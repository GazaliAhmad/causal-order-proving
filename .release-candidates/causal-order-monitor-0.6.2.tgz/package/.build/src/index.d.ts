export declare const monitorPackageVersion = "0.6.2";
export type MonitorImplementationStatus = "replay_operational";
export declare const monitorImplementationStatus: MonitorImplementationStatus;
import { HealthTracker as HealthTrackerImpl } from "./health/HealthTracker.js";
import { ReplayCoordinator as ReplayCoordinatorImpl, type ReplayBatch as ReplayBatchType } from "./replay/ReplayCoordinator.js";
import { DeliveryRouter as DeliveryRouterImpl } from "./routing/DeliveryRouter.js";
import { ThrottleController as ThrottleControllerImpl } from "./throttle/ThrottleController.js";
export { createDefaultMonitorNow, createDefaultMonitorConfig, type MonitorCapacityConfig, type MonitorCapacityOverflowPolicy, type MonitorFilesystemReserveConfig, type MonitorFilesystemUnavailableEvidencePolicy, type MonitorComponentHealthConfig, type MonitorConfig, type MonitorHealthConfig, type MonitorJsonComponentHealthConfig, type MonitorJsonByteLimit, type MonitorJsonCapacityConfig, type MonitorJsonFilesystemReserveConfig, type MonitorJsonLifecycleConfig, type MonitorLifecycleConfig, type MonitorLifecycleOverflowPolicy, type MonitorJsonConfig, type MonitorJsonDuration, type MonitorJsonHealthConfig, type MonitorJsonReplayConfig, type MonitorJsonReservoirConfig, type MonitorJsonThrottleConfig, type MonitorJsonThrottleTierConfig, type MonitorJsonTransportConfig, type MonitorReplayConfig, type MonitorReservoirConfig, type MonitorThrottleConfig, type MonitorThrottleTierConfig, type MonitorTransportConfig, } from "./types/config.js";
export * from "./types/lifecycle.js";
export { DEFAULT_MONITOR_CONFIG_FILE, MONITOR_CONFIG_ENV_VAR, loadMonitorConfigFromEnvironment, loadMonitorConfigFile, parseMonitorConfigJson, type MonitorConfigOverride, resolveMonitorConfigFromEnvironment, resolveMonitorConfig, type MonitorConfigEnvironmentOptions, } from "./config.js";
export { type MonitorClock, type MonitorComponent, type MonitorDeliveryMode, type MonitorEventTimingEvidence, type MonitorHealthState, type MonitorHealthUpdate, type MonitorIngressAction, type MonitorIngressDecision, type MonitorIngressEvent, type MonitorPeerState, type MonitorPeerStateEvent, type MonitorReplaySessionState, type MonitorReplayTargetPath, type MonitorRoutingMode, type MonitorSourcePath, type MonitorThrottleTier, } from "./types/events.js";
export { type MonitorOperationalState, type InspectedMonitorSnapshot, type MonitorComponentHealthSnapshot, type MonitorSnapshot, type ReplaySessionSnapshot, type ReservoirStats, type MonitorAdmissionSnapshotV1, type MonitorCapacityAdmissionPosture, type MonitorCapacityFacet, type MonitorCapacityLastRefusalV1, type MonitorCapacitySnapshotSchema, type MonitorCapacitySnapshotV1, type MonitorOperatorComponent, type MonitorOperatorSnapshotSchema, type MonitorOperatorSnapshotV1, type MonitorOperatorStatus, type MonitorRecommendedAction, type MonitorStoragePressure, type MonitorStorageSnapshotV1, } from "./types/snapshots.js";
export { inspectMonitorSnapshot, inspectMonitorSnapshotV1, } from "./inspect/inspectMonitorSnapshot.js";
export { classifyMonitorBoundaryFailure, deriveMonitorAdmissionDecision, MonitorAdmissionRefusedError, MonitorBoundaryError, MonitorCapacityRefusedError, MonitorClosedError, MonitorIndeterminateOutcomeError, type MonitorAdmissionDecision, type MonitorBoundaryErrorCode, type MonitorBoundaryFailure, type MonitorBoundaryOutcome, type MonitorBoundaryRecommendedAction, type MonitorCapacityLimitingDimension, type MonitorCapacityReasonCode, type MonitorCapacityRefusalEvidence, } from "./boundary.js";
export { createMonitorRuntime, createMonitorRuntimeFromEnvironment, createMonitorRuntimeFromFile, } from "./runtime/createMonitorRuntime.js";
export { MonitorRuntime, ReplayOwnershipError } from "./runtime/MonitorRuntime.js";
export { SQLiteReservoir, type PruneResult, type ReservoirLifecycleStats, type ReservoirReplayEntry, type MonitorStorageEvidenceReader, type WalCheckpointMode, type WalCheckpointResult, } from "./storage/SQLiteReservoir.js";
export { createTransportMonitorAdapterFromEnvironment, createTransportMonitorAdapterFromFile, TransportMonitorAdapter, type MonitorAdapterForwardContext, type MonitorAdapterHandlers, type MonitorIngestResult, type ReplayPumpResult, } from "./transport/TransportMonitorAdapter.js";
export { MonitorScheduler, type MonitorSchedulerOptions, type MonitorSchedulerState, type MonitorSchedulerTimerApi, } from "./scheduler/MonitorScheduler.js";
export { monitorHarnessArtifacts, monitorHarnessScenarios, type MonitorHarnessAdapterContract, type MonitorHarnessArtifactSpec, type MonitorHarnessExpectation, type MonitorHarnessRuntimeKind, type MonitorHarnessScenarioDefinition, type MonitorHarnessScenarioId, } from "./testing/monitorHarness.js";
/** @deprecated Import `HealthTracker` from `@causal-order/monitor/health` instead. */
export declare const HealthTracker: typeof HealthTrackerImpl;
/** @deprecated Import `ReplayCoordinator` from `@causal-order/monitor/replay` instead. */
export declare const ReplayCoordinator: typeof ReplayCoordinatorImpl;
/** @deprecated Import `ReplayBatch` from `@causal-order/monitor/replay` instead. */
export type ReplayBatch = ReplayBatchType;
/** @deprecated Import `DeliveryRouter` from `@causal-order/monitor/routing` instead. */
export declare const DeliveryRouter: typeof DeliveryRouterImpl;
/** @deprecated Import `ThrottleController` from `@causal-order/monitor/throttle` instead. */
export declare const ThrottleController: typeof ThrottleControllerImpl;

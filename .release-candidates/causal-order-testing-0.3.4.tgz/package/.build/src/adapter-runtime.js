#!/usr/bin/env node
import { appendFileSync, mkdirSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { HELP_TEXT, buildConfig, buildRunArtifacts, createSimulationClock, formatDuration, formatOperatorError, randomBetween, randomInt, resolveConfiguredNodeRateShare, sampleIntervalMs, serializeConfig, sleepForSimulatedGap, } from "./deployment-common.js";
import { createMonitorOutageController, deriveReplayRetentionRequirement, } from "./monitor-faults.js";
import { monitorScenarioIncludesDedupeOutage, monitorScenarioIncludesOrderOutage, monitorScenarioIncludesTransport, resolveMonitorScenario, } from "./monitor-scenarios.js";
import { loadHarnessPipeline } from "./pipeline-loader.js";
import { ShutdownCoordinator, TerminalDrainError, } from "./shutdown-coordinator.js";
const SHUTDOWN_TRACE_SYMBOL = Symbol.for("@causal-order/testing/shutdown-contract-trace");
function stringifyJson(value) {
    return JSON.stringify(value, (_key, currentValue) => typeof currentValue === "bigint" ? currentValue.toString() : currentValue);
}
class AsyncOperationTracker {
    limit;
    #tail = Promise.resolve();
    #pendingCount = 0;
    #maxPendingCount = 0;
    #firstFailure = null;
    constructor(limit = 4_096) {
        this.limit = limit;
    }
    run(operation) {
        if (this.#pendingCount >= this.limit) {
            this.#firstFailure ??= new Error(`Monitor operation queue exceeded its ${this.limit} operation limit`);
            return;
        }
        this.#pendingCount += 1;
        this.#maxPendingCount = Math.max(this.#maxPendingCount, this.#pendingCount);
        const scheduled = this.#tail
            .then(async () => {
            // Monitor recovery may enqueue many immediately-resolving promise
            // continuations. Cross an event-loop boundary before each operation so
            // transport acknowledgments and other pending I/O cannot be starved by
            // a long replay chain.
            await new Promise((resolve) => setImmediate(resolve));
            await operation();
        })
            .catch((error) => {
            this.#firstFailure ??= error;
        })
            .finally(() => {
            this.#pendingCount -= 1;
        });
        this.#tail = scheduled;
    }
    async drain() {
        await this.#tail;
        if (this.#firstFailure !== null) {
            throw this.#firstFailure;
        }
    }
    getSnapshot() {
        return {
            pendingOperations: this.#pendingCount,
            maxPendingOperations: this.#maxPendingCount,
            operationLimit: this.limit,
            hasFailure: this.#firstFailure === null ? 0 : 1,
        };
    }
}
class AsyncQueue {
    #items = [];
    #waiters = [];
    #closed = false;
    push(value) {
        if (this.#closed) {
            throw new Error("Cannot push to a closed queue");
        }
        const waiter = this.#waiters.shift();
        if (waiter) {
            waiter({ value, done: false });
            return;
        }
        this.#items.push(value);
    }
    close() {
        if (this.#closed) {
            return;
        }
        this.#closed = true;
        while (this.#waiters.length > 0) {
            const waiter = this.#waiters.shift();
            waiter?.({ value: undefined, done: true });
        }
    }
    [Symbol.asyncIterator]() {
        return this;
    }
    next() {
        if (this.#items.length > 0) {
            return Promise.resolve({
                value: this.#items.shift(),
                done: false,
            });
        }
        if (this.#closed) {
            return Promise.resolve({ value: undefined, done: true });
        }
        return new Promise((resolveNext) => {
            this.#waiters.push(resolveNext);
        });
    }
}
async function main() {
    const maybeHarnessConfig = buildAdapterHarnessConfig(process.argv.slice(2));
    if ("help" in maybeHarnessConfig) {
        console.log(maybeHarnessConfig.text);
        return;
    }
    const { adapterModule, adapterOptions, runtimeConfig: baseConfig, } = maybeHarnessConfig;
    const pipeline = await loadHarnessPipeline(baseConfig.pipelineModule ?? null);
    const wallStartMs = Date.now();
    const artifacts = buildRunArtifacts(baseConfig, wallStartMs);
    const runtimeConfig = {
        ...baseConfig,
        wallStartMs,
        artifacts,
    };
    const clock = createSimulationClock(runtimeConfig);
    mkdirSync(artifacts.runDir, { recursive: true });
    mkdirSync(artifacts.nodesDir, { recursive: true });
    writeFileSync(artifacts.configPath, `${JSON.stringify({
        ...serializeConfig(runtimeConfig),
        adapterModule,
        adapterOptions,
    }, null, 2)}\n`, "utf8");
    const log = (message) => {
        process.stdout.write(`${new Date().toISOString()} ${message}\n`);
    };
    const adapterFactory = await loadAdapterFactory(adapterModule);
    const eventQueue = new AsyncQueue();
    const monitorOperations = new AsyncOperationTracker();
    const dedupeGate = pipeline.createDedupeAdapter({
        config: runtimeConfig.dedupeConfig,
        nowProvider: () => clock.simulationNowMs(),
    });
    const replayRetention = prepareDedupeReplayRetention({
        runtimeConfig,
        dedupeGate,
    });
    const adapter = await adapterFactory({
        nodeIds: runtimeConfig.nodeIds,
        runDir: runtimeConfig.artifacts.runDir,
        log,
        ...adapterOptions,
    });
    const summary = createSummary(runtimeConfig, adapterModule, adapterOptions);
    summary.monitor.replayRetention = replayRetention;
    const shouldFailNextReplayDelivery = runtimeConfig.monitorConfig.enabled &&
        runtimeConfig.monitorConfig.scenarioId === "monitor-replay-retry-backoff";
    let replayFailureInjected = false;
    const enqueueOrderedEvent = (event) => {
        eventQueue.push(event);
    };
    const pushThroughDedupe = (event) => {
        const ingestedAt = event.ingestedAt ?? clock.simulationNowMs();
        const dedupeEvent = {
            ...event,
            ingestedAt,
        };
        const result = dedupeGate.filterWithResult
            ? dedupeGate.filterWithResult(dedupeEvent)
            : {
                accepted: Boolean(dedupeGate.filter(dedupeEvent)),
                reason: "legacy_boolean_result",
                identitySource: "unknown",
            };
        countInto(summary.dedupeDecisions.byReason, result.reason);
        countInto(summary.dedupeDecisions.byIdentitySource, result.identitySource);
        if (!result.accepted) {
            return false;
        }
        enqueueOrderedEvent({
            ...event,
            ingestedAt,
        });
        return true;
    };
    let monitorAdapter = null;
    if (runtimeConfig.monitorConfig.enabled) {
        if (typeof pipeline.createMonitorAdapter !== "function") {
            throw new Error("The selected pipeline does not implement createMonitorAdapter(), but monitor mode was enabled.");
        }
        monitorAdapter = await pipeline.createMonitorAdapter({
            runtimeConfig,
            nowProvider: () => clock.simulationNowMs(),
            deliverToDedupe: (event, context) => {
                if (shouldFailNextReplayDelivery &&
                    context?.replay === true &&
                    !replayFailureInjected) {
                    replayFailureInjected = true;
                    summary.monitor.replayFailureInjected = true;
                    appendMonitorReplay(runtimeConfig, clock, {
                        kind: "replay_delivery_failure_injected",
                        eventId: event.id,
                        rowId: context?.rowId ?? null,
                    });
                    throw new Error("simulated replay delivery failure for retry-backoff validation");
                }
                summary.monitor.forwardedToDedupe += 1;
                if (context?.replay === true) {
                    summary.monitor.replayDeliveriesToDedupe += 1;
                }
                else {
                    summary.monitor.normalDeliveriesToDedupe += 1;
                }
                pushThroughDedupe(event);
            },
            deliverToOrder: (event) => {
                summary.monitor.forwardedToOrder += 1;
                enqueueOrderedEvent({
                    ...event,
                    ingestedAt: event.ingestedAt ?? clock.simulationNowMs(),
                });
            },
            onBuffered: (event, context) => {
                summary.monitor.bufferedEvents += 1;
                appendMonitorHealth(runtimeConfig, clock, "buffered", {
                    eventId: event.id,
                    nodeId: event.nodeId,
                    decision: context,
                });
            },
            onDecision: (event, context) => {
                countInto(summary.monitor.routingModes, String(context.routingMode ?? "unknown"));
                countInto(summary.monitor.deliveryModes, String(context.deliveryMode ?? "unknown"));
                appendMonitorHealth(runtimeConfig, clock, "decision", {
                    eventId: event.id,
                    nodeId: event.nodeId,
                    decision: context,
                });
            },
            onReplayStateChange: (snapshot) => {
                summary.monitor.replayState = String(snapshot.state ?? "unknown");
                summary.monitor.lastReplaySnapshot = snapshot;
                appendMonitorReplay(runtimeConfig, clock, {
                    kind: "replay_state",
                    snapshot,
                });
            },
        });
        summary.monitor.enabled = true;
        summary.monitor.moduleSpecifier =
            runtimeConfig.monitorConfig.moduleSpecifier ?? null;
        summary.monitor.scenarioId = runtimeConfig.monitorConfig.scenarioId ?? null;
    }
    let scenarioTransportFaultActive = false;
    const scenarioTransportNodeId = runtimeConfig.nodeIds[0];
    const monitorOutageController = createMonitorOutageController({
        elapsedMs: () => clock.simulationNowMs() - clock.simulatedStartMs,
        monitorAdapter,
        monitorConfig: runtimeConfig.monitorConfig,
        durationMs: runtimeConfig.durationMs,
        steadyForMs: runtimeConfig.steadyForMs,
        now: () => clock.simulationNowMs(),
        setTransportState: typeof adapter.setNodeConnectivity === "function"
            ? async (state) => {
                if (state === "offline") {
                    scenarioTransportFaultActive = true;
                }
                await adapter.setNodeConnectivity?.(scenarioTransportNodeId, state === "offline" ? "disconnected" : "connected");
                if (state === "online") {
                    scenarioTransportFaultActive = false;
                }
            }
            : undefined,
        onTransition: (component, state, snapshot, elapsedMs) => {
            if (component === "transport" && state === "offline") {
                summary.monitor.scenarioTransportOutages =
                    Number(summary.monitor.scenarioTransportOutages ?? 0) + 1;
            }
            appendMonitorHealth(runtimeConfig, clock, "scenario_transition", {
                component,
                state,
                scenarioId: runtimeConfig.monitorConfig.scenarioId,
                scenarioLabel: snapshot.label,
                elapsedMs: elapsedMs.toString(),
            });
        },
    });
    const nodeStates = new Map();
    const recentGlobal = [];
    const completedNodes = new Set();
    const scheduledTimeouts = new Set();
    const pendingTracker = { current: 0, firstFailure: null };
    let heartbeatTimer = null;
    let stopRequested = false;
    let transportCallbackBoundary = "open";
    let transportCallbackViolation = null;
    let interruptionSignal = null;
    const acceptTransportCallback = () => {
        if (transportCallbackBoundary === "open") {
            return true;
        }
        transportCallbackViolation ??= new Error("Transport callback occurred after the stop barrier");
        return false;
    };
    for (const nodeId of runtimeConfig.nodeIds) {
        const state = {
            nodeId,
            sequence: 0n,
            hlc: pipeline.createClockAdapter({
                nodeId,
                now: clock.simulationNowMs,
            }),
            recentLocal: [],
            stats: {
                generated: 0,
                sent: 0,
                duplicatesInjected: 0,
                sameNodeDependencies: 0,
                crossNodeDependencies: 0,
                remoteHintsReceived: 0,
                maxPendingQueueDepth: 0,
                darkWindowsEntered: 0,
                reconnects: 0,
                connectionOpens: 0,
                jitterExtraDelaysApplied: 0,
                jitterSpikeDelaysApplied: 0,
            },
            lastScheduledSendAtMs: 0n,
            darkActive: false,
        };
        nodeStates.set(nodeId, state);
        summary.transport.nodeStats[nodeId] = state.stats;
    }
    const requestStop = (signal) => {
        if (stopRequested) {
            return;
        }
        stopRequested = true;
        interruptionSignal = signal;
        if (summary.shutdown) {
            summary.shutdown.interruptionRequested = true;
            summary.shutdown.interruptionSignal = signal;
        }
    };
    process.once("SIGINT", () => requestStop("SIGINT"));
    process.once("SIGTERM", () => requestStop("SIGTERM"));
    adapter.onEvent((event) => {
        if (!acceptTransportCallback()) {
            return;
        }
        const ingestedAt = clock.simulationNowMs();
        summary.transport.receivedEvents += 1;
        countInto(summary.transport.receivedByNode, event.nodeId);
        const enrichedEvent = {
            ...event,
            ingestedAt,
        };
        if (monitorAdapter) {
            monitorOperations.run(async () => {
                await monitorOutageController?.tick();
                if (!scenarioTransportFaultActive) {
                    monitorAdapter?.observeHeartbeat("transport", ingestedAt, {
                        eventId: event.id,
                        nodeId: event.nodeId,
                    });
                }
                await monitorAdapter?.ingest(enrichedEvent);
                summary.monitor.lastSnapshot = monitorAdapter?.getSnapshot() ?? null;
            });
            return;
        }
        pushThroughDedupe(enrichedEvent);
    });
    adapter.onPeerState((state) => {
        if (!acceptTransportCallback()) {
            return;
        }
        if (state.status === "connected") {
            summary.transport.connectedNodes[state.peerId] = true;
        }
        if (state.status === "disconnected") {
            summary.transport.disconnectedPeers[state.peerId] = true;
        }
        countInto(summary.transport.peerStatesByStatus, state.status);
        appendLifecycleEvent(runtimeConfig, clock, "adapter_peer_state", {
            peerId: state.peerId,
            connectionId: state.connectionId ?? null,
            status: state.status,
            detail: state.detail ?? null,
        });
        if (monitorAdapter) {
            const monitorState = state.status === "connected"
                ? "online"
                : state.status === "disconnected"
                    ? "offline"
                    : "degraded";
            monitorOperations.run(async () => {
                await monitorAdapter?.updateComponentHealth("transport", monitorState, {
                    peerId: state.peerId,
                    connectionId: state.connectionId ?? null,
                    detail: state.detail ?? null,
                });
            });
            appendMonitorHealth(runtimeConfig, clock, "transport_peer_state", {
                peerId: state.peerId,
                connectionId: state.connectionId ?? null,
                status: state.status,
                mappedState: monitorState,
            });
        }
    });
    adapter.onError((error) => {
        if (!acceptTransportCallback()) {
            return;
        }
        summary.transport.errors += 1;
        appendAnomalyRecord(runtimeConfig, summary, {
            timestampIso: new Date().toISOString(),
            type: "transport_error",
            severity: "error",
            eventId: null,
            nodeId: error.peerId ?? null,
            relatedEventIds: [],
            message: error.detail,
        });
        if (monitorAdapter) {
            monitorOperations.run(async () => {
                await monitorAdapter?.updateComponentHealth("transport", "degraded", {
                    peerId: error.peerId ?? null,
                    connectionId: error.connectionId ?? null,
                    detail: error.detail,
                });
            });
        }
    });
    const orderingPromise = (async () => {
        for await (const batch of pipeline.orderEvents(eventQueue, {
            batchSize: runtimeConfig.batchSize,
            maxLateArrivalMs: runtimeConfig.maxLateArrivalMs,
            lateArrivalPolicy: runtimeConfig.lateArrivalPolicy,
            strict: runtimeConfig.strict,
            allowUnknownOrder: runtimeConfig.allowUnknownOrder,
            detectAnomalies: runtimeConfig.detectAnomalies,
            tieBreaker: runtimeConfig.tieBreaker,
        })) {
            summary.stream.batches += 1;
            summary.stream.orderedEvents += batch.events.length;
            summary.stream.anomalies += batch.anomalies.length;
            summary.stream.lastWatermarkMs = batch.watermark.toString();
            if (BigInt(summary.stream.maxWatermarkMs) < batch.watermark) {
                summary.stream.maxWatermarkMs = batch.watermark.toString();
            }
            if (batch.correction) {
                summary.stream.correctionBatches += 1;
                pushLimited(summary.samples.corrections, {
                    triggerEventId: batch.correction.triggerEventId,
                    reason: batch.correction.reason,
                    scope: batch.correction.scope,
                    watermarkMs: batch.watermark.toString(),
                }, runtimeConfig.sampleLimit);
            }
            if (batch.isFinal) {
                summary.stream.finalBatches += 1;
            }
            for (const orderedEvent of batch.events) {
                countInto(summary.stream.byOrderBasis, orderedEvent.orderBasis);
                countInto(summary.stream.byConfidence, orderedEvent.confidence);
            }
            for (const anomaly of batch.anomalies) {
                countInto(summary.stream.byAnomalyType, anomaly.type);
                countInto(summary.stream.byAnomalySeverity, anomaly.severity);
                if (anomaly.type === "late_arrival") {
                    summary.transport.persistedLateArrivals += 1;
                }
                appendAnomalyRecord(runtimeConfig, summary, {
                    timestampIso: new Date().toISOString(),
                    type: anomaly.type,
                    severity: anomaly.severity,
                    eventId: anomaly.event?.id ?? null,
                    nodeId: anomaly.event?.nodeId ?? null,
                    relatedEventIds: anomaly.relatedEvents?.map((entry) => entry.id) ?? [],
                    message: anomaly.message,
                });
            }
        }
    })();
    // Failure is observed and recorded by terminal orchestration; attach a
    // handler immediately so an early stream rejection is not process-global.
    void orderingPromise.catch(() => { });
    summary.shutdown = {
        phase: "running",
        phases: ["running"],
        milestones: [],
        completedPhases: [],
        lastCompletedPhase: null,
        transportReceivedAtBarrier: null,
        transportCallbackBoundary: "open",
        orderedAtDrain: null,
        verdictDerived: false,
        resourcesClosed: false,
        interruptionRequested: stopRequested,
        interruptionSignal,
        primaryFailure: null,
        primaryFailurePhase: null,
        errors: [],
        errorLimit: 16,
        shutdownTimeoutMs: Math.max(1_000, Math.ceil(Number(runtimeConfig.maxTailDrainMs) / runtimeConfig.timeScale) +
            1_000),
        noProgressPassLimit: 3,
    };
    const captureMonitorEvidence = (evidence) => {
        summary.monitor.lastSnapshot = evidence.snapshot;
        summary.monitor.lastReplaySnapshot = evidence.replaySnapshot;
        summary.monitor.replayState = String(evidence.replaySnapshot.state ?? "unknown");
        summary.monitor.operatorSnapshot = evidence.operatorSnapshot;
        summary.monitor.capacitySnapshot =
            monitorAdapter?.getCapacitySnapshot?.() ?? null;
        summary.monitor.operationTracker = monitorOperations.getSnapshot();
    };
    const captureLifecycleEvidence = (evidence) => {
        summary.monitor.lifecycleFlush = evidence.flush;
        summary.monitor.lifecycleSnapshot = evidence.snapshot;
    };
    const recordShutdownMilestone = (milestone) => {
        summary.shutdown.milestones.push(milestone);
        appendLifecycleEvent(runtimeConfig, clock, "adapter_shutdown_milestone", {
            milestone,
        });
        const trace = globalThis[SHUTDOWN_TRACE_SYMBOL];
        if (typeof trace?.record === "function") {
            trace.record(milestone);
        }
    };
    const shutdownCoordinator = new ShutdownCoordinator({
        adapter,
        monitorAdapter,
        monitorOperations,
        eventQueue,
        orderingPromise,
        shutdownTimeoutMs: Math.max(1_000, Math.ceil(Number(runtimeConfig.maxTailDrainMs) / runtimeConfig.timeScale) +
            1_000),
        replayBatchSize: runtimeConfig.monitorConfig.replayBatchSize,
        simulationNowMs: clock.simulationNowMs,
        timeScale: runtimeConfig.timeScale,
        drainIngress: async () => {
            await waitForDrain(() => pendingTracker.current === 0, Math.max(1_000, Math.ceil(Number(runtimeConfig.maxTailDrainMs) / runtimeConfig.timeScale) + 1_000), "pending adapter deliveries to drain");
            if (pendingTracker.firstFailure !== null) {
                throw pendingTracker.firstFailure;
            }
        },
        stopPeriodicRecovery: () => {
            if (heartbeatTimer) {
                clearInterval(heartbeatTimer);
                heartbeatTimer = null;
            }
        },
        markTransportCallbackBoundaryClosed: () => {
            transportCallbackBoundary = "closed";
            summary.shutdown.transportCallbackBoundary = "closed";
        },
        markTransportCallbackBoundaryUnsafe: () => {
            transportCallbackBoundary = "unsafe";
            summary.shutdown.transportCallbackBoundary = "unsafe";
        },
        getTransportCallbackViolation: () => transportCallbackViolation,
        observeRecoveryHealth: async () => {
            await monitorOutageController?.tick({ reconcile: false });
        },
        captureTransportEvidence: () => {
            summary.shutdown.transportReceivedAtBarrier =
                summary.transport.receivedEvents;
        },
        captureMonitorEvidence,
        captureLifecycleEvidence,
        captureOrderingEvidence: () => {
            summary.shutdown.orderedAtDrain = summary.stream.orderedEvents;
        },
        onPhase: (phase) => {
            summary.shutdown.phase = phase;
            summary.shutdown.phases.push(phase);
            summary.shutdown.completedPhases = shutdownCoordinator.completedPhases;
            summary.shutdown.lastCompletedPhase =
                shutdownCoordinator.lastCompletedPhase;
            appendLifecycleEvent(runtimeConfig, clock, "adapter_shutdown_phase", {
                phase,
            });
        },
        onMilestone: recordShutdownMilestone,
    });
    log([
        `starting adapter runtime in ${artifacts.runDir}`,
        `adapter=${adapterModule}`,
        `duration=${formatDuration(runtimeConfig.durationMs)}`,
        `steady=${formatDuration(runtimeConfig.steadyForMs)}`,
        `timeScale=${runtimeConfig.timeScale}x`,
        `nodes=${runtimeConfig.nodeIds.length}`,
        `profile=${runtimeConfig.workloadProfile.name}`,
    ].join(" | "));
    appendLifecycleEvent(runtimeConfig, clock, "adapter_runtime_started", {
        adapterModule,
    });
    const recordedShutdownFailures = new Set();
    const recordPrimaryFailure = (error) => {
        if (summary.shutdown.primaryFailure !== null) {
            recordSecondaryFailure(error);
            return;
        }
        const evidence = serializeShutdownFailure(error, shutdownCoordinator.phase);
        summary.shutdown.primaryFailure = evidence;
        summary.shutdown.primaryFailurePhase = evidence.phase;
        summary.outcome.failure = evidence;
        recordedShutdownFailures.add(error);
    };
    const recordSecondaryFailure = (error) => {
        if (recordedShutdownFailures.has(error)) {
            return;
        }
        recordedShutdownFailures.add(error);
        if (summary.shutdown.errors.length >= summary.shutdown.errorLimit) {
            return;
        }
        summary.shutdown.errors.push(serializeShutdownFailure(error, shutdownCoordinator.phase));
    };
    let summaryFinalized = false;
    let monitorSummaryWritten = false;
    let summaryWritten = false;
    try {
        await adapter.start();
        await monitorOutageController?.tick();
        heartbeatTimer = setInterval(() => {
            appendHeartbeat(runtimeConfig, summary, clock, dedupeGate, completedNodes.size);
            if (monitorAdapter) {
                monitorOperations.run(async () => {
                    await monitorOutageController?.tick();
                });
                summary.monitor.lastSnapshot = monitorAdapter.getSnapshot();
                appendMonitorHeartbeat(runtimeConfig, clock, summary, completedNodes.size, monitorAdapter);
            }
        }, Math.max(250, Math.ceil(Number(runtimeConfig.reportEveryMs) / runtimeConfig.timeScale)));
        appendHeartbeat(runtimeConfig, summary, clock, dedupeGate, completedNodes.size);
        if (monitorAdapter) {
            appendMonitorHeartbeat(runtimeConfig, clock, summary, completedNodes.size, monitorAdapter);
        }
        await Promise.all([...nodeStates.values()].map((nodeState) => runNodeLoop({
            adapter,
            clock,
            runtimeConfig,
            nodeState,
            recentGlobal,
            summary,
            pendingTracker,
            scheduledTimeouts,
            shouldStop: () => stopRequested,
        }).then(() => {
            completedNodes.add(nodeState.nodeId);
            appendLifecycleEvent(runtimeConfig, clock, "node_completed", {
                nodeId: nodeState.nodeId,
                stats: nodeState.stats,
            });
        })));
        await shutdownCoordinator.runToEvidenceReady();
        summary.outcome.status = stopRequested ? "interrupted" : "completed";
    }
    catch (error) {
        summary.outcome.status = stopRequested ? "interrupted" : "failed";
        recordPrimaryFailure(error);
    }
    finally {
        if (heartbeatTimer) {
            clearInterval(heartbeatTimer);
            heartbeatTimer = null;
        }
        if (shutdownCoordinator.phase !== "evidence_finalizing") {
            summary.shutdown.cancelledScheduledSends = scheduledTimeouts.size;
            for (const timeout of scheduledTimeouts) {
                clearTimeout(timeout);
            }
            pendingTracker.current = Math.max(0, pendingTracker.current - scheduledTimeouts.size);
            scheduledTimeouts.clear();
        }
        const evidenceReady = shutdownCoordinator.phase === "evidence_finalizing";
        if (!evidenceReady) {
            try {
                const cleanup = await shutdownCoordinator.runFailureCleanup();
                summary.shutdown.cleanup = {
                    transportStopped: cleanup.transportStopped,
                    monitorOperationsDrained: cleanup.monitorOperationsDrained,
                    lifecycleDrained: cleanup.lifecycleDrained,
                    orderingSettled: cleanup.orderingSettled,
                };
                for (const error of cleanup.errors) {
                    recordSecondaryFailure(error);
                }
            }
            catch (error) {
                recordSecondaryFailure(error);
            }
        }
        summary.shutdown.completedPhases = shutdownCoordinator.completedPhases;
        summary.shutdown.lastCompletedPhase =
            shutdownCoordinator.lastCompletedPhase;
        summary.shutdown.phase = shutdownCoordinator.phase;
        summary.shutdown.pendingScheduledSends = pendingTracker.current;
        summary.shutdown.operationTracker = monitorOperations.getSnapshot();
        try {
            summary.dedupe = dedupeGate.getStats();
        }
        catch (error) {
            recordSecondaryFailure(error);
        }
        summary.monitor.operationTracker = monitorOperations.getSnapshot();
        if (monitorAdapter) {
            if (!evidenceReady) {
                try {
                    captureMonitorEvidence({
                        snapshot: monitorAdapter.getSnapshot(),
                        replaySnapshot: monitorAdapter.getReplaySnapshot(),
                        operatorSnapshot: monitorAdapter.getOperatorSnapshot?.() ?? null,
                    });
                    summary.monitor.lifecycleSnapshot =
                        monitorAdapter.getLifecycleSnapshot?.() ??
                            summary.monitor.lifecycleSnapshot;
                }
                catch (error) {
                    recordSecondaryFailure(error);
                }
            }
        }
        if (!summaryFinalized) {
            finalizeSummary(summary, clock, runtimeConfig, stopRequested);
            summaryFinalized = true;
        }
        try {
            if (evidenceReady) {
                shutdownCoordinator.markVerdictDerived();
            }
            else {
                shutdownCoordinator.markFailureVerdictDerived();
            }
            summary.shutdown.verdictDerived = true;
        }
        catch (error) {
            recordSecondaryFailure(error);
            shutdownCoordinator.markFailureVerdictDerived();
            summary.shutdown.verdictDerived = true;
        }
        try {
            appendHeartbeat(runtimeConfig, summary, clock, dedupeGate, completedNodes.size, "final");
        }
        catch (error) {
            recordSecondaryFailure(error);
        }
        if (monitorAdapter) {
            try {
                appendMonitorHeartbeat(runtimeConfig, clock, summary, completedNodes.size, monitorAdapter, "final");
            }
            catch (error) {
                recordSecondaryFailure(error);
            }
            if (!monitorSummaryWritten) {
                try {
                    writeFileSync(runtimeConfig.artifacts.monitorSummaryPath, `${stringifyJson(summary.monitor)}\n`, "utf8");
                    monitorSummaryWritten = true;
                }
                catch (error) {
                    recordSecondaryFailure(error);
                }
            }
        }
        const closeDependencies = () => {
            try {
                monitorAdapter?.close();
            }
            catch (error) {
                recordSecondaryFailure(error);
            }
            try {
                dedupeGate.destroy();
            }
            catch (error) {
                recordSecondaryFailure(error);
            }
        };
        try {
            if (evidenceReady) {
                await shutdownCoordinator.closeResources(closeDependencies);
            }
            else {
                await shutdownCoordinator.closeResourcesForFailureCleanup(closeDependencies);
            }
            summary.shutdown.resourcesClosed = true;
        }
        catch (error) {
            recordSecondaryFailure(error);
        }
        summary.shutdown.completedPhases = shutdownCoordinator.completedPhases;
        summary.shutdown.lastCompletedPhase =
            shutdownCoordinator.lastCompletedPhase;
        summary.shutdown.phase = shutdownCoordinator.phase;
        summary.shutdown.finishedLifecycleScope =
            "harness artifact after monitor lifecycle flush";
        try {
            appendLifecycleEvent(runtimeConfig, clock, "adapter_runtime_finished", {
                status: summary.outcome.status,
            });
        }
        catch (error) {
            recordSecondaryFailure(error);
        }
        if (!summaryWritten) {
            try {
                writeFileSync(runtimeConfig.artifacts.summaryPath, `${stringifyJson(summary)}\n`, "utf8");
                summaryWritten = true;
            }
            catch (error) {
                recordSecondaryFailure(error);
                process.stderr.write("Failed to write final adapter-runtime summary.\n");
            }
        }
        if (summary.outcome.status !== "completed" ||
            summary.outcome.verdict === "fail_contract" ||
            summary.outcome.verdict === "invalid_run" ||
            !summaryWritten) {
            process.exitCode = 1;
        }
        log([
            `completed status=${summary.outcome.status}`,
            `received=${summary.transport.receivedEvents}`,
            `ordered=${summary.stream.orderedEvents}`,
            `anomalies=${summary.stream.anomalies}`,
            `summary=${runtimeConfig.artifacts.summaryPath}`,
        ].join(" | "));
    }
}
async function runNodeLoop({ adapter, clock, runtimeConfig, nodeState, recentGlobal, summary, pendingTracker, scheduledTimeouts, shouldStop, }) {
    try {
        while (!shouldStop() && clock.simulationNowMs() < clock.simulatedEndMs) {
            const phase = samplePhase(clock, runtimeConfig, clock.simulationNowMs());
            const totalRate = phase === "steady"
                ? runtimeConfig.eventsPerSecond
                : runtimeConfig.eventsPerSecond *
                    runtimeConfig.chaosMultiplier *
                    randomBetween(runtimeConfig.workloadProfile.phaseRates.chaosJitterMin, runtimeConfig.workloadProfile.phaseRates.chaosJitterMax);
            const nodeRate = Math.max(0.25, totalRate *
                resolveConfiguredNodeRateShare(runtimeConfig.nodeIds, runtimeConfig.workloadProfile.nodeWeights, nodeState.nodeId));
            await sleepForSimulatedGap(sampleIntervalMs(nodeRate), runtimeConfig.timeScale);
            const now = clock.simulationNowMs();
            if (shouldStop() || now >= clock.simulatedEndMs) {
                break;
            }
            await syncAdapterNodeDarkState({
                adapter,
                clock,
                runtimeConfig,
                nodeState,
                now,
            });
            if (nodeState.darkActive) {
                continue;
            }
            const eventRecord = createEventRecord(nodeState, runtimeConfig, phase, now, recentGlobal);
            summary.simulation.generated += 1;
            rememberRecent(nodeState.recentLocal, eventRecord.recentEvent, 48);
            rememberRecent(recentGlobal, eventRecord.recentEvent, 256);
            const baseDelayMs = applyAdapterNodeJitter(sampleDeliveryDelayMs(runtimeConfig, phase), runtimeConfig, nodeState);
            const maxAllowedDelayMs = clock.simulatedEndMs - now + runtimeConfig.maxTailDrainMs;
            const firstSendAtMs = chooseSendTime(nodeState, phase, now + (baseDelayMs > maxAllowedDelayMs ? maxAllowedDelayMs : baseDelayMs), runtimeConfig);
            scheduleSend({
                adapter,
                clock,
                runtimeConfig,
                event: eventRecord.event,
                nodeState,
                summary,
                pendingTracker,
                scheduledTimeouts,
                sendAtMs: firstSendAtMs,
                isDuplicate: false,
            });
            const duplicateChance = phase === "steady"
                ? runtimeConfig.workloadProfile.duplicates.steadyChance
                : runtimeConfig.workloadProfile.duplicates.chaoticChance;
            if (Math.random() < duplicateChance) {
                const duplicateDelayMs = applyAdapterNodeJitter(sampleDeliveryDelayMs(runtimeConfig, "chaotic"), runtimeConfig, nodeState) + 250n;
                const duplicateSendAtMs = firstSendAtMs + duplicateDelayMs;
                scheduleSend({
                    adapter,
                    clock,
                    runtimeConfig,
                    event: eventRecord.event,
                    nodeState,
                    summary,
                    pendingTracker,
                    scheduledTimeouts,
                    sendAtMs: duplicateSendAtMs > clock.simulatedEndMs + runtimeConfig.maxTailDrainMs
                        ? clock.simulatedEndMs + runtimeConfig.maxTailDrainMs
                        : duplicateSendAtMs,
                    isDuplicate: true,
                });
            }
        }
    }
    finally {
        if (nodeState.darkActive) {
            await adapter.setNodeConnectivity?.(nodeState.nodeId, "connected");
            nodeState.darkActive = false;
            nodeState.stats.reconnects += 1;
        }
    }
}
async function syncAdapterNodeDarkState({ adapter, clock, runtimeConfig, nodeState, now, }) {
    const faultInjection = runtimeConfig.faultInjection;
    const darkNodeIndex = faultInjection.darkNodeIds.indexOf(nodeState.nodeId);
    if (darkNodeIndex < 0 || faultInjection.darkDurationMs <= 0n) {
        return;
    }
    if (typeof adapter.setNodeConnectivity !== "function") {
        throw new Error("The configured adapter does not support node dark-window connectivity control");
    }
    const firstDarkStartMs = clock.simulatedStartMs +
        faultInjection.darkStartAfterMs +
        faultInjection.darkStaggerMs * BigInt(darkNodeIndex);
    const shouldBeDark = now >= firstDarkStartMs &&
        (now - firstDarkStartMs) % faultInjection.darkIntervalMs <
            faultInjection.darkDurationMs;
    if (shouldBeDark === nodeState.darkActive) {
        return;
    }
    await adapter.setNodeConnectivity(nodeState.nodeId, shouldBeDark ? "disconnected" : "connected");
    nodeState.darkActive = shouldBeDark;
    if (shouldBeDark) {
        nodeState.stats.darkWindowsEntered += 1;
    }
    else {
        nodeState.stats.reconnects += 1;
    }
}
function applyAdapterNodeJitter(delayMs, runtimeConfig, nodeState) {
    const faultInjection = runtimeConfig.faultInjection;
    if (!faultInjection.jitterNodeIds.includes(nodeState.nodeId)) {
        return delayMs;
    }
    let adjustedDelayMs = delayMs +
        BigInt(randomInt(Number(faultInjection.jitterExtraDelayMinMs), Number(faultInjection.jitterExtraDelayMaxMs)));
    nodeState.stats.jitterExtraDelaysApplied += 1;
    if (Math.random() < faultInjection.jitterSpikeChance) {
        adjustedDelayMs += BigInt(randomInt(Number(faultInjection.jitterSpikeMinMs), Number(faultInjection.jitterSpikeMaxMs)));
        nodeState.stats.jitterSpikeDelaysApplied += 1;
    }
    return adjustedDelayMs;
}
function scheduleSend({ adapter, clock, runtimeConfig, event, nodeState, summary, pendingTracker, scheduledTimeouts, sendAtMs, isDuplicate, }) {
    pendingTracker.current += 1;
    nodeState.stats.maxPendingQueueDepth = Math.max(nodeState.stats.maxPendingQueueDepth, pendingTracker.current);
    summary.simulation.maxPendingQueueDepth = Math.max(summary.simulation.maxPendingQueueDepth, pendingTracker.current);
    summary.simulation.maxQueueDepth = Math.max(summary.simulation.maxQueueDepth, pendingTracker.current);
    const gapMs = sendAtMs > clock.simulationNowMs() ? sendAtMs - clock.simulationNowMs() : 0n;
    const wallDelayMs = Math.max(0, Math.ceil(Number(gapMs) / runtimeConfig.timeScale));
    const timeout = setTimeout(() => {
        scheduledTimeouts.delete(timeout);
        void (async () => {
            try {
                await adapter.send(event);
                nodeState.stats.sent += 1;
                summary.simulation.sent += 1;
                if (isDuplicate) {
                    nodeState.stats.duplicatesInjected += 1;
                    summary.simulation.duplicatesInjected += 1;
                }
            }
            catch (error) {
                pendingTracker.firstFailure ??= error;
                summary.transport.errors += 1;
                appendAnomalyRecord(runtimeConfig, summary, {
                    timestampIso: new Date().toISOString(),
                    type: "adapter_send_error",
                    severity: "error",
                    eventId: event.id,
                    nodeId: event.nodeId,
                    relatedEventIds: [],
                    message: error instanceof Error ? error.message : String(error),
                });
            }
            finally {
                pendingTracker.current = Math.max(0, pendingTracker.current - 1);
            }
        })();
    }, wallDelayMs);
    scheduledTimeouts.add(timeout);
}
function createEventRecord(nodeState, runtimeConfig, phase, now, recentGlobal) {
    const dependency = chooseDependency(runtimeConfig, phase, nodeState, recentGlobal);
    const traceId = dependency?.traceId ??
        `${nodeState.nodeId}-trace-${String(nodeState.stats.generated + 1).padStart(8, "0")}`;
    const entityId = dependency?.entityId ??
        `${nodeState.nodeId}-entity-${String(nodeState.stats.generated + 1).padStart(8, "0")}`;
    let clockValue;
    if (dependency?.isCrossNode) {
        clockValue = nodeState.hlc.receive(dependency.event.clock);
        nodeState.stats.crossNodeDependencies += 1;
    }
    else {
        clockValue = nodeState.hlc.now();
        if (dependency?.event) {
            nodeState.stats.sameNodeDependencies += 1;
        }
    }
    nodeState.sequence += 1n;
    nodeState.stats.generated += 1;
    const id = `${nodeState.nodeId}-${nodeState.sequence.toString().padStart(12, "0")}`;
    const relation = dependency?.relation ?? null;
    const event = {
        id,
        nodeId: nodeState.nodeId,
        clock: clockValue,
        sequence: nodeState.sequence,
        traceId,
        payload: {
            phase,
            service: nodeState.nodeId,
            entityId,
            traceId,
            sentAtMs: now.toString(),
            operation: chooseOperation(phase, dependency),
            dependencyKind: relation,
        },
    };
    if (relation === "parent") {
        event.parentEventId = dependency?.event.id;
    }
    if (relation === "dependency" && dependency?.event.id) {
        event.dependencyEventIds = [dependency.event.id];
    }
    return {
        event,
        recentEvent: {
            id,
            nodeId: nodeState.nodeId,
            clock: event.clock,
            traceId,
            entityId,
        },
    };
}
function chooseDependency(runtimeConfig, phase, nodeState, recentGlobal) {
    const sameNodeChance = phase === "steady"
        ? runtimeConfig.workloadProfile.dependencies.steadySameNodeChance
        : runtimeConfig.workloadProfile.dependencies.chaoticSameNodeChance;
    const crossNodeChance = phase === "steady"
        ? runtimeConfig.workloadProfile.dependencies.steadyCrossNodeChance
        : runtimeConfig.workloadProfile.dependencies.chaoticCrossNodeChance;
    const roll = Math.random();
    if (roll < crossNodeChance) {
        const remoteCandidates = recentGlobal.filter((entry) => entry.nodeId !== nodeState.nodeId);
        if (remoteCandidates.length > 0) {
            const event = chooseFrom(remoteCandidates);
            return {
                event,
                isCrossNode: true,
                relation: Math.random() < runtimeConfig.workloadProfile.dependencies.crossNodeParentChance
                    ? "parent"
                    : "dependency",
                traceId: event.traceId ?? null,
                entityId: event.entityId ?? null,
            };
        }
    }
    if (roll < crossNodeChance + sameNodeChance && nodeState.recentLocal.length > 0) {
        const event = chooseFrom(nodeState.recentLocal);
        return {
            event,
            isCrossNode: false,
            relation: Math.random() < runtimeConfig.workloadProfile.dependencies.sameNodeParentChance
                ? "parent"
                : "dependency",
            traceId: event.traceId ?? null,
            entityId: event.entityId ?? null,
        };
    }
    return null;
}
function chooseOperation(phase, dependency) {
    if (dependency?.isCrossNode) {
        return chooseFrom([
            "replica.applied",
            "projection.updated",
            "payment.confirmed",
            "inventory.reserved",
            "workflow.forwarded",
        ]);
    }
    if (phase === "steady") {
        return chooseFrom([
            "ingress.accepted",
            "order.created",
            "state.persisted",
            "workflow.advanced",
        ]);
    }
    return chooseFrom([
        "retry.dispatched",
        "reconciliation.applied",
        "projection.rebuilt",
        "workflow.recovered",
    ]);
}
function samplePhase(clock, runtimeConfig, now) {
    return now - clock.simulatedStartMs < runtimeConfig.steadyForMs ? "steady" : "chaotic";
}
function sampleDeliveryDelayMs(runtimeConfig, phase) {
    if (phase === "steady") {
        let delayMs = BigInt(randomInt(runtimeConfig.workloadProfile.delays.steady.baseMinMs, runtimeConfig.workloadProfile.delays.steady.baseMaxMs));
        if (Math.random() < runtimeConfig.workloadProfile.delays.steady.spikeChance) {
            delayMs += BigInt(randomInt(runtimeConfig.workloadProfile.delays.steady.spikeMinMs, runtimeConfig.workloadProfile.delays.steady.spikeMaxMs));
        }
        return delayMs;
    }
    let delayMs = BigInt(randomInt(runtimeConfig.workloadProfile.delays.chaotic.baseMinMs, runtimeConfig.workloadProfile.delays.chaotic.baseMaxMs));
    if (Math.random() < runtimeConfig.workloadProfile.delays.chaotic.slowSpikeChance) {
        delayMs += BigInt(randomInt(runtimeConfig.workloadProfile.delays.chaotic.slowSpikeMinMs, runtimeConfig.workloadProfile.delays.chaotic.slowSpikeMaxMs));
    }
    if (Math.random() < runtimeConfig.workloadProfile.delays.chaotic.lateSpikeChance) {
        delayMs += BigInt(randomInt(runtimeConfig.workloadProfile.delays.chaotic.lateSpikeMinMs, runtimeConfig.workloadProfile.delays.chaotic.lateSpikeMaxMs));
    }
    if (Math.random() < runtimeConfig.workloadProfile.delays.chaotic.extremeSpikeChance) {
        delayMs += BigInt(randomInt(runtimeConfig.workloadProfile.delays.chaotic.extremeSpikeMinMs, runtimeConfig.workloadProfile.delays.chaotic.extremeSpikeMaxMs));
    }
    return delayMs;
}
function chooseSendTime(nodeState, phase, candidateSendAtMs, runtimeConfig) {
    const preserveOrderChance = phase === "steady"
        ? runtimeConfig.workloadProfile.ordering.steadyPreserveOrderChance
        : runtimeConfig.workloadProfile.ordering.chaoticPreserveOrderChance;
    if (Math.random() >= preserveOrderChance) {
        if (candidateSendAtMs > nodeState.lastScheduledSendAtMs) {
            nodeState.lastScheduledSendAtMs = candidateSendAtMs;
        }
        return candidateSendAtMs;
    }
    const earliestSendAtMs = nodeState.lastScheduledSendAtMs > 0n
        ? nodeState.lastScheduledSendAtMs + BigInt(randomInt(1, 12))
        : candidateSendAtMs;
    const sendAtMs = candidateSendAtMs > earliestSendAtMs ? candidateSendAtMs : earliestSendAtMs;
    nodeState.lastScheduledSendAtMs = sendAtMs;
    return sendAtMs;
}
function rememberRecent(bucket, value, limit) {
    bucket.unshift(value);
    if (bucket.length > limit) {
        bucket.length = limit;
    }
}
function chooseFrom(items) {
    return items[Math.floor(Math.random() * items.length)];
}
function prepareDedupeReplayRetention(options) {
    const scenario = resolveMonitorScenario(options.runtimeConfig.monitorConfig.scenarioId);
    if (!options.runtimeConfig.monitorConfig.enabled ||
        !monitorScenarioIncludesOrderOutage(scenario)) {
        return null;
    }
    const requirement = deriveReplayRetentionRequirement({
        durationMs: options.runtimeConfig.durationMs,
        steadyForMs: options.runtimeConfig.steadyForMs,
    });
    const requiredWindowSeconds = Number((requirement.requiredRetentionMs + 999n) / 1000n);
    const beforeSeconds = Number(options.dedupeGate.getStats().activeWindowSeconds);
    if ((!Number.isFinite(beforeSeconds) || beforeSeconds < requiredWindowSeconds) &&
        typeof options.dedupeGate.updateWindow !== "function") {
        throw new Error(`${scenario?.id ?? "order-outage"} requires ${requiredWindowSeconds}s of dedupe retention, but the adapter does not expose updateWindow(); configure a bounded window that covers outage plus replay or use a durable identity ledger for an unbounded outage`);
    }
    options.dedupeGate.updateWindow?.(requiredWindowSeconds);
    const activeWindowSeconds = Number(options.dedupeGate.getStats().activeWindowSeconds);
    if (!Number.isFinite(activeWindowSeconds) ||
        activeWindowSeconds < requiredWindowSeconds) {
        throw new Error(`${scenario?.id ?? "order-outage"} requires ${requiredWindowSeconds}s of dedupe retention (outage ${requirement.outageDurationMs}ms + replay margin ${requirement.replayMarginMs}ms), but the configured dedupe maximum only provided ${Number.isFinite(activeWindowSeconds) ? `${activeWindowSeconds}s` : "an unreported window"}; increase the bounded dedupe window or use a durable identity ledger for an unbounded outage`);
    }
    return {
        status: "satisfied",
        policy: "outage_horizon_plus_replay_margin",
        outageDurationMs: requirement.outageDurationMs.toString(),
        replayMarginMs: requirement.replayMarginMs.toString(),
        requiredWindowSeconds,
        activeWindowSeconds,
        unboundedOutagePolicy: "durable_identity_ledger_required",
    };
}
function buildAdapterHarnessConfig(argv) {
    const stripped = [];
    let adapterModule = null;
    let maxInFlightSendsPerPeer;
    for (let index = 0; index < argv.length; index += 1) {
        const token = argv[index];
        if (token === "--adapter") {
            adapterModule = argv[index + 1] ?? null;
            index += 1;
            continue;
        }
        if (token.startsWith("--adapter=")) {
            adapterModule = token.slice("--adapter=".length);
            continue;
        }
        if (token === "--adapter-max-in-flight-sends-per-peer") {
            maxInFlightSendsPerPeer = parseAdapterPositiveInteger(token, argv[index + 1]);
            index += 1;
            continue;
        }
        if (token.startsWith("--adapter-max-in-flight-sends-per-peer=")) {
            maxInFlightSendsPerPeer = parseAdapterPositiveInteger("--adapter-max-in-flight-sends-per-peer", token.slice("--adapter-max-in-flight-sends-per-peer=".length));
            continue;
        }
        stripped.push(token);
    }
    const maybeConfig = buildConfig(stripped);
    if ("help" in maybeConfig) {
        return {
            help: true,
            text: [
                "Usage:",
                "  causal-order-testing-adapter-runtime --adapter <specifier> [options]",
                "",
                "Adapter:",
                "  --adapter <specifier>      Package name, subpath, or file path that exports a harness adapter factory",
                "  --adapter-max-in-flight-sends-per-peer <n>",
                "                             Optional per-peer send capacity passed to the adapter",
                "",
                HELP_TEXT,
            ].join("\n"),
        };
    }
    if (!adapterModule || adapterModule.trim().length === 0) {
        throw new Error("Missing required --adapter <specifier>");
    }
    return {
        adapterModule,
        adapterOptions: {
            ...(maxInFlightSendsPerPeer === undefined
                ? {}
                : { maxInFlightSendsPerPeer }),
        },
        runtimeConfig: maybeConfig,
    };
}
function parseAdapterPositiveInteger(label, value) {
    if (value === undefined || value.trim().length === 0) {
        throw new Error(`${label} requires a value`);
    }
    const parsed = Number(value);
    if (!Number.isSafeInteger(parsed) || parsed <= 0) {
        throw new Error(`${label} must be a positive safe integer`);
    }
    return parsed;
}
async function loadAdapterFactory(specifier) {
    const isPathLike = specifier.startsWith(".") ||
        specifier.startsWith("/") ||
        /^[A-Za-z]:[\\/]/.test(specifier) ||
        specifier.startsWith("file://");
    const ref = specifier.startsWith("file://")
        ? specifier
        : isPathLike
            ? pathToFileURL(resolve(process.cwd(), specifier)).href
            : specifier;
    const mod = (await import(ref));
    const factory = mod.createHarnessAdapter ?? mod.default;
    if (typeof factory !== "function") {
        throw new Error(`Adapter module ${specifier} must export createHarnessAdapter() or a default factory`);
    }
    return factory;
}
function createSummary(config, adapterModule, adapterOptions) {
    return {
        outcome: {
            status: "running",
            failure: null,
            verdict: "pending",
            verdictReasons: [],
        },
        artifacts: {
            runDir: config.artifacts.runDir,
            summaryPath: config.artifacts.summaryPath,
            heartbeatPath: config.artifacts.heartbeatPath,
            anomalyPath: config.artifacts.anomalyPath,
            duplicateLeakPath: config.artifacts.duplicateLeakPath,
            lifecyclePath: config.artifacts.lifecyclePath,
            configPath: config.artifacts.configPath,
            monitorHeartbeatPath: config.artifacts.monitorHeartbeatPath,
            monitorHealthPath: config.artifacts.monitorHealthPath,
            monitorReplayPath: config.artifacts.monitorReplayPath,
            monitorSummaryPath: config.artifacts.monitorSummaryPath,
        },
        config: {
            durationMs: config.durationMs.toString(),
            steadyForMs: config.steadyForMs.toString(),
            eventsPerSecond: config.eventsPerSecond,
            chaosMultiplier: config.chaosMultiplier,
            batchSize: config.batchSize,
            maxLateArrivalMs: config.maxLateArrivalMs.toString(),
            maxTailDrainMs: config.maxTailDrainMs.toString(),
            lateArrivalPolicy: config.lateArrivalPolicy,
            reportEveryMs: config.reportEveryMs.toString(),
            timeScale: config.timeScale,
            outputDir: config.outputDir,
            runName: config.runName,
            strict: config.strict,
            allowUnknownOrder: config.allowUnknownOrder,
            detectAnomalies: config.detectAnomalies,
            tieBreaker: config.tieBreaker,
            nodeIds: config.nodeIds,
            model: "transport_adapter",
            adapterModule,
            adapterOptions,
            profileName: config.workloadProfile?.name ?? "unknown",
            profileDescription: config.workloadProfile?.description ?? "",
            profileSource: config.profileSource ?? null,
            pipelineModule: config.pipelineModule ?? null,
            monitorConfig: {
                enabled: config.monitorConfig.enabled,
                moduleSpecifier: config.monitorConfig.moduleSpecifier,
                databasePath: config.monitorConfig.databasePath,
                replayBatchSize: config.monitorConfig.replayBatchSize,
                scenarioId: config.monitorConfig.scenarioId,
            },
        },
        timing: {
            startedAtIso: new Date(config.wallStartMs).toISOString(),
            finishedAtIso: null,
            wallElapsedMs: null,
            simulatedElapsedMs: null,
            interrupted: false,
        },
        transport: {
            receivedEvents: 0,
            receivedByNode: {},
            connectedNodes: {},
            disconnectedPeers: {},
            peerHintsBroadcast: 0,
            nodeStats: {},
            persistedLateArrivals: 0,
            faultEventsByType: {},
            peerStatesByStatus: {},
            errors: 0,
        },
        stream: {
            batches: 0,
            correctionBatches: 0,
            finalBatches: 0,
            orderedEvents: 0,
            anomalies: 0,
            maxWatermarkMs: "0",
            lastWatermarkMs: "0",
            byAnomalyType: {},
            byAnomalySeverity: {},
            byOrderBasis: {},
            byConfidence: {},
        },
        dedupe: {},
        dedupeDecisions: {
            byReason: {},
            byIdentitySource: {},
        },
        monitor: {
            enabled: false,
            moduleSpecifier: null,
            scenarioId: null,
            bufferedEvents: 0,
            forwardedToDedupe: 0,
            normalDeliveriesToDedupe: 0,
            replayDeliveriesToDedupe: 0,
            forwardedToOrder: 0,
            replayState: "idle",
            routingModes: {},
            deliveryModes: {},
            scenarioTransportOutages: 0,
            replayFailureInjected: false,
            lastSnapshot: null,
            lastReplaySnapshot: null,
            operatorSnapshot: null,
            capacitySnapshot: null,
            lifecycleSnapshot: null,
            lifecycleFlush: null,
            operationTracker: null,
            expectedContract: resolveMonitorScenarioContract(config.monitorConfig.enabled, config.monitorConfig.scenarioId),
            analysis: null,
        },
        simulation: {
            generated: 0,
            delivered: 0,
            sent: 0,
            duplicatesInjected: 0,
            sameNodeDependencies: 0,
            crossNodeDependencies: 0,
            remoteHintsReceived: 0,
            maxPendingQueueDepth: 0,
            maxQueueDepth: 0,
            darkWindowsEntered: 0,
            reconnects: 0,
            connectionOpens: 0,
            jitterExtraDelaysApplied: 0,
            jitterSpikeDelaysApplied: 0,
        },
        samples: {
            anomalies: [],
            corrections: [],
        },
    };
}
function finalizeSummary(summary, clock, config, interrupted) {
    const nodeStats = Object.values(summary.transport.nodeStats);
    summary.simulation.delivered = summary.transport.receivedEvents;
    summary.simulation.sameNodeDependencies = sumBy(nodeStats, "sameNodeDependencies");
    summary.simulation.crossNodeDependencies = sumBy(nodeStats, "crossNodeDependencies");
    summary.simulation.remoteHintsReceived = sumBy(nodeStats, "remoteHintsReceived");
    summary.simulation.darkWindowsEntered = sumBy(nodeStats, "darkWindowsEntered");
    summary.simulation.reconnects = sumBy(nodeStats, "reconnects");
    summary.simulation.connectionOpens = sumBy(nodeStats, "connectionOpens");
    summary.simulation.jitterExtraDelaysApplied = sumBy(nodeStats, "jitterExtraDelaysApplied");
    summary.simulation.jitterSpikeDelaysApplied = sumBy(nodeStats, "jitterSpikeDelaysApplied");
    summary.timing.finishedAtIso = new Date().toISOString();
    summary.timing.wallElapsedMs = Date.now() - config.wallStartMs;
    summary.timing.simulatedElapsedMs = (clock.simulationNowMs() - clock.simulatedStartMs).toString();
    summary.timing.interrupted = interrupted;
    if (summary.monitor?.enabled && summary.monitor.lastSnapshot) {
        const reservoir = summary.monitor.lastSnapshot.reservoir ?? {};
        summary.monitor.pendingRows = Number(reservoir.totalPendingRows ?? 0);
        summary.monitor.oldestPendingAgeMs = String(reservoir.oldestPendingAgeMs ?? "0");
        summary.monitor.analysis = summarizeMonitorAnalysis(summary.monitor);
    }
    const verdict = deriveScenarioVerdict(summary, config);
    summary.outcome.verdict = verdict.verdict;
    summary.outcome.verdictReasons = verdict.reasons;
}
function deriveScenarioVerdict(summary, config) {
    if (summary.outcome.status === "failed") {
        return {
            verdict: "invalid_run",
            reasons: ["runtime execution failed before contract validation completed"],
        };
    }
    if (summary.outcome.status === "interrupted") {
        return {
            verdict: "invalid_run",
            reasons: ["runtime execution was interrupted"],
        };
    }
    const reasons = [];
    const duplicateErrors = Number(summary.stream.byAnomalyType.duplicate_event ?? 0);
    const generated = Number(summary.simulation.generated ?? 0);
    const ordered = Number(summary.stream.orderedEvents ?? 0);
    if (config.faultInjection.jitterNodeIds.length > 0 &&
        Number(summary.simulation.jitterExtraDelaysApplied ?? 0) === 0) {
        reasons.push("configured node jitter was not exercised");
    }
    if (config.faultInjection.darkNodeIds.length > 0) {
        if (Number(summary.simulation.darkWindowsEntered ?? 0) === 0) {
            reasons.push("configured node dark window was not exercised");
        }
        if (Number(summary.simulation.reconnects ?? 0) === 0) {
            reasons.push("configured dark node did not reconnect");
        }
    }
    if (!config.monitorConfig.enabled) {
        if (duplicateErrors > 0) {
            reasons.push(`causal-order observed ${duplicateErrors} duplicate_event anomalies`);
        }
        if (ordered !== generated) {
            reasons.push(`ordered ${ordered} events but generated ${generated} unique events`);
        }
        return {
            verdict: reasons.length === 0 ? "pass" : "fail_contract",
            reasons,
        };
    }
    const scenarioId = config.monitorConfig.scenarioId;
    const scenario = resolveMonitorScenario(scenarioId);
    const analysis = summary.monitor.analysis ?? {};
    const sawNormal = Boolean(analysis.sawNormalFlow);
    const sawBypass = Boolean(analysis.sawDedupeBypass);
    const sawBuffer = Boolean(analysis.sawOrderBufferOnly);
    const sawFullOutageBuffer = Boolean(analysis.sawFullOutageBuffer);
    const sawReplay = Boolean(analysis.sawReplayThroughDedupe);
    const endedDrained = Boolean(analysis.endedDrained);
    if (!sawNormal) {
        reasons.push("normal monitor flow was not observed");
    }
    if (scenario === null || scenario.kind === "healthy") {
        if (sawBypass) {
            reasons.push("healthy monitor run unexpectedly used dedupe bypass");
        }
        if (sawBuffer || sawFullOutageBuffer || sawReplay) {
            reasons.push("healthy monitor run unexpectedly buffered or replayed work");
        }
    }
    else {
        if (monitorScenarioIncludesTransport(scenario)) {
            if (Number(summary.monitor.scenarioTransportOutages ?? 0) === 0) {
                reasons.push(`${scenarioId} did not inject a mid-run transport outage`);
            }
            if (Number(summary.transport.peerStatesByStatus.disconnected ?? 0) === 0) {
                reasons.push(`${scenarioId} did not observe a disconnected peer`);
            }
        }
        const includesDedupe = monitorScenarioIncludesDedupeOutage(scenario);
        const includesOrder = monitorScenarioIncludesOrderOutage(scenario);
        if (includesDedupe && !includesOrder) {
            if (!sawBypass) {
                reasons.push(`${scenarioId} did not observe dedupe bypass`);
            }
            if (!endedDrained) {
                reasons.push(`${scenarioId} ended with pending monitor rows`);
            }
            return {
                verdict: reasons.length === 0
                    ? "pass_with_expected_degradation"
                    : "fail_contract",
                reasons: reasons.length === 0
                    ? [
                        `dedupe bypass was exercised; ${duplicateErrors} duplicate_event anomalies were observed outside dedupe`,
                    ]
                    : reasons,
            };
        }
        if (includesOrder) {
            if (includesDedupe) {
                if (!sawFullOutageBuffer) {
                    reasons.push(`${scenarioId} did not observe full-outage buffering`);
                }
            }
            else if (!sawBuffer) {
                reasons.push(`${scenarioId} did not observe order buffering`);
            }
            if (!sawReplay) {
                reasons.push(`${scenarioId} did not observe replay through dedupe`);
            }
            if (sawBypass) {
                reasons.push(`${scenarioId} unexpectedly used dedupe bypass`);
            }
            if (!endedDrained) {
                reasons.push(`${scenarioId} ended with pending monitor rows`);
            }
        }
        else if (sawBypass) {
            reasons.push(`${scenarioId} unexpectedly used dedupe bypass`);
        }
    }
    if (duplicateErrors > 0) {
        reasons.push(`causal-order observed ${duplicateErrors} duplicate_event anomalies`);
    }
    if (ordered !== generated) {
        reasons.push(`ordered ${ordered} events but generated ${generated} unique events`);
    }
    if (scenario?.kind === "replay_retry" &&
        !Boolean(analysis.replayFailureInjected)) {
        reasons.push("replay retry scenario did not inject its expected failure");
    }
    return {
        verdict: reasons.length === 0 ? "pass" : "fail_contract",
        reasons,
    };
}
function resolveMonitorScenarioContract(enabled, scenarioId) {
    if (!enabled) {
        return null;
    }
    const scenario = resolveMonitorScenario(scenarioId);
    if (scenario === null || scenario.kind === "healthy") {
        return {
            expectedRouting: ["normal"],
            bypassPermitted: false,
            bufferingRequired: false,
            replayRequired: false,
            finalDrainRequired: true,
            duplicateErrorsPermitted: false,
        };
    }
    if (monitorScenarioIncludesTransport(scenario) &&
        !monitorScenarioIncludesDedupeOutage(scenario) &&
        !monitorScenarioIncludesOrderOutage(scenario)) {
        return {
            expectedRouting: ["normal"],
            expectedTransportStates: ["disconnected", "connected"],
            bypassPermitted: false,
            bufferingRequired: false,
            replayRequired: false,
            finalDrainRequired: true,
            duplicateErrorsPermitted: false,
        };
    }
    if (monitorScenarioIncludesDedupeOutage(scenario) &&
        !monitorScenarioIncludesOrderOutage(scenario)) {
        return {
            expectedRouting: ["normal", "dedupe_bypass_throttled"],
            ...(monitorScenarioIncludesTransport(scenario)
                ? { expectedTransportStates: ["disconnected", "connected"] }
                : {}),
            bypassPermitted: true,
            bufferingRequired: false,
            replayRequired: false,
            finalDrainRequired: true,
            duplicateErrorsPermitted: true,
        };
    }
    if (monitorScenarioIncludesDedupeOutage(scenario)) {
        return {
            expectedRouting: ["normal", "full_outage_buffer", "replay_through_dedupe"],
            ...(monitorScenarioIncludesTransport(scenario)
                ? { expectedTransportStates: ["disconnected", "connected"] }
                : {}),
            bypassPermitted: false,
            bufferingRequired: true,
            replayRequired: true,
            finalDrainRequired: true,
            duplicateErrorsPermitted: false,
        };
    }
    return {
        expectedRouting: ["normal", "order_buffer_only", "replay_through_dedupe"],
        ...(monitorScenarioIncludesTransport(scenario)
            ? { expectedTransportStates: ["disconnected", "connected"] }
            : {}),
        bypassPermitted: false,
        bufferingRequired: true,
        replayRequired: true,
        finalDrainRequired: true,
        duplicateErrorsPermitted: false,
    };
}
function summarizeMonitorAnalysis(monitor) {
    const routingModes = monitor.routingModes ?? {};
    const deliveryModes = monitor.deliveryModes ?? {};
    const pendingRows = Number(monitor.pendingRows ?? monitor.lastSnapshot?.reservoir?.totalPendingRows ?? 0);
    const retryWaitingRows = Number(monitor.retryWaitingRows ?? monitor.lastSnapshot?.reservoir?.retryWaitingRows ?? 0);
    const replayNextRetryAt = monitor.replayNextRetryAt ?? monitor.lastReplaySnapshot?.nextRetryAt ?? null;
    const replayConsecutiveFailureCount = Number(monitor.replayConsecutiveFailureCount ??
        monitor.lastReplaySnapshot?.consecutiveFailureCount ??
        0);
    const replayState = String(monitor.replayState ?? monitor.lastReplaySnapshot?.state ?? "unknown");
    return {
        sawNormalFlow: Number(routingModes.normal ?? 0) > 0,
        sawDedupeBypass: Number(routingModes.dedupe_bypass_throttled ?? 0) > 0 ||
            Number(deliveryModes.dedupe_bypass_throttled ?? 0) > 0 ||
            Number(monitor.forwardedToOrder ?? 0) > 0,
        sawOrderBufferOnly: Number(routingModes.order_buffer_only ?? 0) > 0,
        sawFullOutageBuffer: Number(routingModes.full_outage_buffer ?? 0) > 0,
        sawReplayThroughDedupe: Number(monitor.replayDeliveriesToDedupe ?? 0) > 0 ||
            Number(routingModes.replay_through_dedupe ?? 0) > 0,
        finalReplayState: replayState,
        endedDrained: pendingRows === 0,
        retryWaitingRows,
        replayNextRetryAt,
        replayConsecutiveFailureCount,
        replayFailureInjected: Boolean(monitor.replayFailureInjected),
        dominantRoutingMode: findDominantMode(routingModes),
        dominantDeliveryMode: findDominantMode(deliveryModes),
    };
}
function findDominantMode(bucket) {
    let winner = null;
    let winnerCount = -1;
    for (const [mode, count] of Object.entries(bucket)) {
        if (count > winnerCount) {
            winner = mode;
            winnerCount = count;
        }
    }
    return winner;
}
function appendHeartbeat(config, summary, clock, dedupeGate, completedNodes, kind = "progress") {
    const memory = process.memoryUsage();
    appendFileSync(config.artifacts.heartbeatPath, `${JSON.stringify({
        timestampIso: new Date().toISOString(),
        kind,
        status: summary.outcome.status,
        wallElapsedMs: Date.now() - config.wallStartMs,
        simulatedElapsedMs: (clock.simulationNowMs() - clock.simulatedStartMs).toString(),
        received: summary.transport.receivedEvents,
        ordered: summary.stream.orderedEvents,
        anomalies: summary.stream.anomalies,
        lateAnomalies: summary.stream.byAnomalyType.late_arrival ?? 0,
        connectedNodes: Object.keys(summary.transport.connectedNodes).length,
        completedNodes,
        dedupe: dedupeGate.getStats(),
        rssBytes: memory.rss,
        heapUsedBytes: memory.heapUsed,
        heapTotalBytes: memory.heapTotal,
    })}\n`, "utf8");
}
function appendMonitorHeartbeat(config, clock, summary, completedNodes, monitorAdapter, kind = "progress") {
    const snapshot = monitorAdapter.getSnapshot();
    appendFileSync(config.artifacts.monitorHeartbeatPath, `${stringifyJson({
        timestampIso: new Date().toISOString(),
        kind,
        wallElapsedMs: Date.now() - config.wallStartMs,
        simulatedElapsedMs: (clock.simulationNowMs() - clock.simulatedStartMs).toString(),
        completedNodes,
        routingMode: snapshot.routingMode ?? null,
        throttleTier: snapshot.throttleTier ?? null,
        replayState: snapshot.replay?.state ?? null,
        pendingRows: snapshot.reservoir?.totalPendingRows ?? null,
        monitor: snapshot,
        transportReceived: summary.transport.receivedEvents,
        ordered: summary.stream.orderedEvents,
    })}\n`, "utf8");
}
function appendMonitorHealth(config, clock, event, details = {}) {
    appendFileSync(config.artifacts.monitorHealthPath, `${stringifyJson({
        timestampIso: new Date().toISOString(),
        event,
        wallElapsedMs: Date.now() - config.wallStartMs,
        simulatedElapsedMs: (clock.simulationNowMs() - clock.simulatedStartMs).toString(),
        ...details,
    })}\n`, "utf8");
}
function appendMonitorReplay(config, clock, details = {}) {
    appendFileSync(config.artifacts.monitorReplayPath, `${stringifyJson({
        timestampIso: new Date().toISOString(),
        wallElapsedMs: Date.now() - config.wallStartMs,
        simulatedElapsedMs: (clock.simulationNowMs() - clock.simulatedStartMs).toString(),
        ...details,
    })}\n`, "utf8");
}
function appendLifecycleEvent(config, clock, event, details = {}) {
    appendFileSync(config.artifacts.lifecyclePath, `${JSON.stringify({
        timestampIso: new Date().toISOString(),
        event,
        wallElapsedMs: Date.now() - config.wallStartMs,
        simulatedElapsedMs: (clock.simulationNowMs() - clock.simulatedStartMs).toString(),
        ...details,
    })}\n`, "utf8");
}
function appendAnomalyRecord(config, summary, record) {
    if (record.type === "late_arrival" &&
        summary.transport.persistedLateArrivals > config.maxLateArrivalSamples) {
        return;
    }
    appendFileSync(config.artifacts.anomalyPath, `${JSON.stringify(record)}\n`, "utf8");
    pushLimited(summary.samples.anomalies, {
        type: record.type,
        severity: record.severity,
        eventId: record.eventId,
        relatedEventIds: record.relatedEventIds ?? [],
        message: record.message,
    }, config.sampleLimit);
}
function serializeError(error) {
    if (error instanceof Error) {
        return {
            name: error.name,
            message: error.message,
            stack: error.stack ?? null,
        };
    }
    return {
        name: "Error",
        message: String(error),
        stack: null,
    };
}
function serializeShutdownFailure(error, fallbackPhase) {
    if (error instanceof TerminalDrainError) {
        return {
            phase: error.phase,
            name: error.name,
            code: error.code,
            message: error.message,
            state: error.state,
        };
    }
    return {
        phase: fallbackPhase,
        name: error instanceof Error ? error.name : "Error",
        code: typeof error === "object" &&
            error !== null &&
            "code" in error &&
            typeof error.code === "string"
            ? error.code
            : null,
        message: `adapter runtime failed during ${fallbackPhase}`,
        state: {},
    };
}
function countInto(bucket, key) {
    bucket[key] = (bucket[key] ?? 0) + 1;
}
function pushLimited(bucket, value, limit) {
    if (bucket.length < limit) {
        bucket.push(value);
    }
}
function sumBy(values, key) {
    return values.reduce((total, entry) => total + Number(entry?.[key] ?? 0), 0);
}
async function waitForDrain(predicate, timeoutMs, label) {
    const startedAt = Date.now();
    while (!predicate()) {
        if (Date.now() - startedAt > timeoutMs) {
            throw new Error(`Timed out waiting for ${label}`);
        }
        await new Promise((resolveDelay) => setTimeout(resolveDelay, 50));
    }
}
main().catch((error) => {
    console.error(formatOperatorError(error));
    process.exitCode = 1;
});

# Changelog

All notable changes to `@causal-order/testing` will be documented in this file.

## 0.3.4

- Added `--adapter-max-in-flight-sends-per-peer` to adapter-runtime tests and
  retained the configured value in run evidence, allowing transport-outage
  qualification to size the existing pressure guard without reducing load.

## 0.3.3

- Applied `--jitter-nodes` and `--dark-nodes` in adapter-runtime runs, including
  real adapter connectivity transitions, observable node-fault counters, and
  verdict gates that reject configured-but-unexercised node faults.

## 0.3.2

- Added canonical transport+dedupe, transport+causal-order, and
  transport+dedupe+causal-order monitor scenarios for adapter-runtime tests.
- Replaced shutdown-only transport evidence with explicit mid-run disconnect
  and reconnect injection through the published transport testing adapter.
- Added scenario-aware verdict gates that require injected transport evidence
  plus the intended bypass, buffering, replay, and final-drain behavior.
- Added an accelerated composition contract covering the transport-only and
  all three overlapping transport scenarios.
- Kept packed-stack qualification compatible with both array-shaped and
  package-keyed `npm pack --json` output.

## 0.3.1

- Ordered shutdown so ingress and the transport callback barrier complete before terminal monitor recovery, lifecycle draining, ordering closure, evidence capture, and verdict derivation.
- Added bounded recovery/no-progress handling and evidence-preserving failure cleanup without weakening pending-row or generated-versus-ordered assertions.
- Added deterministic coverage for delivery during transport stop, terminal monitor reconciliation, post-stop callback violations, shutdown phase ordering, and failure propagation.
- Updated the supported transport line to `0.2.x`, whose acknowledged-delivery and bounded-stop contract is required for exact end-to-end drain qualification.
- Updated the supported monitor line to `0.6.x` and qualified the clean dependency graph with monitor `0.6.0`, transport `0.2.0`, dedupe `1.2.0`, and core `1.0.x`.
- Added structured shutdown evidence to adapter summaries, including phase and milestone history, transport-barrier counters, terminal monitor and ordering state, interruption details, and retained cleanup failures.
- Expanded packed-stack qualification across healthy, transport-outage, dedupe-bypass, order-outage, dual-outage, replay-retry, and intentional negative-control scenarios on Node 22 and Node 24.

## 0.3.0

- Raised the runtime floor to Node `>=22.13.0`, updated CI to Node 22 and Node 24 LTS, and aligned development with monitor `0.5.x` and built-in `node:sqlite`.
- Added explicit dedupe-bypass behavior while preserving `monitor-dedupe-bypass` and `monitor-recovery-through-dedupe` as compatibility aliases for the published monitor scenario catalog; `monitor-order-outage` remains the canonical replay-through-dedupe validation path.
- Added serialized, bounded ownership for asynchronous monitor ingestion, health, and recovery operations so shutdown waits before closing the causal-order input queue.
- Added scenario-aware adapter verdicts that distinguish a clean pass, expected bypass degradation, contract failure, and invalid execution across healthy, transport, dedupe, order, dual-outage, and retry scenarios.
- Aligned development and peer contracts with `causal-order@1.0.x`, `@causal-order/dedupe@1.2.x`, `@causal-order/monitor@0.5.x`, and `@causal-order/transport@0.1.x`.
- Qualified the installed and clean packed-consumer stack against `@causal-order/transport@0.1.3` while retaining the supported transport `0.1.x` peer floor at `0.1.2`.
- Added structured dedupe reason and identity-source evidence, versioned monitor operator/capacity/lifecycle snapshots, bounded lifecycle flushing, deterministic installed-stack contracts, and clean packed-consumer validation.
- Streamlined the package README around the npm consumer contract and moved the detailed adapter, artifact, CLI, scenario, and operational reference into `docs/integration-reference.md` without removing historical release records.

## 0.2.6

- Added a dedicated `monitor-replay-retry-backoff` scenario that forces a replay delivery failure so monitor retry/backoff behavior can be observed through the harness.
- Extended monitor-aware summary and compare reporting with retry-waiting backlog, replay failure streak, next-retry visibility, and injected replay-failure markers.

## 0.2.5

- Extended `causal-order-testing-compare` with monitor-aware recovery metrics so two outage runs can be contrasted by buffering posture, replay lifecycle, drained completion, and scenario transitions.
- Added replay-path and replay-session comparison output derived from `monitor-replay.ndjson`, plus component transition summaries derived from `monitor-health.ndjson`.

## 0.2.4

- Added compact replay-phase analysis to monitor-aware adapter-run summaries so healthy flow, dedupe bypass, order buffering, replay-through-dedupe, and drained completion are visible without reading raw NDJSON artifacts.
- Extended `causal-order-testing-summary` to reconstruct replay path and outage transitions automatically from `monitor-replay.ndjson` and `monitor-health.ndjson`.

## 0.2.3

- Added an optional monitor adapter boundary to the shared pipeline provider contract so `@causal-order/monitor` can participate in the harness without replacing the existing clock, dedupe, ordering, or transport seams.
- Extended runtime config and artifact planning with monitor-aware settings and outputs, including `monitor-heartbeats.ndjson`, `monitor-health.ndjson`, `monitor-replay.ndjson`, and `monitor-summary.json`.
- Updated the default pipeline to instantiate `TransportMonitorAdapter` dynamically when monitor mode is enabled, while preserving the old non-monitor flow as the default path.
- Wired the adapter runtime and deployment collector to route ingress through monitor when enabled and to emit monitor-aware health, routing, and replay telemetry.
- Extended human-readable run summaries with monitor state, routing, replay, and pending-backlog visibility.
- Added first monitor scenario profiles for healthy buffering, transport outage, dedupe outage, order outage, dual outage, and replay-through-dedupe recovery.
- Declared `@causal-order/monitor` as a peer dependency for the testing package.

## 0.2.2

- Added wall-clock summary compatibility for `@causal-order/transport` artifacts under `artifacts/transport-runs/`, including the nested timing, generator, ordering, process, and heartbeat fields used by that harness.
- Verified the wall-clock compatibility fix against a real `4h` `typical-real-world-mesh` transport run.
- Updated the README so the published reporting flow is documented for both adapter-runtime artifacts and `/transport` wall-clock artifacts.

## 0.2.1

- Updated the adapter-run summary logic so dedupe traffic is judged against `accepted + dropped == delivered` when dedupe telemetry is available.
- Updated the adapter-run summary verdict to compare final ordered output against accepted events instead of raw delivered traffic when dedupe telemetry is available.
- Updated run comparison logic so duplicate leakage is computed from unsuppressed duplicates and unexplained delivery gaps instead of raw `delivered - generated`.
- Verified the reporting fix against real `@causal-order/transport/testing` adapter runs, including the published consumer path.
- Clarified the README around the latest `@causal-order/transport/testing` entrypoint and the intended interpretation order for adapter-run summaries.
- Added a `transport-sanity-mesh` profile for low-noise transport validation runs with no intentional duplicate injection or sequence reordering.

## 0.2.0

- Added a pluggable pipeline provider boundary so `causal-order` and `@causal-order/dedupe` can be supplied through harness adapters instead of being hard-wired into the harness core.
- Added shared pipeline provider TypeScript interfaces and exported them from the package entrypoint for custom clock, dedupe, and ordering integrations.
- Added dynamic pipeline loading with a new `--pipeline <specifier>` runtime option while keeping the current `causal-order` and `@causal-order/dedupe` behavior as the default provider.
- Refactored the deployment and adapter runtimes to consume the new pipeline provider contract across standard, rejoin, and adapter-driven execution paths.
- Added focused package subpaths for narrower stack surfaces: `@causal-order/testing/transport`, `@causal-order/testing/dedupe`, `@causal-order/testing/order`, and `@causal-order/testing/providers/default`.
- Aligned the package metadata and docs around the full-stack peer dependency model for `@causal-order/transport`, `@causal-order/dedupe`, and `causal-order`.

## 0.1.1

- Added an adapter-driven runtime CLI so transport implementations can be exercised through the same deployment-style harness.
- Exported shared adapter TypeScript interfaces for custom harness integrations.
- Added a loopback adapter smoke path and packaged CLI wrapper coverage for the new adapter runtime entrypoint.

## 0.1.0

- Extracted the deployment-style runtime harness into a standalone package.
- Added package-relative workload profile loading for installed usage.
- Added CLI entrypoints for runtime execution and artifact summaries.
- Added npm-facing package metadata, keywords, and publish configuration for `@causal-order/testing`.
- Added wrapper executables under `bin/` so packaged CLI commands install cleanly for end users.
- Added a lightweight smoke test and release-check scripts for first-user and first-publish validation.
- Reworked the README to be more package-facing while retaining maintainer and repo-setup guidance.
- Added GitHub Actions CI and npm publish workflow scaffolding.

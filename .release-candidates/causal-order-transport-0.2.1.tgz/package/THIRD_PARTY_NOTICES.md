# Third-Party Notices

This package includes vendored code from the following third-party project:

## ws

- Package: `ws`
- Upstream version: `8.21.1`
- Upstream repository: `https://github.com/websockets/ws`
- License: `MIT`

The vendored runtime files are included under `src/vendor/ws/`. The upstream
license text is preserved at `src/vendor/ws/LICENSE`.

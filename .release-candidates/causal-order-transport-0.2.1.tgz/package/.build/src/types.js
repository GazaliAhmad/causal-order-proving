export class TransportOperationError extends Error {
    code;
    peerId;
    transmissionId;
    constructor(code, message, options = {}) {
        super(message, options.cause === undefined ? undefined : { cause: options.cause });
        this.name = "TransportOperationError";
        this.code = code;
        this.peerId = options.peerId;
        this.transmissionId = options.transmissionId;
    }
}

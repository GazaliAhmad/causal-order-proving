import VendoredWebSocket, { WebSocketServer as VendoredWebSocketServer } from "../vendor/ws/wrapper.mjs";
export const WebSocket = VendoredWebSocket;
export const WebSocketServer = VendoredWebSocketServer;
export default WebSocket;

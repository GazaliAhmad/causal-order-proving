export const TRANSPORT_WIRE_SCHEMA = "causal-order/transport";
export const TRANSPORT_WIRE_VERSION = 1;
function eventToWireRecord(event) {
    return {
        ...event,
        sequence: event.sequence?.toString(),
        clock: {
            ...event.clock,
            physicalTimeMs: event.clock.physicalTimeMs.toString(),
        },
        ingestedAt: event.ingestedAt?.toString(),
    };
}
function stringifyWireValue(value) {
    try {
        return JSON.stringify(value);
    }
    catch (cause) {
        throw new Error("Transport event could not be serialized as JSON", { cause });
    }
}
export function serializeTransportEventMessage(event) {
    return stringifyWireValue(eventToWireRecord(event));
}
export function serializeTransportEventFrame(event, transmissionId) {
    return stringifyWireValue({
        schema: TRANSPORT_WIRE_SCHEMA,
        version: TRANSPORT_WIRE_VERSION,
        type: "event",
        transmissionId,
        event: eventToWireRecord(event),
    });
}
export function serializeTransportDeliveryResultFrame(frame) {
    return stringifyWireValue({
        schema: TRANSPORT_WIRE_SCHEMA,
        version: TRANSPORT_WIRE_VERSION,
        type: "delivery-result",
        ...frame,
    });
}
function isRecord(value) {
    return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}
export function parseTransportWireMessage(value) {
    if (!isRecord(value) || value.schema === undefined) {
        return { kind: "legacy-event", event: value };
    }
    if (value.schema !== TRANSPORT_WIRE_SCHEMA ||
        value.version !== TRANSPORT_WIRE_VERSION) {
        throw new Error("Unsupported transport wire schema or version");
    }
    if (typeof value.transmissionId !== "string" || value.transmissionId.length === 0) {
        throw new Error("Transport frame must include transmissionId");
    }
    if (value.type === "event") {
        if (!isRecord(value.event)) {
            throw new Error("Transport event frame must include an event object");
        }
        return { kind: "frame", frame: value };
    }
    if (value.type === "delivery-result") {
        if (!["accepted", "refused", "failed"].includes(value.outcome)) {
            throw new Error("Transport delivery result has an invalid outcome");
        }
        if (value.code !== undefined && typeof value.code !== "string") {
            throw new Error("Transport delivery result code must be a string");
        }
        if (value.detail !== undefined && typeof value.detail !== "string") {
            throw new Error("Transport delivery result detail must be a string");
        }
        return { kind: "frame", frame: value };
    }
    throw new Error("Unsupported transport frame type");
}

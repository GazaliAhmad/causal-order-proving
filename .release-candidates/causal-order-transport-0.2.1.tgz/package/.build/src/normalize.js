function asRecord(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
        throw new Error("Transport message must be a JSON object");
    }
    return value;
}
function asString(value) {
    return typeof value === "string" && value.trim().length > 0 ? value : undefined;
}
const CANONICAL_INTEGER = /^-?(0|[1-9][0-9]*)$/;
function toBigInt(value, label, nonNegative = false) {
    let parsed;
    if (typeof value === "bigint") {
        parsed = value;
    }
    else if (typeof value === "number") {
        if (!Number.isSafeInteger(value)) {
            throw new Error(`${label} must be a safe integer`);
        }
        parsed = BigInt(value);
    }
    else if (typeof value === "string") {
        const trimmed = value.trim();
        if (!CANONICAL_INTEGER.test(trimmed)) {
            throw new Error(`${label} must be a canonical integer string`);
        }
        parsed = BigInt(trimmed);
    }
    else {
        throw new Error(`${label} must be a bigint-compatible safe integer`);
    }
    if (nonNegative && parsed < 0n) {
        throw new Error(`${label} must be non-negative`);
    }
    return parsed;
}
function toLogicalCounter(value) {
    if (value === undefined) {
        return 0;
    }
    let parsed;
    if (typeof value === "number") {
        parsed = value;
    }
    else if (typeof value === "string") {
        const trimmed = value.trim();
        if (!/^(0|[1-9][0-9]*)$/.test(trimmed)) {
            throw new Error("clock.logicalCounter must be a non-negative safe integer");
        }
        parsed = Number(trimmed);
    }
    else {
        throw new Error("clock.logicalCounter must be a non-negative safe integer");
    }
    if (!Number.isSafeInteger(parsed) || parsed < 0) {
        throw new Error("clock.logicalCounter must be a non-negative safe integer");
    }
    return parsed;
}
function optionalString(value, label) {
    if (value === undefined) {
        return undefined;
    }
    const parsed = asString(value);
    if (!parsed) {
        throw new Error(`${label} must be a non-empty string when provided`);
    }
    return parsed;
}
function optionalStringArray(value, label) {
    if (value === undefined) {
        return undefined;
    }
    if (!Array.isArray(value)) {
        throw new Error(`${label} must be an array of non-empty strings when provided`);
    }
    return value.map((entry, index) => {
        const parsed = asString(entry);
        if (!parsed) {
            throw new Error(`${label}[${index}] must be a non-empty string`);
        }
        return parsed;
    });
}
function resolveClock(nodeId, record) {
    if ("clock" in record) {
        const clock = asRecord(record.clock);
        if (clock.physicalTimeMs !== undefined) {
            return {
                physicalTimeMs: toBigInt(clock.physicalTimeMs, "clock.physicalTimeMs", true),
                logicalCounter: toLogicalCounter(clock.logicalCounter ?? clock.logical ?? clock.lc),
                nodeId: asString(clock.nodeId) ?? nodeId,
            };
        }
    }
    const timestamp = record.ts ?? record.timestampMs ?? record.physicalTimeMs;
    if (timestamp !== undefined) {
        return {
            physicalTimeMs: toBigInt(timestamp, "timestamp", true),
            logicalCounter: toLogicalCounter(record.logicalCounter ?? record.logical ?? record.lc),
            nodeId,
        };
    }
    throw new Error("Transport message must include clock.physicalTimeMs or a timestamp alias");
}
export function createEventId(nodeId, sequence) {
    return `${nodeId}-${String(sequence).padStart(12, "0")}`;
}
export function normalizeTransportEventMessage(value) {
    const record = asRecord(value);
    const nodeId = asString(record.nodeId ?? record.node ?? record.sourceNodeId);
    if (!nodeId) {
        throw new Error("Transport message must include nodeId or node");
    }
    const sequenceValue = record.sequence ?? record.seq;
    const sequence = sequenceValue !== undefined
        ? toBigInt(sequenceValue, "sequence", true)
        : undefined;
    const payload = (record.payload ?? record.body ?? {});
    const id = asString(record.id) ??
        (sequence !== undefined ? createEventId(nodeId, sequence) : undefined);
    if (!id) {
        throw new Error("Transport message must include id or sequence/seq");
    }
    return {
        id,
        nodeId,
        sequence,
        clock: resolveClock(nodeId, record),
        payload,
        partition: optionalString(record.partition, "partition"),
        parentEventId: optionalString(record.parentEventId, "parentEventId"),
        dependencyEventIds: optionalStringArray(record.dependencyEventIds, "dependencyEventIds"),
        traceId: optionalString(record.traceId, "traceId"),
        ingestedAt: record.ingestedAt !== undefined
            ? toBigInt(record.ingestedAt, "ingestedAt", true)
            : undefined,
    };
}

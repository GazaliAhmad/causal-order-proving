import type { NormalizedTransportEvent } from "./types.js";
export declare function createEventId(nodeId: string, sequence: bigint | string | number): string;
export declare function normalizeTransportEventMessage<T = Record<string, unknown>>(value: unknown): NormalizedTransportEvent<T>;

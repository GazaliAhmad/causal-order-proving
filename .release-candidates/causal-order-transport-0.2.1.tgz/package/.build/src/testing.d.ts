import type { NormalizedTransportEvent, TransportError, TransportPeerState } from "./types.js";
type HarnessEvent = NormalizedTransportEvent<Record<string, unknown>>;
type HarnessEventContext = {
    peerId?: string;
    connectionId?: string;
    receivedAtMs?: bigint;
    rawMessage?: unknown;
};
type HarnessEventHandler = (event: HarnessEvent, context: HarnessEventContext) => void;
type HarnessPeerStateHandler = (state: TransportPeerState) => void;
type HarnessErrorHandler = (error: TransportError) => void;
type HarnessAdapter = {
    start(): Promise<void>;
    stop(): Promise<void>;
    send(event: HarnessEvent): Promise<void>;
    setNodeConnectivity(nodeId: string, state: "connected" | "disconnected"): Promise<void>;
    onEvent(handler: HarnessEventHandler): () => void;
    onPeerState(handler: HarnessPeerStateHandler): () => void;
    onError(handler: HarnessErrorHandler): () => void;
};
type HarnessAdapterOptions = {
    nodeIds: string[];
};
export declare function createHarnessAdapter(options: HarnessAdapterOptions): Promise<HarnessAdapter>;
export default createHarnessAdapter;

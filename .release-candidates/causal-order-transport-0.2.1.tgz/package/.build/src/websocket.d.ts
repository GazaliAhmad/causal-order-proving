import type { NormalizedTransportEvent, TransportContract, TransportDeliveryHandler, TransportErrorHandler, TransportEventHandler, TransportLifecycleState, TransportPeerStateHandler, WebSocketJsonTransportOptions } from "./types.js";
export declare class WebSocketJsonTransport<T = Record<string, unknown>> implements TransportContract<T> {
    #private;
    constructor(options: WebSocketJsonTransportOptions<T>);
    get state(): TransportLifecycleState;
    start(): Promise<void>;
    stop(): Promise<void>;
    send(event: NormalizedTransportEvent<T>, targetPeerId?: string): Promise<void>;
    onDelivery(handler: TransportDeliveryHandler<T>): () => void;
    onEvent(handler: TransportEventHandler<T>): () => void;
    onPeerState(handler: TransportPeerStateHandler): () => void;
    onError(handler: TransportErrorHandler): () => void;
}

import { randomUUID } from "node:crypto";
import { TransportOperationError } from "./types.js";
import { WebSocket, WebSocketServer } from "./internal/ws-runtime.js";
import { normalizeTransportEventMessage } from "./normalize.js";
import { parseTransportWireMessage, serializeTransportDeliveryResultFrame, serializeTransportEventFrame, } from "./internal/wire-message.js";
const DEFAULT_ACKNOWLEDGMENT_TIMEOUT_MS = 5_000;
const DEFAULT_CONNECTION_TIMEOUT_MS = 5_000;
const DEFAULT_DELIVERY_TIMEOUT_MS = 5_000;
const DEFAULT_SHUTDOWN_TIMEOUT_MS = 10_000;
const DEFAULT_MAX_IN_FLIGHT_SENDS = 10_000;
const DEFAULT_MAX_IN_FLIGHT_SENDS_PER_PEER = 2_000;
const DEFAULT_MAX_IN_FLIGHT_RECEIVES = 10_000;
const DEFAULT_MAX_IN_FLIGHT_RECEIVES_PER_PEER = 2_000;
const DEFAULT_MAX_BUFFERED_AMOUNT_BYTES = 16 * 1024 * 1024;
function positiveInteger(value, fallback, label) {
    const resolved = value ?? fallback;
    if (!Number.isSafeInteger(resolved) || resolved <= 0) {
        throw new Error(`${label} must be a positive safe integer`);
    }
    return resolved;
}
function errorDetail(error) {
    return error instanceof Error ? error.message : String(error);
}
export class WebSocketJsonTransport {
    #options;
    #server = null;
    #client = null;
    #peers = new Map();
    #eventHandlers = new Set();
    #peerHandlers = new Set();
    #errorHandlers = new Set();
    #deliveryHandler = null;
    #state = "idle";
    #startPromise = null;
    #stopPromise = null;
    #pendingSends = new Map();
    #receiveTasks = new Set();
    #receiveCountsByPeer = new Map();
    #idleWaiters = new Set();
    #acknowledgmentTimeoutMs;
    #connectionTimeoutMs;
    #deliveryTimeoutMs;
    #shutdownTimeoutMs;
    #maxInFlightSends;
    #maxInFlightSendsPerPeer;
    #maxInFlightReceives;
    #maxInFlightReceivesPerPeer;
    #maxBufferedAmountBytes;
    constructor(options) {
        this.#options = options;
        this.#acknowledgmentTimeoutMs = positiveInteger(options.acknowledgmentTimeoutMs, DEFAULT_ACKNOWLEDGMENT_TIMEOUT_MS, "acknowledgmentTimeoutMs");
        this.#connectionTimeoutMs = positiveInteger(options.connectionTimeoutMs, DEFAULT_CONNECTION_TIMEOUT_MS, "connectionTimeoutMs");
        this.#deliveryTimeoutMs = positiveInteger(options.deliveryTimeoutMs, DEFAULT_DELIVERY_TIMEOUT_MS, "deliveryTimeoutMs");
        this.#shutdownTimeoutMs = positiveInteger(options.shutdownTimeoutMs, DEFAULT_SHUTDOWN_TIMEOUT_MS, "shutdownTimeoutMs");
        this.#maxInFlightSends = positiveInteger(options.maxInFlightSends, DEFAULT_MAX_IN_FLIGHT_SENDS, "maxInFlightSends");
        this.#maxInFlightSendsPerPeer = positiveInteger(options.maxInFlightSendsPerPeer, DEFAULT_MAX_IN_FLIGHT_SENDS_PER_PEER, "maxInFlightSendsPerPeer");
        this.#maxInFlightReceives = positiveInteger(options.maxInFlightReceives, DEFAULT_MAX_IN_FLIGHT_RECEIVES, "maxInFlightReceives");
        this.#maxInFlightReceivesPerPeer = positiveInteger(options.maxInFlightReceivesPerPeer, DEFAULT_MAX_IN_FLIGHT_RECEIVES_PER_PEER, "maxInFlightReceivesPerPeer");
        this.#maxBufferedAmountBytes = positiveInteger(options.maxBufferedAmountBytes, DEFAULT_MAX_BUFFERED_AMOUNT_BYTES, "maxBufferedAmountBytes");
    }
    get state() {
        return this.#state;
    }
    async start() {
        if (this.#state === "starting" && this.#startPromise) {
            return this.#startPromise;
        }
        if (this.#state === "started" || this.#state === "stopping") {
            throw new TransportOperationError("TRANSPORT_INVALID_STATE", "Transport is already started or starting");
        }
        this.#state = "starting";
        const operation = (async () => {
            try {
                if (this.#options.mode === "server") {
                    await this.#startServer();
                }
                else {
                    await this.#startClient();
                }
                if (this.#state === "starting") {
                    this.#state = "started";
                }
            }
            catch (error) {
                this.#state = "failed";
                throw error;
            }
        })();
        this.#startPromise = operation;
        try {
            await operation;
        }
        finally {
            if (this.#startPromise === operation) {
                this.#startPromise = null;
            }
        }
    }
    async stop() {
        if (this.#state === "stopping" && this.#stopPromise) {
            return this.#stopPromise;
        }
        if (this.#state === "idle" || this.#state === "stopped") {
            this.#state = "stopped";
            return;
        }
        this.#state = "stopping";
        const operation = this.#performStop();
        this.#stopPromise = operation;
        try {
            await operation;
        }
        finally {
            if (this.#stopPromise === operation) {
                this.#stopPromise = null;
            }
        }
    }
    async send(event, targetPeerId) {
        if (this.#state !== "started") {
            throw new TransportOperationError("TRANSPORT_INVALID_STATE", `Transport cannot send while ${this.#state}`);
        }
        const targets = targetPeerId
            ? [this.#requirePeer(targetPeerId)]
            : [...this.#peers.values()];
        const results = await Promise.allSettled(targets.map((peer) => this.#sendToPeer(peer, event)));
        const failures = results
            .map((result, index) => ({ result, peerId: targets[index].peerId }))
            .filter((entry) => entry.result.status === "rejected");
        if (failures.length === 1) {
            throw failures[0].result.reason;
        }
        if (failures.length > 1) {
            throw new TransportOperationError("TRANSPORT_SEND_FAILED", `Transport broadcast failed for ${failures.length} peers: ${failures.map(({ peerId }) => peerId).join(", ")}`, {
                cause: new AggregateError(failures.map(({ result }) => result.reason), "Transport broadcast failures"),
            });
        }
    }
    onDelivery(handler) {
        if (this.#deliveryHandler) {
            throw new Error("Transport already has a primary delivery handler");
        }
        this.#deliveryHandler = handler;
        return () => {
            if (this.#deliveryHandler === handler) {
                this.#deliveryHandler = null;
            }
        };
    }
    onEvent(handler) {
        this.#eventHandlers.add(handler);
        return () => this.#eventHandlers.delete(handler);
    }
    onPeerState(handler) {
        this.#peerHandlers.add(handler);
        return () => this.#peerHandlers.delete(handler);
    }
    onError(handler) {
        this.#errorHandlers.add(handler);
        return () => this.#errorHandlers.delete(handler);
    }
    async #performStop() {
        let stopError = null;
        try {
            if (this.#startPromise) {
                await this.#startPromise.catch(() => undefined);
            }
            await this.#waitForIdle(this.#shutdownTimeoutMs);
        }
        catch (error) {
            stopError =
                error instanceof Error
                    ? error
                    : new TransportOperationError("TRANSPORT_SHUTDOWN_TIMEOUT", "Transport shutdown failed", { cause: error });
            this.#failAllPending(stopError);
        }
        try {
            await this.#closeResources();
        }
        catch (error) {
            stopError ??= error instanceof Error ? error : new Error(String(error));
        }
        finally {
            this.#state = "stopped";
            this.#notifyIdle();
        }
        if (stopError) {
            throw stopError;
        }
    }
    #requirePeer(peerId) {
        const peer = this.#peers.get(peerId);
        if (!peer) {
            throw new TransportOperationError("TRANSPORT_UNKNOWN_PEER", `Unknown peer "${peerId}"`, { peerId });
        }
        return peer;
    }
    #sendToPeer(peer, event) {
        if (peer.socket.readyState !== WebSocket.OPEN) {
            throw new TransportOperationError("TRANSPORT_PEER_NOT_OPEN", `Transport peer "${peer.peerId}" is not open`, { peerId: peer.peerId });
        }
        if (peer.socket.bufferedAmount > this.#maxBufferedAmountBytes) {
            throw new TransportOperationError("TRANSPORT_SEND_PRESSURE", `Transport peer "${peer.peerId}" exceeded the send buffer limit`, { peerId: peer.peerId });
        }
        const pendingForPeer = [...this.#pendingSends.values()].filter((pending) => pending.peerId === peer.peerId).length;
        if (this.#pendingSends.size >= this.#maxInFlightSends ||
            pendingForPeer >= this.#maxInFlightSendsPerPeer) {
            throw new TransportOperationError("TRANSPORT_SEND_PRESSURE", `Transport in-flight send limit reached for peer "${peer.peerId}"`, { peerId: peer.peerId });
        }
        const transmissionId = randomUUID();
        const message = serializeTransportEventFrame(event, transmissionId);
        return new Promise((resolve, reject) => {
            const timer = setTimeout(() => {
                this.#settlePendingSend(transmissionId, new TransportOperationError("TRANSPORT_ACK_TIMEOUT", `Timed out waiting for delivery acknowledgment from "${peer.peerId}"`, { peerId: peer.peerId, transmissionId }));
            }, this.#acknowledgmentTimeoutMs);
            this.#pendingSends.set(transmissionId, {
                peerId: peer.peerId,
                transmissionId,
                resolve,
                reject,
                timer,
            });
            try {
                peer.socket.send(message, (error) => {
                    if (error) {
                        this.#settlePendingSend(transmissionId, new TransportOperationError("TRANSPORT_SEND_FAILED", `Failed to write transmission to "${peer.peerId}"`, { peerId: peer.peerId, transmissionId, cause: error }));
                    }
                });
            }
            catch (error) {
                this.#settlePendingSend(transmissionId, new TransportOperationError("TRANSPORT_SEND_FAILED", `Failed to write transmission to "${peer.peerId}"`, { peerId: peer.peerId, transmissionId, cause: error }));
            }
        });
    }
    #settlePendingSend(transmissionId, error) {
        const pending = this.#pendingSends.get(transmissionId);
        if (!pending) {
            return;
        }
        this.#pendingSends.delete(transmissionId);
        clearTimeout(pending.timer);
        if (error) {
            pending.reject(error);
        }
        else {
            pending.resolve();
        }
        this.#notifyIdle();
    }
    #failAllPending(error) {
        for (const transmissionId of [...this.#pendingSends.keys()]) {
            this.#settlePendingSend(transmissionId, error);
        }
    }
    #failPendingForPeer(peerId) {
        for (const pending of [...this.#pendingSends.values()]) {
            if (pending.peerId === peerId) {
                this.#settlePendingSend(pending.transmissionId, new TransportOperationError("TRANSPORT_CONNECTION_LOST", `Connection to transport peer "${peerId}" closed before acknowledgment`, { peerId, transmissionId: pending.transmissionId }));
            }
        }
    }
    #queueSocketMessage(peer, raw) {
        const peerReceiveCount = this.#receiveCountsByPeer.get(peer.peerId) ?? 0;
        const pressured = this.#receiveTasks.size >= this.#maxInFlightReceives ||
            peerReceiveCount >= this.#maxInFlightReceivesPerPeer;
        const task = this.#handleSocketMessage(peer, raw, pressured);
        this.#receiveTasks.add(task);
        this.#receiveCountsByPeer.set(peer.peerId, peerReceiveCount + 1);
        void task.finally(() => {
            this.#receiveTasks.delete(task);
            const remaining = (this.#receiveCountsByPeer.get(peer.peerId) ?? 1) - 1;
            if (remaining <= 0) {
                this.#receiveCountsByPeer.delete(peer.peerId);
            }
            else {
                this.#receiveCountsByPeer.set(peer.peerId, remaining);
            }
            this.#notifyIdle();
        });
    }
    async #handleSocketMessage(peer, raw, pressured) {
        let parsed;
        try {
            parsed = JSON.parse(String(raw));
            const decoded = parseTransportWireMessage(parsed);
            if (decoded.kind === "legacy-event") {
                if (this.#state !== "started" || pressured) {
                    return;
                }
                await this.#deliverEvent(peer, decoded.event, parsed);
                return;
            }
            if (decoded.frame.type === "delivery-result") {
                this.#handleDeliveryResult(peer, decoded.frame);
                return;
            }
            if (this.#state !== "started") {
                await this.#sendDeliveryResult(peer, {
                    transmissionId: decoded.frame.transmissionId,
                    outcome: "failed",
                    code: "TRANSPORT_INVALID_STATE",
                    detail: `Receiver is ${this.#state}`,
                });
                return;
            }
            if (pressured) {
                await this.#sendDeliveryResult(peer, {
                    transmissionId: decoded.frame.transmissionId,
                    outcome: "refused",
                    code: "TRANSPORT_RECEIVE_PRESSURE",
                    detail: "Receiver in-flight delivery limit reached",
                });
                return;
            }
            await this.#deliverAcknowledgedEvent(peer, decoded.frame, parsed);
        }
        catch (error) {
            this.#emitError({
                code: "TRANSPORT_PROTOCOL_ERROR",
                peerId: peer.peerId,
                connectionId: peer.connectionId,
                detail: errorDetail(error),
                cause: error,
            });
        }
    }
    #handleDeliveryResult(peer, frame) {
        const pending = this.#pendingSends.get(frame.transmissionId);
        if (!pending) {
            return;
        }
        if (pending.peerId !== peer.peerId) {
            this.#settlePendingSend(frame.transmissionId, new TransportOperationError("TRANSPORT_PROTOCOL_ERROR", "Delivery result arrived from the wrong peer", { peerId: peer.peerId, transmissionId: frame.transmissionId }));
            return;
        }
        if (frame.outcome === "accepted") {
            this.#settlePendingSend(frame.transmissionId);
            return;
        }
        this.#settlePendingSend(frame.transmissionId, new TransportOperationError(frame.outcome === "refused"
            ? "TRANSPORT_DELIVERY_REFUSED"
            : "TRANSPORT_DELIVERY_FAILED", frame.detail ?? `Remote delivery ${frame.outcome}`, { peerId: peer.peerId, transmissionId: frame.transmissionId }));
    }
    async #deliverAcknowledgedEvent(peer, frame, rawMessage) {
        try {
            const result = await this.#deliverEvent(peer, frame.event, rawMessage);
            if (result && result.outcome === "refused") {
                await this.#sendDeliveryResult(peer, {
                    transmissionId: frame.transmissionId,
                    outcome: "refused",
                    code: result.code ?? "TRANSPORT_DELIVERY_REFUSED",
                    detail: result.detail ?? "Primary delivery refused the event",
                });
                return;
            }
            await this.#sendDeliveryResult(peer, {
                transmissionId: frame.transmissionId,
                outcome: "accepted",
            });
        }
        catch (error) {
            await this.#sendDeliveryResult(peer, {
                transmissionId: frame.transmissionId,
                outcome: "failed",
                code: error instanceof TransportOperationError
                    ? error.code
                    : "TRANSPORT_DELIVERY_FAILED",
                detail: errorDetail(error),
            }).catch(() => undefined);
        }
    }
    async #deliverEvent(peer, message, rawMessage) {
        const normalizer = this.#options.normalizeMessage ?? normalizeTransportEventMessage;
        const event = normalizer(message);
        const context = {
            peerId: peer.peerId,
            connectionId: peer.connectionId,
            receivedAtMs: BigInt(Date.now()),
            mode: this.#options.mode,
            rawMessage,
        };
        for (const handler of this.#eventHandlers) {
            try {
                handler(event, context);
            }
            catch (error) {
                this.#emitError({
                    code: "TRANSPORT_DELIVERY_FAILED",
                    peerId: peer.peerId,
                    connectionId: peer.connectionId,
                    detail: `Transport observation handler failed: ${errorDetail(error)}`,
                    cause: error,
                });
            }
        }
        if (!this.#deliveryHandler) {
            return { outcome: "accepted" };
        }
        return this.#withTimeout(Promise.resolve(this.#deliveryHandler(event, context)), this.#deliveryTimeoutMs, new TransportOperationError("TRANSPORT_DELIVERY_TIMEOUT", `Primary delivery timed out for peer "${peer.peerId}"`, { peerId: peer.peerId }));
    }
    async #sendDeliveryResult(peer, result) {
        if (peer.socket.readyState !== WebSocket.OPEN) {
            throw new TransportOperationError("TRANSPORT_CONNECTION_LOST", `Cannot return delivery result to closed peer "${peer.peerId}"`, { peerId: peer.peerId, transmissionId: result.transmissionId });
        }
        const message = serializeTransportDeliveryResultFrame(result);
        await new Promise((resolve, reject) => {
            try {
                peer.socket.send(message, (error) => {
                    if (error) {
                        reject(error);
                    }
                    else {
                        resolve();
                    }
                });
            }
            catch (error) {
                reject(error);
            }
        });
    }
    async #waitForIdle(timeoutMs) {
        if (this.#isIdle()) {
            return;
        }
        await this.#withTimeout(new Promise((resolve) => this.#idleWaiters.add(resolve)), timeoutMs, new TransportOperationError("TRANSPORT_SHUTDOWN_TIMEOUT", `Transport shutdown timed out with ${this.#pendingSends.size} pending sends and ${this.#receiveTasks.size} receive tasks`));
    }
    #isIdle() {
        return this.#pendingSends.size === 0 && this.#receiveTasks.size === 0;
    }
    #notifyIdle() {
        if (!this.#isIdle()) {
            return;
        }
        for (const resolve of this.#idleWaiters) {
            resolve();
        }
        this.#idleWaiters.clear();
    }
    async #withTimeout(promise, timeoutMs, timeoutError) {
        let timer;
        try {
            return await Promise.race([
                promise,
                new Promise((_resolve, reject) => {
                    timer = setTimeout(() => reject(timeoutError), timeoutMs);
                }),
            ]);
        }
        finally {
            if (timer) {
                clearTimeout(timer);
            }
        }
    }
    async #closeResources() {
        const sockets = new Set();
        for (const peer of this.#peers.values()) {
            sockets.add(peer.socket);
        }
        if (this.#client) {
            sockets.add(this.#client);
        }
        const socketResults = await Promise.allSettled([...sockets].map((socket) => this.#closeSocket(socket)));
        this.#peers.clear();
        this.#receiveCountsByPeer.clear();
        this.#client = null;
        const server = this.#server;
        this.#server = null;
        let serverFailure;
        if (server) {
            try {
                await this.#withTimeout(new Promise((resolve) => server.close(() => resolve())), this.#shutdownTimeoutMs, new TransportOperationError("TRANSPORT_SHUTDOWN_TIMEOUT", "Transport server close timed out"));
            }
            catch (error) {
                serverFailure = error;
            }
        }
        const failures = socketResults
            .filter((result) => result.status === "rejected")
            .map((result) => result.reason);
        if (serverFailure !== undefined) {
            failures.push(serverFailure);
        }
        if (failures.length > 0) {
            throw new TransportOperationError("TRANSPORT_SHUTDOWN_TIMEOUT", "Transport could not close every socket and server within the shutdown bound", { cause: new AggregateError(failures, "Transport close failures") });
        }
    }
    async #closeSocket(socket) {
        if (socket.readyState === WebSocket.CLOSED) {
            return;
        }
        await this.#withTimeout(new Promise((resolve) => {
            socket.once("close", () => resolve());
            if (socket.readyState !== WebSocket.CLOSING) {
                socket.close();
            }
        }), this.#shutdownTimeoutMs, new TransportOperationError("TRANSPORT_SHUTDOWN_TIMEOUT", "Transport socket close timed out"));
    }
    async #startServer() {
        if (!this.#options.port) {
            throw new Error('Server mode requires "port"');
        }
        const server = new WebSocketServer({
            host: this.#options.host ?? "127.0.0.1",
            port: this.#options.port,
        });
        this.#server = server;
        server.on("connection", (socket) => {
            const connectionId = randomUUID();
            const peerId = `peer-${connectionId}`;
            const peer = { peerId, connectionId, socket };
            this.#peers.set(peerId, peer);
            this.#emitPeerState({ peerId, connectionId, status: "connected" });
            this.#attachSocket(peer);
        });
        server.on("error", (error) => {
            this.#emitError({ detail: error.message, cause: error });
        });
        try {
            await new Promise((resolveStart, rejectStart) => {
                const handleListening = () => {
                    server.off("error", handleInitialError);
                    resolveStart();
                };
                const handleInitialError = (error) => {
                    server.off("listening", handleListening);
                    rejectStart(error);
                };
                server.once("listening", handleListening);
                server.once("error", handleInitialError);
            });
        }
        catch (error) {
            if (this.#server === server) {
                this.#server = null;
            }
            throw error;
        }
    }
    async #startClient() {
        if (!this.#options.url) {
            throw new Error('Client mode requires "url"');
        }
        const socket = new WebSocket(this.#options.url);
        this.#client = socket;
        const connectionId = randomUUID();
        const peerId = this.#options.peerId ?? "server";
        try {
            await new Promise((resolveStart, rejectStart) => {
                const timer = setTimeout(() => {
                    socket.off("open", handleOpen);
                    socket.off("error", handleInitialError);
                    socket.once("error", () => undefined);
                    socket.close();
                    rejectStart(new TransportOperationError("TRANSPORT_CONNECTION_TIMEOUT", `Timed out connecting to ${this.#options.url}`, { peerId }));
                }, this.#connectionTimeoutMs);
                const handleOpen = () => {
                    clearTimeout(timer);
                    socket.off("error", handleInitialError);
                    const peer = { peerId, connectionId, socket };
                    this.#peers.set(peerId, peer);
                    this.#emitPeerState({ peerId, connectionId, status: "connected" });
                    this.#attachSocket(peer);
                    resolveStart();
                };
                const handleInitialError = (error) => {
                    clearTimeout(timer);
                    socket.off("open", handleOpen);
                    this.#emitError({
                        peerId,
                        connectionId,
                        detail: error.message,
                        cause: error,
                    });
                    rejectStart(error);
                };
                socket.once("open", handleOpen);
                socket.once("error", handleInitialError);
            });
        }
        catch (error) {
            if (this.#client === socket) {
                this.#client = null;
            }
            throw error;
        }
    }
    #attachSocket(peer) {
        peer.socket.on("message", (raw) => this.#queueSocketMessage(peer, raw));
        peer.socket.on("close", () => {
            if (this.#peers.get(peer.peerId)?.socket === peer.socket) {
                this.#peers.delete(peer.peerId);
            }
            if (this.#client === peer.socket) {
                this.#client = null;
            }
            this.#failPendingForPeer(peer.peerId);
            this.#emitPeerState({
                peerId: peer.peerId,
                connectionId: peer.connectionId,
                status: "disconnected",
            });
            this.#notifyIdle();
        });
        peer.socket.on("error", (error) => {
            this.#emitPeerState({
                peerId: peer.peerId,
                connectionId: peer.connectionId,
                status: "error",
                detail: error.message,
            });
            this.#emitError({
                peerId: peer.peerId,
                connectionId: peer.connectionId,
                detail: error.message,
                cause: error,
            });
        });
    }
    #emitPeerState(state) {
        for (const handler of this.#peerHandlers) {
            try {
                handler(state);
            }
            catch {
                // Peer observers do not own transport lifecycle.
            }
        }
    }
    #emitError(error) {
        for (const handler of this.#errorHandlers) {
            try {
                handler(error);
            }
            catch {
                // Error observers must not recursively destabilize the transport.
            }
        }
    }
}

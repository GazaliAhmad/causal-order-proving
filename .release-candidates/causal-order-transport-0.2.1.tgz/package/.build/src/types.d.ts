import type { EventEnvelope } from "causal-order/types";
export type TransportEventPayload = Record<string, unknown>;
export type NormalizedTransportEvent<T = TransportEventPayload> = EventEnvelope<T> & {
    sequence?: bigint;
    traceId?: string;
    ingestedAt?: bigint;
};
export type TransportMode = "server" | "client";
export type TransportLifecycleState = "idle" | "starting" | "started" | "stopping" | "stopped" | "failed";
export type TransportErrorCode = "TRANSPORT_INVALID_STATE" | "TRANSPORT_UNKNOWN_PEER" | "TRANSPORT_PEER_NOT_OPEN" | "TRANSPORT_SEND_PRESSURE" | "TRANSPORT_SEND_FAILED" | "TRANSPORT_CONNECTION_TIMEOUT" | "TRANSPORT_ACK_TIMEOUT" | "TRANSPORT_CONNECTION_LOST" | "TRANSPORT_RECEIVE_PRESSURE" | "TRANSPORT_DELIVERY_REFUSED" | "TRANSPORT_DELIVERY_FAILED" | "TRANSPORT_DELIVERY_TIMEOUT" | "TRANSPORT_SHUTDOWN_TIMEOUT" | "TRANSPORT_PROTOCOL_ERROR";
export declare class TransportOperationError extends Error {
    readonly code: TransportErrorCode;
    readonly peerId?: string;
    readonly transmissionId?: string;
    constructor(code: TransportErrorCode, message: string, options?: {
        peerId?: string;
        transmissionId?: string;
        cause?: unknown;
    });
}
export interface TransportContext {
    peerId: string;
    connectionId: string;
    receivedAtMs: bigint;
    mode: TransportMode;
    rawMessage: unknown;
}
export interface TransportPeerState {
    peerId: string;
    connectionId: string;
    status: "connecting" | "connected" | "disconnected" | "error";
    detail?: string;
}
export interface TransportError {
    code?: TransportErrorCode;
    peerId?: string;
    connectionId?: string;
    transmissionId?: string;
    detail: string;
    cause?: unknown;
}
export type TransportDeliveryResult = {
    outcome: "accepted";
} | {
    outcome: "refused";
    code?: string;
    detail?: string;
};
export type TransportDeliveryHandler<T = TransportEventPayload> = (event: NormalizedTransportEvent<T>, context: TransportContext) => void | TransportDeliveryResult | Promise<void | TransportDeliveryResult>;
export type TransportEventHandler<T = TransportEventPayload> = (event: NormalizedTransportEvent<T>, context: TransportContext) => void;
export type TransportPeerStateHandler = (state: TransportPeerState) => void;
export type TransportErrorHandler = (error: TransportError) => void;
export interface TransportContract<T = TransportEventPayload> {
    readonly state: TransportLifecycleState;
    start(): Promise<void>;
    stop(): Promise<void>;
    send(event: NormalizedTransportEvent<T>, targetPeerId?: string): Promise<void>;
    onDelivery(handler: TransportDeliveryHandler<T>): () => void;
    onEvent(handler: TransportEventHandler<T>): () => void;
    onPeerState(handler: TransportPeerStateHandler): () => void;
    onError(handler: TransportErrorHandler): () => void;
}
export interface WebSocketJsonTransportOptions<T = TransportEventPayload> {
    mode: TransportMode;
    url?: string;
    port?: number;
    host?: string;
    peerId?: string;
    normalizeMessage?: (message: unknown) => NormalizedTransportEvent<T>;
    connectionTimeoutMs?: number;
    acknowledgmentTimeoutMs?: number;
    deliveryTimeoutMs?: number;
    shutdownTimeoutMs?: number;
    maxInFlightSends?: number;
    maxInFlightSendsPerPeer?: number;
    maxInFlightReceives?: number;
    maxInFlightReceivesPerPeer?: number;
    maxBufferedAmountBytes?: number;
}

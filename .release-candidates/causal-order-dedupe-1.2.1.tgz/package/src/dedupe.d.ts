export interface DedupeEvent {
    id?: string | null;
    nodeId?: string | null;
    sequence?: bigint | number | string;
}
export type DedupeIdentitySource = "id" | "node_sequence" | "none";
export type DedupeFilterReason = "accepted" | "duplicate" | "accepted_without_identity";
export interface DedupeFilterResult {
    accepted: boolean;
    reason: DedupeFilterReason;
    identitySource: DedupeIdentitySource;
}
export interface DedupeIdentityLedgerStats {
    storedIdentities: number;
    maxIdentities: number;
    databasePath: string;
}
export interface DedupeIdentityLedger {
    claim(identityKey: string, acceptedAtMs: bigint): boolean;
    getStats?(): DedupeIdentityLedgerStats;
    close?(): void;
}
export interface SqliteIdentityLedgerConfig {
    databasePath: string;
    maxIdentities: number;
}
export declare class DedupeIdentityLedgerCapacityError extends Error {
    readonly code = "ERR_DEDUPE_IDENTITY_LEDGER_CAPACITY";
    readonly storedIdentities: number;
    readonly maxIdentities: number;
    constructor(storedIdentities: number, maxIdentities: number);
}
export declare class SqliteIdentityLedger implements DedupeIdentityLedger {
    #private;
    readonly databasePath: string;
    readonly maxIdentities: number;
    constructor(config: SqliteIdentityLedgerConfig);
    claim(identityKey: string, acceptedAtMs: bigint): boolean;
    getStats(): DedupeIdentityLedgerStats;
    close(): void;
}
export type DedupePreset = "standard" | "heavy-duplicates" | "high-latency" | "cross-node-busy";
export interface DedupeGatewayConfig {
    preset?: DedupePreset;
    maxSlidingWindowSeconds?: number;
    slidingWindowSeconds?: number;
    autoCleanup?: boolean;
    autoCleanupIntervalSeconds?: number;
    nowProvider?: () => bigint | number;
    identityLedger?: DedupeIdentityLedger;
    durableIdentityLedgerPath?: string;
    maxDurableIdentities?: number;
}
export interface DedupeGatewayFileConfig {
    preset?: DedupePreset;
    maxSlidingWindowSeconds?: number;
    slidingWindowSeconds?: number;
    autoCleanup?: boolean;
    autoCleanupIntervalSeconds?: number;
    durableIdentityLedgerPath?: string;
    maxDurableIdentities?: number;
}
export interface DedupeGatewayStats {
    acceptedEvents: number;
    droppedDuplicates: number;
    currentCacheSize: number;
    activeWindowSeconds: number;
    durableLedger?: DedupeIdentityLedgerStats;
}
export declare function loadDedupeGatewayConfigFile(configPath: string): DedupeGatewayFileConfig;
export declare function createDedupeGatewayFromConfigFile(configPath: string, overrides?: DedupeGatewayConfig): DedupeGateway;
export declare class DedupeGateway {
    #private;
    constructor(config?: DedupeGatewayConfig);
    get maxSlidingWindowMs(): bigint;
    get currentWindowMs(): bigint;
    get cacheSize(): number;
    getStats(): DedupeGatewayStats;
    updateWindow(seconds: number): void;
    filter(event?: DedupeEvent | null): boolean;
    filterWithResult(event?: DedupeEvent | null): DedupeFilterResult;
    cleanup(): void;
    destroy(): void;
}

import type { RuntimeMonitorConfig } from "./deployment-common.js";
import type { HarnessMonitorAdapter } from "./pipeline-types.js";
type ControlledMonitorComponent = "transport" | "dedupe" | "causal-order";
type ControlledMonitorState = "online" | "offline";
export interface MonitorScenarioSnapshot {
    label: string;
    transport: ControlledMonitorState;
    dedupe: ControlledMonitorState;
    causalOrder: ControlledMonitorState;
}
export interface MonitorOutageController {
    tick(options?: {
        reconcile?: boolean;
    }): Promise<MonitorScenarioSnapshot | null>;
}
export declare const DEFAULT_REPLAY_RETENTION_MARGIN_MS = 180000n;
export interface ReplayRetentionRequirement {
    outageDurationMs: bigint;
    replayMarginMs: bigint;
    requiredRetentionMs: bigint;
}
export declare function deriveReplayRetentionRequirement(options: {
    durationMs: bigint;
    steadyForMs: bigint;
    replayMarginMs?: bigint;
}): ReplayRetentionRequirement;
export declare function createMonitorOutageController(options: {
    elapsedMs: () => bigint;
    monitorAdapter: HarnessMonitorAdapter | null;
    monitorConfig: RuntimeMonitorConfig;
    durationMs: bigint;
    steadyForMs: bigint;
    now: () => bigint;
    setTransportState?: (state: ControlledMonitorState) => Promise<void>;
    onTransition?: (component: ControlledMonitorComponent, state: ControlledMonitorState, snapshot: MonitorScenarioSnapshot, elapsedMs: bigint) => void;
}): MonitorOutageController | null;
export declare function deriveOutageWindow(durationMs: bigint, steadyForMs: bigint): {
    startOffsetMs: bigint;
    endOffsetMs: bigint;
};
export {};

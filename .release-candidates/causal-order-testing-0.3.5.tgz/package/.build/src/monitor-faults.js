import { monitorScenarioIncludesTransport, resolveMonitorScenario, } from "./monitor-scenarios.js";
export const DEFAULT_REPLAY_RETENTION_MARGIN_MS = 180000n;
export function deriveReplayRetentionRequirement(options) {
    const window = deriveOutageWindow(options.durationMs, options.steadyForMs);
    const outageDurationMs = window.endOffsetMs - window.startOffsetMs;
    const replayMarginMs = options.replayMarginMs ?? DEFAULT_REPLAY_RETENTION_MARGIN_MS;
    if (replayMarginMs < 0n) {
        throw new Error("replayMarginMs must be non-negative");
    }
    return {
        outageDurationMs,
        replayMarginMs,
        requiredRetentionMs: outageDurationMs + replayMarginMs,
    };
}
export function createMonitorOutageController(options) {
    if (!options.monitorAdapter || !options.monitorConfig.enabled) {
        return null;
    }
    const scenario = resolveMonitorScenario(options.monitorConfig.scenarioId);
    if (!scenario || scenario.kind === "healthy") {
        return null;
    }
    const scenarioId = scenario.id;
    if (monitorScenarioIncludesTransport(scenario) && !options.setTransportState) {
        throw new Error(`${scenarioId} requires an adapter that implements published transport fault control`);
    }
    const lastState = {};
    return {
        async tick(tickOptions = {}) {
            const elapsedMs = options.elapsedMs();
            const snapshot = resolveMonitorScenarioSnapshot({
                scenarioId,
                elapsedMs,
                durationMs: options.durationMs,
                steadyForMs: options.steadyForMs,
            });
            if (lastState.transport !== snapshot.transport) {
                await options.setTransportState?.(snapshot.transport);
                options.onTransition?.("transport", snapshot.transport, snapshot, elapsedMs);
                lastState.transport = snapshot.transport;
            }
            for (const component of ["dedupe", "causal-order"]) {
                const desiredState = component === "dedupe" ? snapshot.dedupe : snapshot.causalOrder;
                if (lastState[component] !== desiredState) {
                    await options.monitorAdapter?.updateComponentHealth(component, desiredState, {
                        scenarioId,
                        scenarioLabel: snapshot.label,
                        elapsedMs: elapsedMs.toString(),
                    });
                    options.onTransition?.(component, desiredState, snapshot, elapsedMs);
                    lastState[component] = desiredState;
                }
                if (desiredState === "online") {
                    await options.monitorAdapter?.observeHeartbeat(component, options.now(), {
                        scenarioId,
                        scenarioLabel: snapshot.label,
                        elapsedMs: elapsedMs.toString(),
                    });
                }
            }
            if (snapshot.dedupe === "online" &&
                snapshot.causalOrder === "online" &&
                tickOptions.reconcile !== false &&
                typeof options.monitorAdapter.reconcileRecovery === "function") {
                await options.monitorAdapter.reconcileRecovery(options.monitorConfig.replayBatchSize);
            }
            return snapshot;
        },
    };
}
function resolveMonitorScenarioSnapshot(input) {
    const window = deriveOutageWindow(input.durationMs, input.steadyForMs);
    const inOutage = input.elapsedMs >= window.startOffsetMs && input.elapsedMs < window.endOffsetMs;
    const scenario = resolveMonitorScenario(input.scenarioId);
    if (!scenario) {
        throw new Error("A monitor scenario is required for outage injection");
    }
    switch (scenario.kind) {
        case "healthy":
            return {
                label: scenario.kind,
                transport: "online",
                dedupe: "online",
                causalOrder: "online",
            };
        case "transport_outage":
            return {
                label: inOutage ? "transport_outage" : "healthy_or_recovery",
                transport: inOutage ? "offline" : "online",
                dedupe: "online",
                causalOrder: "online",
            };
        case "dedupe_bypass":
            return {
                label: inOutage ? "dedupe_outage" : "healthy_or_recovery",
                transport: "online",
                dedupe: inOutage ? "offline" : "online",
                causalOrder: "online",
            };
        case "order_outage":
        case "replay_retry":
            return {
                label: inOutage ? "order_outage" : "healthy_or_recovery",
                transport: "online",
                dedupe: "online",
                causalOrder: inOutage ? "offline" : "online",
            };
        case "dual_outage":
            return {
                label: inOutage ? "dual_outage" : "healthy_or_recovery",
                transport: "online",
                dedupe: inOutage ? "offline" : "online",
                causalOrder: inOutage ? "offline" : "online",
            };
        case "transport_dedupe_outage":
            return {
                label: inOutage
                    ? "transport_dedupe_outage"
                    : "healthy_or_recovery",
                transport: inOutage ? "offline" : "online",
                dedupe: inOutage ? "offline" : "online",
                causalOrder: "online",
            };
        case "transport_order_outage":
            return {
                label: inOutage
                    ? "transport_order_outage"
                    : "healthy_or_recovery",
                transport: inOutage ? "offline" : "online",
                dedupe: "online",
                causalOrder: inOutage ? "offline" : "online",
            };
        case "transport_dedupe_order_outage":
            return {
                label: inOutage
                    ? "transport_dedupe_order_outage"
                    : "healthy_or_recovery",
                transport: inOutage ? "offline" : "online",
                dedupe: inOutage ? "offline" : "online",
                causalOrder: inOutage ? "offline" : "online",
            };
    }
}
export function deriveOutageWindow(durationMs, steadyForMs) {
    const total = durationMs > 0n ? durationMs : 1n;
    const minLead = 60000n;
    const maxStart = total > 180000n ? total / 3n : minLead;
    const startOffsetMs = clampBigInt(steadyForMs + 120000n, minLead, maxStart);
    const desiredLength = clampBigInt(total / 5n, 120000n, 720000n);
    const latestEnd = total > 120000n ? total - 60000n : total;
    const endOffsetMs = clampBigInt(startOffsetMs + desiredLength, startOffsetMs + 30000n, latestEnd);
    return {
        startOffsetMs,
        endOffsetMs,
    };
}
function clampBigInt(value, min, max) {
    if (value < min) {
        return min;
    }
    if (value > max) {
        return max;
    }
    return value;
}

export class TerminalDrainError extends Error {
    phase;
    state;
    code = "ERR_TESTING_TERMINAL_DRAIN";
    constructor(phase, message, state = {}) {
        super(message);
        this.phase = phase;
        this.state = state;
        this.name = "TerminalDrainError";
    }
}
export class ShutdownCoordinator {
    options;
    #phase = "running";
    #completedPhases = new Set();
    #verdictDerived = false;
    #eventQueueClosed = false;
    #transportStopPromise = null;
    #runPromise = null;
    #failureCleanupPromise = null;
    #resourceClosePromise = null;
    #lifecycleFlushPromise = null;
    #periodicRecoveryStopped = false;
    #transportStopped = false;
    #monitorOperationsDrained = false;
    #monitorTerminal = false;
    #lifecycleDrained = false;
    #orderingSettled = false;
    #startedAt = 0;
    #deadlineAt = Number.POSITIVE_INFINITY;
    #now;
    constructor(options) {
        this.options = options;
        this.#now = options.now ?? Date.now;
        // Ordering may reject before shutdown reaches the ordering drain. Observe it
        // immediately so earlier barrier turns do not turn that expected rejection
        // into an unhandled-rejection process failure; the original promise is still
        // awaited below and retains its rejection for contract reporting.
        void options.orderingPromise.catch(() => { });
    }
    get phase() {
        return this.#phase;
    }
    get eventQueueClosed() {
        return this.#eventQueueClosed;
    }
    get completedPhases() {
        return [...this.#completedPhases];
    }
    get lastCompletedPhase() {
        return this.completedPhases.at(-1) ?? null;
    }
    runToEvidenceReady() {
        this.#runPromise ??= this.#runToEvidenceReady();
        return this.#runPromise;
    }
    async #runToEvidenceReady() {
        this.#startDeadlineIfNeeded();
        this.#transition("running", "ingress_stopping");
        await this.#withinDeadline(this.options.drainIngress(), "ingress_stopping", "shutdown ingress drain incomplete before deadline");
        this.#stopPeriodicRecoveryOnce();
        this.#transition("ingress_stopping", "ingress_stopped");
        this.options.onMilestone?.("ingress_stopped");
        this.#transition("ingress_stopped", "transport_stopping");
        await this.#withinDeadline(this.#stopTransportOnce(), "transport_stopping", "shutdown transport barrier incomplete before deadline");
        this.options.markTransportCallbackBoundaryClosed();
        this.#transportStopped = true;
        this.options.onMilestone?.("adapter_stop_resolved");
        await this.#withinDeadline(new Promise((resolve) => setImmediate(resolve)), "transport_stopped", "shutdown callback-boundary check incomplete before deadline");
        this.options.captureTransportEvidence?.();
        this.#assertNoTransportCallbackViolation();
        this.#transition("transport_stopping", "transport_stopped");
        this.#transition("transport_stopped", "monitor_operations_draining");
        await this.#drainMonitorOperations();
        this.#monitorOperationsDrained = true;
        this.options.onMilestone?.("monitor_operations_drained");
        this.#assertNoTransportCallbackViolation();
        this.#transition("monitor_operations_draining", "monitor_recovering");
        if (this.options.monitorAdapter) {
            await this.#recoverMonitor();
        }
        this.#monitorTerminal = true;
        this.options.onMilestone?.("monitor_terminal");
        this.#assertNoTransportCallbackViolation();
        this.#transition("monitor_recovering", "monitor_drained");
        this.#transition("monitor_drained", "lifecycle_draining");
        if (this.options.monitorAdapter) {
            await this.#drainLifecycle(this.options.monitorAdapter);
        }
        this.#lifecycleDrained = true;
        this.options.onMilestone?.("lifecycle_drained");
        this.#assertNoTransportCallbackViolation();
        this.#transition("lifecycle_draining", "order_draining");
        this.#assertPreOrderingInvariants();
        this.#closeEventQueueOnce();
        await this.#withinDeadline(this.options.orderingPromise, "order_draining", "shutdown ordering drain incomplete before deadline");
        this.#orderingSettled = true;
        this.options.onMilestone?.("ordering_settled");
        this.options.captureOrderingEvidence?.();
        this.#assertNoTransportCallbackViolation();
        this.#transition("order_draining", "evidence_finalizing");
    }
    markVerdictDerived() {
        if (this.#phase !== "evidence_finalizing") {
            throw new TerminalDrainError(this.#phase, `Cannot derive verdict during shutdown phase ${this.#phase}`);
        }
        this.#assertNoTransportCallbackViolation();
        this.#verdictDerived = true;
        this.options.onMilestone?.("verdict_derived");
    }
    markFailureVerdictDerived() {
        this.#verdictDerived = true;
    }
    async closeResources(close) {
        if (this.#phase !== "evidence_finalizing" || !this.#verdictDerived) {
            throw new TerminalDrainError(this.#phase, "Cannot close shutdown resources before verdict derivation");
        }
        this.#resourceClosePromise ??= Promise.resolve()
            .then(close)
            .then(() => {
            if (this.#phase === "evidence_finalizing") {
                this.#transition("evidence_finalizing", "resources_closed");
            }
        });
        await this.#resourceClosePromise;
    }
    closeResourcesForFailureCleanup(close) {
        if (!this.#verdictDerived) {
            return Promise.reject(new TerminalDrainError(this.#phase, "Cannot close shutdown resources before failure verdict derivation"));
        }
        this.#resourceClosePromise ??= Promise.resolve().then(close);
        return this.#resourceClosePromise;
    }
    closeEventQueueForFailureCleanup() {
        this.#closeEventQueueOnce();
    }
    runFailureCleanup() {
        this.#failureCleanupPromise ??= this.#runFailureCleanup();
        return this.#failureCleanupPromise;
    }
    async #runFailureCleanup() {
        this.#startDeadlineIfNeeded();
        this.#stopPeriodicRecoveryOnce();
        const errors = [];
        if (!this.#transportStopped) {
            try {
                await this.#withinDeadline(this.#stopTransportOnce(), "transport_stopping", "shutdown transport barrier incomplete before deadline");
                this.options.markTransportCallbackBoundaryClosed();
                this.#transportStopped = true;
                this.options.onMilestone?.("adapter_stop_resolved");
                this.options.captureTransportEvidence?.();
            }
            catch (error) {
                this.options.markTransportCallbackBoundaryUnsafe();
                errors.push(this.#asCleanupError("transport_stopping", "shutdown transport barrier failed during cleanup", error));
            }
        }
        if (!this.#monitorOperationsDrained) {
            try {
                await this.#drainMonitorOperations();
                this.#monitorOperationsDrained = true;
                this.options.onMilestone?.("monitor_operations_drained");
            }
            catch (error) {
                errors.push(this.#asCleanupError("monitor_operations_draining", "shutdown monitor operations failed during cleanup", error));
            }
        }
        const monitor = this.options.monitorAdapter;
        if (monitor) {
            try {
                this.options.captureMonitorEvidence?.(this.#readMonitorEvidence(monitor));
            }
            catch (error) {
                errors.push(this.#asCleanupError("monitor_recovering", "shutdown monitor evidence capture failed during cleanup", error));
            }
            if (!this.#lifecycleDrained) {
                try {
                    await this.#drainLifecycle(monitor);
                    this.#lifecycleDrained = true;
                    this.options.onMilestone?.("lifecycle_drained");
                }
                catch (error) {
                    errors.push(this.#asCleanupError("lifecycle_draining", "shutdown lifecycle failed during cleanup", error));
                }
            }
        }
        else {
            this.#lifecycleDrained = true;
        }
        this.#closeEventQueueOnce();
        if (!this.#orderingSettled) {
            try {
                await this.#withinDeadline(this.options.orderingPromise, "order_draining", "shutdown ordering drain incomplete before deadline");
                this.#orderingSettled = true;
                this.options.onMilestone?.("ordering_settled");
                this.options.captureOrderingEvidence?.();
            }
            catch (error) {
                errors.push(this.#asCleanupError("order_draining", "shutdown ordering failed during cleanup", error));
            }
        }
        return {
            errors,
            transportStopped: this.#transportStopped,
            monitorOperationsDrained: this.#monitorOperationsDrained,
            lifecycleDrained: this.#lifecycleDrained,
            orderingSettled: this.#orderingSettled,
        };
    }
    #asCleanupError(phase, message, error) {
        if (error instanceof TerminalDrainError) {
            return error;
        }
        return new TerminalDrainError(phase, message, {
            errorName: error instanceof Error ? error.name : "Error",
            elapsedMs: this.#now() - this.#startedAt,
        });
    }
    #transition(expected, next) {
        if (this.#phase !== expected) {
            throw new TerminalDrainError(this.#phase, `Invalid shutdown phase transition ${this.#phase} -> ${next}; expected ${expected}`);
        }
        this.#completedPhases.add(expected);
        this.#phase = next;
        this.options.onPhase?.(next);
    }
    #stopTransportOnce() {
        if (!this.#transportStopPromise) {
            this.options.onMilestone?.("adapter_stop_started");
            this.#transportStopPromise = this.options.adapter.stop();
        }
        return this.#transportStopPromise;
    }
    #stopPeriodicRecoveryOnce() {
        if (this.#periodicRecoveryStopped) {
            return;
        }
        this.options.stopPeriodicRecovery();
        this.#periodicRecoveryStopped = true;
    }
    #closeEventQueueOnce() {
        if (this.#eventQueueClosed) {
            return;
        }
        this.options.eventQueue.close();
        this.#eventQueueClosed = true;
        this.options.onMilestone?.("event_queue_closed");
    }
    async #drainMonitorOperations() {
        try {
            await this.#withinDeadline(this.options.monitorOperations.drain(), "monitor_operations_draining", "shutdown monitor operations failed or remained pending");
        }
        catch (error) {
            if (error instanceof TerminalDrainError) {
                throw error;
            }
            throw new TerminalDrainError("monitor_operations_draining", "shutdown monitor operations failed or remained pending", this.options.monitorOperations.getSnapshot());
        }
        const tracker = this.options.monitorOperations.getSnapshot();
        if (Number(tracker.pendingOperations ?? 0) !== 0) {
            throw new TerminalDrainError("monitor_operations_draining", "shutdown monitor operations failed or remained pending", tracker);
        }
    }
    async #recoverMonitor() {
        const monitor = this.options.monitorAdapter;
        if (!monitor) {
            return;
        }
        if (typeof monitor.reconcileRecovery !== "function") {
            throw this.#monitorDrainError(this.#readMonitorEvidence(monitor), 0);
        }
        let evidence = this.#readMonitorEvidence(monitor);
        this.options.captureMonitorEvidence?.(evidence);
        let previousSample = monitorProgressSample(evidence);
        let noProgressPasses = 0;
        let passes = 0;
        while (!isMonitorRecoveryComplete(evidence)) {
            if (this.#remainingMs() <= 0) {
                throw this.#monitorDrainError(evidence, passes);
            }
            await this.#waitForReplayRetry(evidence);
            await this.options.observeRecoveryHealth?.();
            this.options.onMilestone?.("final_reconcile_started");
            await this.#withinDeadline(Promise.resolve(monitor.reconcileRecovery(this.options.replayBatchSize)), "monitor_recovering", "shutdown monitor recovery incomplete before deadline");
            await this.#drainMonitorOperations();
            evidence = this.#readMonitorEvidence(monitor);
            this.options.captureMonitorEvidence?.(evidence);
            passes += 1;
            const sample = monitorProgressSample(evidence);
            if (sample === previousSample) {
                noProgressPasses += 1;
            }
            else {
                noProgressPasses = 0;
                previousSample = sample;
            }
            if (String(evidence.replaySnapshot.state ?? "unknown") === "aborted") {
                throw this.#monitorDrainError(evidence, passes);
            }
            if (noProgressPasses >= 3 && !isMonitorRecoveryComplete(evidence)) {
                throw this.#monitorDrainError(evidence, passes);
            }
        }
        await this.#drainMonitorOperations();
        evidence = this.#readMonitorEvidence(monitor);
        this.options.captureMonitorEvidence?.(evidence);
        if (!isMonitorRecoveryComplete(evidence)) {
            throw this.#monitorDrainError(evidence, passes);
        }
    }
    async #waitForReplayRetry(evidence) {
        const rawRetryAt = evidence.replaySnapshot.nextRetryAt;
        if (rawRetryAt === null || rawRetryAt === undefined) {
            return;
        }
        const retryAt = BigInt(rawRetryAt);
        const now = this.options.simulationNowMs();
        if (retryAt <= now) {
            return;
        }
        const scaledWait = Math.ceil(Number(retryAt - now) / this.options.timeScale);
        const waitMs = Math.min(Math.max(1, scaledWait), this.#remainingMs());
        await this.#withinDeadline(new Promise((resolve) => setTimeout(resolve, waitMs)), "monitor_recovering", "shutdown monitor recovery incomplete before deadline");
    }
    #readMonitorEvidence(monitor) {
        return {
            snapshot: monitor.getSnapshot(),
            replaySnapshot: monitor.getReplaySnapshot(),
            operatorSnapshot: monitor.getOperatorSnapshot?.() ?? null,
        };
    }
    #monitorDrainError(evidence, passes) {
        const pendingRows = Number(evidence.snapshot.reservoir?.totalPendingRows ?? -1);
        const retryWaitingRows = Number(evidence.snapshot.reservoir?.retryWaitingRows ?? -1);
        const replayState = String(evidence.replaySnapshot.state ?? "unknown");
        const gateClosed = evidence.operatorSnapshot?.replay?.gateClosed ?? "unknown";
        const elapsedMs = this.#now() - this.#startedAt;
        return new TerminalDrainError("monitor_recovering", `shutdown monitor recovery incomplete: pendingRows=${pendingRows}, retryWaitingRows=${retryWaitingRows}, replayState=${replayState}, gateClosed=${String(gateClosed)}, passes=${passes}, elapsedMs=${elapsedMs}`, { pendingRows, retryWaitingRows, replayState, gateClosed, passes, elapsedMs });
    }
    async #drainLifecycle(monitor) {
        if (typeof monitor.flushLifecycle !== "function" ||
            typeof monitor.getLifecycleSnapshot !== "function") {
            throw new TerminalDrainError("lifecycle_draining", "shutdown lifecycle incomplete: flushStatus=unavailable, queueDepth=-1, activeDispatch=unknown");
        }
        const timeoutMs = BigInt(Math.max(1, this.#remainingMs()));
        let flush;
        try {
            this.#lifecycleFlushPromise ??= monitor.flushLifecycle(timeoutMs);
            flush = await this.#withinDeadline(this.#lifecycleFlushPromise, "lifecycle_draining", "shutdown lifecycle incomplete before deadline");
        }
        catch (error) {
            if (error instanceof TerminalDrainError) {
                throw error;
            }
            throw new TerminalDrainError("lifecycle_draining", "shutdown lifecycle incomplete: flushStatus=failed, queueDepth=-1, activeDispatch=unknown");
        }
        const snapshot = monitor.getLifecycleSnapshot();
        const evidence = { flush, snapshot };
        this.options.captureLifecycleEvidence?.(evidence);
        if (!isLifecycleDrained(evidence)) {
            throw new TerminalDrainError("lifecycle_draining", `shutdown lifecycle incomplete: flushStatus=${String(flush.status ?? "unknown")}, queueDepth=${Number(snapshot.queueDepth ?? flush.queueDepth ?? -1)}, activeDispatch=${String(flush.activeDispatch ?? "unknown")}`, {
                flushStatus: flush.status ?? "unknown",
                queueDepth: Number(snapshot.queueDepth ?? flush.queueDepth ?? -1),
                activeDispatch: flush.activeDispatch ?? "unknown",
            });
        }
    }
    #assertPreOrderingInvariants() {
        if (this.#phase !== "order_draining") {
            throw new TerminalDrainError(this.#phase, "Ordering drain started before monitor and lifecycle completion");
        }
        const tracker = this.options.monitorOperations.getSnapshot();
        if (Number(tracker.pendingOperations ?? 0) !== 0) {
            throw new TerminalDrainError("order_draining", "Ordering drain started with pending monitor operations", tracker);
        }
    }
    #assertNoTransportCallbackViolation() {
        const violation = this.options.getTransportCallbackViolation();
        if (violation) {
            throw new TerminalDrainError(this.#phase, "Transport callback occurred after the stop barrier", { callbackBoundaryViolated: true });
        }
    }
    async #withinDeadline(operation, phase, message) {
        const remainingMs = this.#remainingMs();
        if (remainingMs <= 0) {
            throw new TerminalDrainError(phase, message, { elapsedMs: this.#now() - this.#startedAt });
        }
        let timeout = null;
        try {
            return await Promise.race([
                operation,
                new Promise((_resolve, reject) => {
                    timeout = setTimeout(() => {
                        reject(new TerminalDrainError(phase, message, {
                            elapsedMs: this.#now() - this.#startedAt,
                        }));
                    }, remainingMs);
                }),
            ]);
        }
        finally {
            if (timeout) {
                clearTimeout(timeout);
            }
        }
    }
    #remainingMs() {
        return Math.max(0, this.#deadlineAt - this.#now());
    }
    #startDeadlineIfNeeded() {
        if (Number.isFinite(this.#deadlineAt)) {
            return;
        }
        this.#startedAt = this.#now();
        this.#deadlineAt =
            this.#startedAt + Math.max(1, this.options.shutdownTimeoutMs);
    }
}
export function isMonitorRecoveryComplete(evidence) {
    const reservoir = evidence.snapshot.reservoir ?? {};
    const replay = evidence.replaySnapshot ?? {};
    const operator = evidence.operatorSnapshot;
    const replayState = String(replay.state ?? "unknown");
    return (Number(reservoir.totalPendingRows ?? -1) === 0 &&
        Number(reservoir.retryWaitingRows ?? -1) === 0 &&
        (replayState === "idle" || replayState === "completed") &&
        replay.nextRetryAt == null &&
        replay.lastError == null &&
        operator !== null &&
        operator.replay?.gateClosed === false &&
        Number(operator.backlog?.totalRows ?? -1) === 0 &&
        Number(operator.replay?.backlogRemainingRows ?? -1) === 0);
}
function isLifecycleDrained(evidence) {
    return (evidence.flush.status === "drained" &&
        Number(evidence.flush.queueDepth ?? -1) === 0 &&
        evidence.flush.activeDispatch === false &&
        Number(evidence.snapshot.queueDepth ?? -1) === 0);
}
function monitorProgressSample(evidence) {
    const reservoir = evidence.snapshot.reservoir ?? {};
    const replay = evidence.replaySnapshot ?? {};
    const operatorReplay = evidence.operatorSnapshot?.replay ?? {};
    return JSON.stringify([
        Number(reservoir.totalPendingRows ?? -1),
        Number(reservoir.retryWaitingRows ?? -1),
        String(replay.state ?? "unknown"),
        Number(replay.queuedEventCount ?? -1),
        Number(replay.deliveredEventCount ?? -1),
        replay.nextRetryAt == null ? null : String(replay.nextRetryAt),
        operatorReplay.gateClosed ?? "unknown",
        Number(operatorReplay.backlogRemainingRows ?? -1),
    ]);
}

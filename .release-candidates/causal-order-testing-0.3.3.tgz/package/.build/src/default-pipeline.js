import { createHlcClock, orderEventStream } from "causal-order";
import { DedupeGateway } from "@causal-order/dedupe";
export const harnessPipeline = {
    createClockAdapter({ nodeId, now }) {
        const clock = createHlcClock({ nodeId, now });
        return {
            now: () => clock.now(),
            receive: (remoteClock) => clock.receive(remoteClock),
        };
    },
    createDedupeAdapter({ config, nowProvider }) {
        const gate = new DedupeGateway({
            ...config,
            nowProvider,
        });
        return {
            filter: (event) => gate.filter(event),
            filterWithResult: (event) => gate.filterWithResult(event),
            updateWindow: (seconds) => gate.updateWindow(seconds),
            getStats: () => gate.getStats(),
            destroy: () => gate.destroy(),
        };
    },
    async createMonitorAdapter(options) {
        const runtimeConfig = options.runtimeConfig;
        const specifier = typeof runtimeConfig.monitorConfig === "object" &&
            runtimeConfig.monitorConfig !== null &&
            typeof runtimeConfig.monitorConfig.moduleSpecifier === "string"
            ? String(runtimeConfig.monitorConfig.moduleSpecifier)
            : "@causal-order/monitor";
        const mod = (await import(specifier));
        const Adapter = mod.TransportMonitorAdapter;
        if (typeof Adapter !== "function") {
            throw new Error(`Monitor module ${specifier} must export TransportMonitorAdapter`);
        }
        const monitorConfig = typeof runtimeConfig.monitorConfig === "object" &&
            runtimeConfig.monitorConfig !== null
            ? runtimeConfig.monitorConfig
            : {};
        const rawAdapter = new Adapter({
            deliverToDedupe: options.deliverToDedupe,
            deliverToOrder: options.deliverToOrder,
            onBuffered: options.onBuffered,
            onDecision: options.onDecision,
            onReplayStateChange: options.onReplayStateChange,
        }, {
            now: options.nowProvider,
            reservoir: {
                databasePath: typeof monitorConfig.databasePath === "string"
                    ? monitorConfig.databasePath
                    : ":memory:",
                rollingBufferWindowMs: BigInt(monitorConfig.rollingBufferWindowMs ??
                    4n * 60n * 60n * 1000n),
                fullOutageMaxWindowMs: BigInt(monitorConfig.fullOutageMaxWindowMs ??
                    6n * 60n * 60n * 1000n),
                pruneIntervalMs: BigInt(monitorConfig.pruneIntervalMs ??
                    60000n),
            },
        });
        return {
            ingest: (event, sourceStreamId) => rawAdapter.ingest(event, sourceStreamId),
            updateComponentHealth: (component, state, details) => rawAdapter.updateComponentHealth(component, {
                state,
                details,
            }),
            observeHeartbeat: (component, observedAt, details) => rawAdapter.observeHeartbeat(component, observedAt, details),
            getSnapshot: () => rawAdapter.getSnapshot(),
            getReplaySnapshot: () => rawAdapter.getReplaySnapshot(),
            getOperatorSnapshot: () => rawAdapter.getOperatorSnapshot(),
            getCapacitySnapshot: () => rawAdapter.capacity.getSnapshot(),
            getLifecycleSnapshot: () => rawAdapter.lifecycle.getSnapshot(),
            flushLifecycle: (timeoutMs) => rawAdapter.lifecycle.flush(timeoutMs),
            reconcileRecovery: (limit) => rawAdapter.reconcileRecovery(limit),
            close: () => rawAdapter.close(),
        };
    },
    orderEvents(source, options) {
        return orderEventStream(source, options);
    },
};
export default harnessPipeline;

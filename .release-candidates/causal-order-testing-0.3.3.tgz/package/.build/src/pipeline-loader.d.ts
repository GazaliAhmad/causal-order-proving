import type { HarnessPipelineProvider } from "./pipeline-types.js";
export declare function loadHarnessPipeline(specifier?: string | null): Promise<HarnessPipelineProvider>;

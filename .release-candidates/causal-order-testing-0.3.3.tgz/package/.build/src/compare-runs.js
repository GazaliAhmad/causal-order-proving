#!/usr/bin/env node
import { readFile } from "node:fs/promises";
import { existsSync, readdirSync, statSync } from "node:fs";
import { resolve } from "node:path";
const RUNS_DIR = resolve("artifacts/runs");
function main() {
    if (process.argv.includes("--help")) {
        printHelp();
        return;
    }
    const pathArgs = process.argv.slice(2).filter((token) => token !== "--help");
    resolveSummaryPaths(pathArgs)
        .then(async ([leftPath, rightPath]) => {
        const [left, right] = await Promise.all([
            loadRunMetrics(leftPath),
            loadRunMetrics(rightPath),
        ]);
        console.log(buildComparisonReport(left, right));
    })
        .catch((error) => {
        console.error(error instanceof Error ? error.message : String(error));
        process.exitCode = 1;
    });
}
function printHelp() {
    console.log("usage: causal-order-testing-compare [left] [right]");
    console.log("");
    console.log("Compare two run directories or summary.json files.");
    console.log("If no paths are provided, compares the two most recent runs.");
    console.log("");
    console.log("positional arguments:");
    console.log("  left        Optional path to a run directory or summary.json.");
    console.log("  right       Optional path to a run directory or summary.json.");
}
async function resolveSummaryPaths(pathArgs) {
    if (pathArgs.length === 0) {
        const latest = findLatestRuns(RUNS_DIR, 2);
        if (latest.length < 2) {
            throw new Error(`Need at least two run folders with summary.json under ${RUNS_DIR}`);
        }
        return [resolve(latest[1], "summary.json"), resolve(latest[0], "summary.json")];
    }
    if (pathArgs.length !== 2) {
        throw new Error("Provide zero paths or exactly two paths. See --help for usage.");
    }
    return [resolveSummaryPath(pathArgs[0]), resolveSummaryPath(pathArgs[1])];
}
function resolveSummaryPath(pathArg) {
    const path = resolve(pathArg);
    const summaryPath = path.endsWith(".json") ? path : resolve(path, "summary.json");
    if (!existsSync(summaryPath)) {
        throw new Error(`Summary file not found: ${summaryPath}`);
    }
    return summaryPath;
}
function findLatestRuns(runsDir, count) {
    if (!existsSync(runsDir)) {
        return [];
    }
    const candidates = [];
    for (const entry of readdirSync(runsDir, { withFileTypes: true })) {
        if (!entry.isDirectory()) {
            continue;
        }
        const path = resolve(runsDir, entry.name);
        const summaryPath = resolve(path, "summary.json");
        if (!existsSync(summaryPath)) {
            continue;
        }
        candidates.push({
            modifiedMs: statSync(summaryPath).mtimeMs,
            path,
        });
    }
    candidates.sort((left, right) => right.modifiedMs - left.modifiedMs);
    return candidates.slice(0, count).map((entry) => entry.path);
}
async function loadRunMetrics(summaryPath) {
    const summary = JSON.parse(await readFile(summaryPath, "utf8"));
    const runDir = resolve(summaryPath, "..");
    const runtimeConfig = await loadOptionalJson(resolve(runDir, "run-config.json"));
    const heartbeats = await loadPreferredNdjson(runDir, [
        "heartbeats.ndjson",
        "heartbeat.ndjson",
    ]);
    const dedupe = summary.dedupe ?? {};
    const config = summary.config ?? {};
    const monitor = summary.monitor ?? {};
    const normalized = normalizeSummary(summary);
    const monitorHealth = await loadNdjson(resolve(runDir, "monitor-health.ndjson"));
    const monitorReplay = await loadNdjson(resolve(runDir, "monitor-replay.ndjson"));
    const monitorAnalysis = deriveMonitorAnalysis(monitor);
    const monitorReplayLifecycle = summarizeReplayLifecycle(monitorReplay);
    const monitorTransitionSummary = summarizeScenarioTransitions(monitorHealth);
    const delivered = normalized.delivered;
    const generated = normalized.generated;
    const ordered = normalized.ordered;
    const anomalies = normalized.anomalies;
    const late = normalized.late;
    const warnings = normalized.warnings;
    const errors = normalized.errors;
    const duplicatesInjected = normalized.duplicatesInjected;
    const acceptedEvents = normalized.acceptedEvents;
    const droppedDuplicates = normalized.droppedDuplicates;
    const unsuppressedDuplicates = duplicatesInjected > 0
        ? Math.max(duplicatesInjected - droppedDuplicates, 0)
        : 0;
    const unexplainedDeliveryGap = acceptedEvents > 0
        ? Math.max(delivered - acceptedEvents - droppedDuplicates, 0)
        : Math.max(delivered - generated, 0);
    const duplicateLeakage = Math.max(unsuppressedDuplicates, unexplainedDeliveryGap);
    const duplicateLeakageRatio = duplicatesInjected > 0 ? duplicateLeakage / duplicatesInjected : null;
    const maxQueue = Number(normalized.maxQueue);
    const wallElapsedMs = Number(normalized.wallElapsedMs);
    let peakRssMb = null;
    let lastRssMb = null;
    if (heartbeats.length > 0) {
        peakRssMb =
            Math.max(...heartbeats.map((row) => Number(row.rssBytes ?? row.process?.rssBytes ?? 0)), 0) /
                (1024 * 1024);
        lastRssMb =
            Number(heartbeats.at(-1)?.rssBytes ?? heartbeats.at(-1)?.process?.rssBytes ?? 0) /
                (1024 * 1024);
    }
    else if (normalized.kind === "wallclock-transport") {
        peakRssMb = Number(summary.process?.rssBytes?.maxRssBytes ?? 0) / (1024 * 1024);
        lastRssMb = Number(summary.process?.rssBytes?.finalRssBytes ?? 0) / (1024 * 1024);
    }
    const peakDedupeCacheSize = Math.max(normalized.currentCacheSize, ...heartbeats.map((row) => Number(row.dedupe?.currentCacheSize ?? row.dedupe?.cacheSize ?? 0)));
    const status = normalized.status;
    const dedupeWindow = resolveDedupeWindow(summary, runtimeConfig);
    const { assessment } = assessRun({
        status,
        errors,
        late,
        anomalies,
        generated,
        maxQueue,
        delivered,
        accepted: acceptedEvents,
        ordered,
        dedupeWindow,
    });
    return {
        kind: normalized.kind,
        name: runDir.split(/[\\/]/).at(-1) ?? runDir,
        runDir,
        status,
        assessment,
        verdict: deriveVerdict({ status, assessment }),
        profileName: normalized.profileName,
        model: normalized.model,
        dedupeLabel: formatDedupeLabel(config, runtimeConfig),
        generated,
        delivered,
        ordered,
        duplicatesInjected,
        duplicateLeakage,
        duplicateLeakageRatio,
        anomalies,
        late,
        lateRatio: delivered > 0 ? late / delivered : 0,
        warnings,
        errors,
        maxQueue,
        wallElapsedMs,
        peakRssMb,
        lastRssMb,
        activeWindowSeconds: dedupeWindow.activeWindowSeconds,
        configuredFloorSeconds: dedupeWindow.configuredFloorSeconds,
        configuredMaxSeconds: dedupeWindow.configuredMaxSeconds,
        violatesConfiguredFloor: dedupeWindow.violatesConfiguredFloor,
        hasDedupeTelemetry: Object.keys(dedupe).length > 0,
        acceptedEvents,
        droppedDuplicates,
        currentCacheSize: normalized.currentCacheSize,
        peakDedupeCacheSize,
        hasMonitorTelemetry: Boolean(monitor?.enabled),
        monitorScenarioId: typeof monitor?.scenarioId === "string" ? monitor.scenarioId : null,
        monitorBufferedEvents: Number(monitor?.bufferedEvents ?? 0),
        monitorForwardedToDedupe: Number(monitor?.forwardedToDedupe ?? 0),
        monitorForwardedToOrder: Number(monitor?.forwardedToOrder ?? 0),
        monitorPendingRows: Number(monitor?.pendingRows ?? monitor?.lastSnapshot?.reservoir?.totalPendingRows ?? 0),
        monitorSawNormalFlow: monitorAnalysis.sawNormalFlow,
        monitorSawDedupeBypass: monitorAnalysis.sawDedupeBypass,
        monitorSawOrderBufferOnly: monitorAnalysis.sawOrderBufferOnly,
        monitorSawReplayThroughDedupe: monitorAnalysis.sawReplayThroughDedupe,
        monitorEndedDrained: monitorAnalysis.endedDrained,
        monitorReplayPath: monitorReplayLifecycle.path,
        monitorReplaySessionsStarted: monitorReplayLifecycle.startedSessions,
        monitorReplaySessionsCompleted: monitorReplayLifecycle.completedSessions,
        monitorReplaySessionsFailed: monitorReplayLifecycle.failedSessions,
        monitorLatestFailedNextRetryAt: monitorReplayLifecycle.latestFailedNextRetryAt === null ||
            monitorReplayLifecycle.latestFailedNextRetryAt === undefined
            ? null
            : String(monitorReplayLifecycle.latestFailedNextRetryAt),
        monitorTransitionSummary,
        monitorRetryWaitingRows: Number(monitorAnalysis.retryWaitingRows ??
            monitor?.lastSnapshot?.reservoir?.retryWaitingRows ??
            0),
        monitorReplayNextRetryAt: monitorAnalysis.replayNextRetryAt === null ||
            monitorAnalysis.replayNextRetryAt === undefined
            ? null
            : String(monitorAnalysis.replayNextRetryAt),
        monitorReplayConsecutiveFailureCount: Number(monitorAnalysis.replayConsecutiveFailureCount ?? 0),
        monitorReplayFailureInjected: Boolean(monitorAnalysis.replayFailureInjected),
    };
}
function detectSummaryKind(summary) {
    if (summary?.generator &&
        summary?.ordering &&
        summary?.timing?.wallStartedAtIso !== undefined) {
        return "wallclock-transport";
    }
    return "adapter-runtime";
}
function normalizeSummary(summary) {
    const kind = detectSummaryKind(summary);
    if (kind === "wallclock-transport") {
        const outcome = summary.outcome ?? {};
        const config = summary.config ?? {};
        const timing = summary.timing ?? {};
        const generator = summary.generator ?? {};
        const transport = summary.transport ?? {};
        const ordering = summary.ordering ?? {};
        const dedupe = summary.dedupe ?? {};
        return {
            kind,
            status: String(outcome.status ?? "unknown"),
            model: "transport_adapter",
            profileName: String(config.profile ?? "unknown"),
            generated: Number(generator.generatedEvents ?? 0),
            delivered: Number(transport.receivedEvents ?? generator.sentEvents ?? 0),
            ordered: Number(ordering.orderedEvents ?? 0),
            anomalies: Number(ordering.anomalies ?? 0),
            late: Number(ordering.byAnomalyType?.late_arrival ?? 0),
            warnings: Number(ordering.byAnomalySeverity?.warning ?? 0),
            errors: Number(ordering.byAnomalySeverity?.error ?? 0),
            duplicatesInjected: Number(generator.duplicatesInjected ?? 0),
            acceptedEvents: Number(dedupe.acceptedEvents ?? 0),
            droppedDuplicates: Number(dedupe.droppedDuplicates ?? 0),
            maxQueue: Number(transport.maxEventQueueDepth ?? 0),
            wallElapsedMs: Number(timing.wallElapsedMs ?? 0),
            currentCacheSize: Number(dedupe.cacheSize ?? 0),
        };
    }
    const outcome = summary.outcome ?? {};
    const timing = summary.timing ?? {};
    const config = summary.config ?? {};
    const stream = summary.stream ?? {};
    const simulation = summary.simulation ?? {};
    const transport = summary.transport ?? {};
    const dedupe = summary.dedupe ?? {};
    return {
        kind,
        status: String(outcome.status ?? "unknown"),
        model: String(config.model ?? "single_process"),
        profileName: String(config.profileName ?? "unknown"),
        generated: Number(simulation.generated ?? 0),
        delivered: Number(simulation.delivered ?? transport.receivedEvents ?? simulation.sent ?? 0),
        ordered: Number(stream.orderedEvents ?? 0),
        anomalies: Number(stream.anomalies ?? 0),
        late: Number(stream.byAnomalyType?.late_arrival ?? 0),
        warnings: Number(stream.byAnomalySeverity?.warning ?? 0),
        errors: Number(stream.byAnomalySeverity?.error ?? 0),
        duplicatesInjected: Number(simulation.duplicatesInjected ?? 0),
        acceptedEvents: Number(dedupe.acceptedEvents ?? 0),
        droppedDuplicates: Number(dedupe.droppedDuplicates ?? 0),
        maxQueue: Number(simulation.maxQueueDepth ?? simulation.maxPendingQueueDepth ?? 0),
        wallElapsedMs: Number(timing.wallElapsedMs ?? 0),
        currentCacheSize: Number(dedupe.currentCacheSize ?? 0),
    };
}
async function loadNdjson(path) {
    if (!existsSync(path)) {
        return [];
    }
    const rows = [];
    for (const line of (await readFile(path, "utf8")).split(/\r?\n/)) {
        if (line.trim()) {
            rows.push(JSON.parse(line));
        }
    }
    return rows;
}
async function loadPreferredNdjson(runDir, filenames) {
    for (const filename of filenames) {
        const path = resolve(runDir, filename);
        if (existsSync(path)) {
            return loadNdjson(path);
        }
    }
    return [];
}
async function loadOptionalJson(path) {
    if (!existsSync(path)) {
        return null;
    }
    return JSON.parse(await readFile(path, "utf8"));
}
function formatDedupeLabel(summaryConfig, runtimeConfig) {
    const dedupeConfig = summaryConfig.dedupeConfig ?? runtimeConfig?.dedupeConfig ?? {};
    if (typeof dedupeConfig.preset === "string" && dedupeConfig.preset.trim()) {
        return `preset:${dedupeConfig.preset}`;
    }
    const sliding = dedupeConfig.slidingWindowSeconds;
    const maxSliding = dedupeConfig.maxSlidingWindowSeconds;
    if (sliding !== undefined && maxSliding !== undefined) {
        return `manual:${sliding}/${maxSliding}s`;
    }
    return "unknown";
}
function resolveDedupeWindow(summary, runtimeConfig) {
    const dedupe = summary.dedupe ?? {};
    const dedupeConfig = summary.config?.dedupeConfig ?? runtimeConfig?.dedupeConfig ?? {};
    const activeWindowSeconds = toFiniteNumberOrNull(dedupe.activeWindowSeconds);
    const configuredFloorSeconds = toFiniteNumberOrNull(dedupeConfig.slidingWindowSeconds);
    const configuredMaxSeconds = toFiniteNumberOrNull(dedupeConfig.maxSlidingWindowSeconds);
    return {
        activeWindowSeconds,
        configuredFloorSeconds,
        configuredMaxSeconds,
        violatesConfiguredFloor: activeWindowSeconds !== null &&
            configuredFloorSeconds !== null &&
            activeWindowSeconds + 1e-9 < configuredFloorSeconds,
    };
}
function toFiniteNumberOrNull(value) {
    const numeric = Number(value);
    return Number.isFinite(numeric) ? numeric : null;
}
function buildComparisonReport(left, right) {
    const lines = [];
    lines.push(`Compare: ${left.name} -> ${right.name}`);
    lines.push(`Profiles: ${left.profileName} vs ${right.profileName} | Dedupe: ${left.dedupeLabel} vs ${right.dedupeLabel}`);
    lines.push(`Paths: ${left.runDir} | ${right.runDir}`);
    lines.push("");
    lines.push(`Verdict: ${left.verdict} -> ${right.verdict} | Status: ${left.status} -> ${right.status}`);
    lines.push(`Wall: ${formatDurationMs(left.wallElapsedMs)} -> ${formatDurationMs(right.wallElapsedMs)}`);
    lines.push(`Traffic: generated=${left.generated} -> ${right.generated} | delivered=${left.delivered} -> ${right.delivered} | ordered=${left.ordered} -> ${right.ordered}`);
    lines.push(`Duplicate leakage: ${formatLeakage(left)} -> ${formatLeakage(right)} | delta=${formatDeltaNumber(right.duplicateLeakage - left.duplicateLeakage)}`);
    lines.push(`Late ratio: ${formatPercent(left.lateRatio)} -> ${formatPercent(right.lateRatio)} | delta=${formatSignedPercent(right.lateRatio - left.lateRatio)}`);
    lines.push(`Queue peak: ${left.maxQueue} -> ${right.maxQueue} | delta=${formatDeltaNumber(right.maxQueue - left.maxQueue)}`);
    lines.push(`Anomalies: total=${left.anomalies} -> ${right.anomalies} | warn=${left.warnings} -> ${right.warnings} | error=${left.errors} -> ${right.errors}`);
    lines.push(`Dedupe window: ${formatWindow(left)} -> ${formatWindow(right)}`);
    lines.push(`Dedupe validation: ${formatDedupeValidation(left)} -> ${formatDedupeValidation(right)}`);
    if (left.hasMonitorTelemetry || right.hasMonitorTelemetry) {
        lines.push(`Monitor scenario: ${formatMonitorScenario(left)} -> ${formatMonitorScenario(right)}`);
        lines.push(`Monitor buffered: ${left.monitorBufferedEvents} -> ${right.monitorBufferedEvents} | delta=${formatDeltaNumber(right.monitorBufferedEvents - left.monitorBufferedEvents)}`);
        lines.push(`Monitor route-to-dedupe: ${left.monitorForwardedToDedupe} -> ${right.monitorForwardedToDedupe} | route-to-order: ${left.monitorForwardedToOrder} -> ${right.monitorForwardedToOrder}`);
        lines.push(`Monitor posture: ${formatMonitorPosture(left)} -> ${formatMonitorPosture(right)}`);
        lines.push(`Monitor replay: ${formatMonitorReplay(left)} -> ${formatMonitorReplay(right)}`);
        lines.push(`Monitor retry: waiting=${left.monitorRetryWaitingRows} -> ${right.monitorRetryWaitingRows} | failures=${left.monitorReplayConsecutiveFailureCount} -> ${right.monitorReplayConsecutiveFailureCount} | injected=${formatYesNo(left.monitorReplayFailureInjected)} -> ${formatYesNo(right.monitorReplayFailureInjected)}`);
        lines.push(`Monitor replay failures: sessions=${left.monitorReplaySessionsFailed} -> ${right.monitorReplaySessionsFailed} | latestNextRetryAt=${formatNullable(left.monitorLatestFailedNextRetryAt)} -> ${formatNullable(right.monitorLatestFailedNextRetryAt)}`);
        lines.push(`Monitor transitions: ${formatMonitorTransitions(left)} -> ${formatMonitorTransitions(right)}`);
    }
    if (left.peakRssMb !== null || right.peakRssMb !== null) {
        lines.push(`Peak RSS: ${formatMaybeMb(left.peakRssMb)} -> ${formatMaybeMb(right.peakRssMb)} | delta=${formatDeltaMb(deltaMaybe(left.peakRssMb, right.peakRssMb))}`);
    }
    lines.push("Equilibrium:");
    lines.push(`  Correctness: ${describeCorrectness(left)} -> ${describeCorrectness(right)}`);
    lines.push(`  Pressure: ${describePressure(left)} -> ${describePressure(right)}`);
    lines.push(`  Backlog: ${describeBacklog(left)} -> ${describeBacklog(right)}`);
    lines.push("Reading:");
    for (const line of buildReading(left, right)) {
        lines.push(`  - ${line}`);
    }
    return lines.join("\n");
}
function buildReading(left, right) {
    const notes = [];
    if (left.profileName !== right.profileName) {
        notes.push("the two runs use different workload profiles, so treat the comparison as directional rather than apples-to-apples");
    }
    if (left.violatesConfiguredFloor || right.violatesConfiguredFloor) {
        if (!left.violatesConfiguredFloor && right.violatesConfiguredFloor) {
            notes.push("the newer run drifted below its configured dedupe floor, so this is not a trustworthy tuning comparison");
        }
        else if (left.violatesConfiguredFloor && !right.violatesConfiguredFloor) {
            notes.push("the older run drifted below its configured dedupe floor, so part of the apparent improvement may simply be config correctness");
        }
        else {
            notes.push("both runs drifted below their configured dedupe floors, so treat the comparison as invalid for tuning");
        }
    }
    if (left.errors === 0 && right.errors === 0) {
        notes.push("both runs preserved correctness at the error-level gate, so the comparison is mainly about pressure, backlog, and duplicate leakage");
    }
    else if (right.errors < left.errors) {
        notes.push("the newer run reduced error-level anomalies, which is the strongest correctness improvement");
    }
    else if (right.errors > left.errors) {
        notes.push("the newer run introduced more error-level anomalies, which is a meaningful regression even if other metrics improved");
    }
    if (right.duplicateLeakage < left.duplicateLeakage) {
        notes.push("duplicate leakage improved in the newer run");
    }
    else if (right.duplicateLeakage > left.duplicateLeakage) {
        notes.push("duplicate leakage worsened in the newer run");
    }
    else {
        notes.push("duplicate leakage was unchanged between the two runs");
    }
    if (right.lateRatio < left.lateRatio) {
        notes.push("the newer run saw a lower late-arrival ratio");
    }
    else if (right.lateRatio > left.lateRatio) {
        notes.push("the newer run saw a higher late-arrival ratio");
    }
    if (right.maxQueue < left.maxQueue) {
        notes.push("backlog pressure eased in the newer run");
    }
    else if (right.maxQueue > left.maxQueue) {
        notes.push("backlog pressure increased in the newer run");
    }
    if (left.hasMonitorTelemetry || right.hasMonitorTelemetry) {
        if (!left.hasMonitorTelemetry && right.hasMonitorTelemetry) {
            notes.push("the newer run includes monitor telemetry, so recovery posture is more directly inspectable");
        }
        else if (left.hasMonitorTelemetry && !right.hasMonitorTelemetry) {
            notes.push("the newer run does not include monitor telemetry, so recovery posture cannot be compared directly");
        }
        else {
            if (!left.monitorEndedDrained && right.monitorEndedDrained) {
                notes.push("the newer run finished with a drained monitor reservoir, which is a meaningful recovery improvement");
            }
            else if (left.monitorEndedDrained && !right.monitorEndedDrained) {
                notes.push("the newer run finished with monitor backlog still pending, which is a recovery regression");
            }
            if (left.monitorReplaySessionsCompleted !== right.monitorReplaySessionsCompleted) {
                notes.push(`replay session count changed from ${left.monitorReplaySessionsCompleted} to ${right.monitorReplaySessionsCompleted}, which may reflect different batching or recovery churn`);
            }
            if (!left.monitorSawOrderBufferOnly && right.monitorSawOrderBufferOnly) {
                notes.push("the newer run exercised order-buffer-only outage behavior where the older run did not");
            }
            if (left.monitorSawDedupeBypass !== right.monitorSawDedupeBypass) {
                notes.push("dedupe-bypass participation changed between the two runs");
            }
        }
    }
    if (right.lateRatio > left.lateRatio && right.maxQueue <= left.maxQueue && right.errors === 0) {
        notes.push("the newer run absorbed more lateness without extra backlog, which suggests stronger operational elasticity");
    }
    else if (right.lateRatio > left.lateRatio &&
        right.maxQueue > left.maxQueue &&
        right.errors === 0) {
        notes.push("the newer run stayed correct under higher pressure, but the added lateness also pushed backlog higher");
    }
    if (notes.length === 0) {
        notes.push("no strong directional difference stood out in the selected metrics");
    }
    return notes;
}
function assessRun(input) {
    const reasons = [];
    if (input.status === "failed") {
        reasons.push("the run ended with a failed status");
        return { assessment: "failed", reasons };
    }
    if (input.errors > 0) {
        reasons.push(`${input.errors} error-level anomalies were recorded`);
    }
    if (input.dedupeWindow.violatesConfiguredFloor) {
        reasons.push("active dedupe window fell below the configured floor");
    }
    if (input.late > 0 && input.delivered > 0) {
        const lateRatio = input.late / input.delivered;
        if (lateRatio >= 0.5) {
            reasons.push("late arrivals were very high");
        }
        else if (lateRatio >= 0.2) {
            reasons.push("late arrivals were elevated");
        }
    }
    if (input.maxQueue > 0 && input.generated > 0) {
        const queueRatio = input.maxQueue / input.generated;
        if (queueRatio >= 0.5) {
            reasons.push("queue backlog grew large relative to generated volume");
        }
        else if (queueRatio >= 0.2) {
            reasons.push("queue backlog was noticeable");
        }
    }
    const orderingInputCount = input.accepted > 0 ? input.accepted : input.delivered;
    if (input.ordered < orderingInputCount) {
        const source = input.accepted > 0 ? "accepted" : "delivered";
        reasons.push(`ordered count ended below ${source} count`);
    }
    if (input.status === "interrupted") {
        reasons.push("the run was interrupted before a normal completion");
    }
    if (input.status === "completed" && reasons.length === 0 && input.anomalies === 0) {
        return { assessment: "healthy", reasons };
    }
    if (input.status === "completed" && reasons.length === 0) {
        return { assessment: "healthy", reasons };
    }
    if (input.status === "completed") {
        if (input.dedupeWindow.violatesConfiguredFloor) {
            return { assessment: "invalid", reasons };
        }
        return { assessment: "degraded", reasons };
    }
    return { assessment: input.status, reasons };
}
function deriveVerdict(input) {
    if (input.status === "failed") {
        return "FAIL";
    }
    if (input.status === "interrupted") {
        return "INTERRUPTED";
    }
    if (input.status === "completed" && input.assessment === "invalid") {
        return "INVALID CONFIG";
    }
    if (input.status === "completed" && input.assessment === "healthy") {
        return "PASS";
    }
    if (input.status === "completed" && input.assessment === "degraded") {
        return "PASS WITH STRESS";
    }
    return input.status.toUpperCase();
}
function formatDurationMs(milliseconds) {
    if (!Number.isFinite(milliseconds) || milliseconds <= 0) {
        return "0s";
    }
    const totalSeconds = Math.floor(milliseconds / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    if (hours > 0) {
        return `${hours}h${minutes.toString().padStart(2, "0")}m`;
    }
    if (minutes > 0) {
        return `${minutes}m${seconds.toString().padStart(2, "0")}s`;
    }
    return `${seconds}s`;
}
function formatPercent(value) {
    return value.toLocaleString(undefined, {
        style: "percent",
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });
}
function formatSignedPercent(value) {
    const sign = value > 0 ? "+" : "";
    return `${sign}${formatPercent(value)}`;
}
function formatLeakage(run) {
    const ratio = run.duplicateLeakageRatio === null ? "n/a" : formatPercent(run.duplicateLeakageRatio);
    return `${run.duplicateLeakage}/${run.duplicatesInjected} (${ratio})`;
}
function formatWindow(run) {
    const parts = [`active=${formatMaybeSeconds(run.activeWindowSeconds)}`];
    if (run.configuredFloorSeconds !== null) {
        parts.push(`floor=${run.configuredFloorSeconds}s`);
    }
    if (run.configuredMaxSeconds !== null) {
        parts.push(`max=${run.configuredMaxSeconds}s`);
    }
    if (run.violatesConfiguredFloor) {
        parts.push("below_floor");
    }
    return parts.join(" ");
}
function formatMaybeSeconds(value) {
    return value === null ? "n/a" : `${value}s`;
}
function deriveMonitorAnalysis(monitor) {
    const analysis = monitor.analysis ?? {};
    const routingModes = monitor.routingModes ?? {};
    const deliveryModes = monitor.deliveryModes ?? {};
    const pendingRows = Number(monitor.pendingRows ?? monitor.lastSnapshot?.reservoir?.totalPendingRows ?? 0);
    const retryWaitingRows = Number(monitor.retryWaitingRows ?? monitor.lastSnapshot?.reservoir?.retryWaitingRows ?? 0);
    return {
        sawNormalFlow: Boolean(analysis.sawNormalFlow) || Number(routingModes.normal ?? 0) > 0,
        sawDedupeBypass: Boolean(analysis.sawDedupeBypass) ||
            Number(routingModes.dedupe_bypass_throttled ?? 0) > 0 ||
            Number(deliveryModes.dedupe_bypass_throttled ?? 0) > 0 ||
            Number(monitor.forwardedToOrder ?? 0) > 0,
        sawOrderBufferOnly: Boolean(analysis.sawOrderBufferOnly) ||
            Number(routingModes.order_buffer_only ?? 0) > 0,
        sawReplayThroughDedupe: Boolean(analysis.sawReplayThroughDedupe) ||
            Number(routingModes.replay_through_dedupe ?? 0) > 0,
        endedDrained: Boolean(analysis.endedDrained) || pendingRows === 0,
        retryWaitingRows,
        replayNextRetryAt: analysis.replayNextRetryAt ??
            monitor.replayNextRetryAt ??
            monitor.lastReplaySnapshot?.nextRetryAt ??
            null,
        replayConsecutiveFailureCount: Number(analysis.replayConsecutiveFailureCount ??
            monitor.replayConsecutiveFailureCount ??
            monitor.lastReplaySnapshot?.consecutiveFailureCount ??
            0),
        replayFailureInjected: Boolean(analysis.replayFailureInjected ?? monitor.replayFailureInjected),
    };
}
function summarizeReplayLifecycle(rows) {
    const path = [];
    let previousState = null;
    let startedSessions = 0;
    let completedSessions = 0;
    let failedSessions = 0;
    let latestFailedNextRetryAt = null;
    for (const row of rows) {
        const state = row.snapshot?.state;
        if (typeof state !== "string") {
            continue;
        }
        if (state !== previousState) {
            if (!path.includes(state)) {
                path.push(state);
            }
            if (state === "running") {
                startedSessions += 1;
            }
            if (state === "completed") {
                completedSessions += 1;
            }
            if (state === "failed") {
                failedSessions += 1;
                latestFailedNextRetryAt = row.snapshot?.nextRetryAt ?? latestFailedNextRetryAt;
            }
            previousState = state;
        }
    }
    return {
        path,
        startedSessions,
        completedSessions,
        failedSessions,
        latestFailedNextRetryAt,
    };
}
function summarizeScenarioTransitions(rows) {
    const byComponent = new Map();
    for (const row of rows) {
        if (row.event !== "scenario_transition") {
            continue;
        }
        const component = typeof row.component === "string" ? row.component : null;
        const state = typeof row.state === "string" ? row.state : null;
        if (!component || !state) {
            continue;
        }
        const sequence = byComponent.get(component) ?? [];
        if (sequence.at(-1) !== state) {
            sequence.push(state);
        }
        byComponent.set(component, sequence);
    }
    return [...byComponent.entries()]
        .sort(([left], [right]) => left.localeCompare(right))
        .map(([component, sequence]) => `${component}=${sequence.join(" -> ")}`);
}
function formatMonitorScenario(run) {
    return run.hasMonitorTelemetry ? run.monitorScenarioId ?? "enabled" : "n/a";
}
function formatMonitorPosture(run) {
    if (!run.hasMonitorTelemetry) {
        return "n/a";
    }
    return [
        `normal=${formatYesNo(run.monitorSawNormalFlow)}`,
        `dedupe_bypass=${formatYesNo(run.monitorSawDedupeBypass)}`,
        `order_buffer=${formatYesNo(run.monitorSawOrderBufferOnly)}`,
        `replay=${formatYesNo(run.monitorSawReplayThroughDedupe)}`,
        `drained=${formatYesNo(run.monitorEndedDrained)}`,
        `pending=${run.monitorPendingRows}`,
    ].join(" | ");
}
function formatMonitorReplay(run) {
    if (!run.hasMonitorTelemetry) {
        return "n/a";
    }
    const path = run.monitorReplayPath.length > 0 ? run.monitorReplayPath.join(" -> ") : "none";
    return `${path} | sessions=${run.monitorReplaySessionsCompleted}/${run.monitorReplaySessionsStarted}`;
}
function formatMonitorTransitions(run) {
    if (!run.hasMonitorTelemetry) {
        return "n/a";
    }
    return run.monitorTransitionSummary.length > 0
        ? run.monitorTransitionSummary.join(" | ")
        : "none";
}
function formatNullable(value) {
    return value ?? "n/a";
}
function formatYesNo(value) {
    return value ? "yes" : "no";
}
function formatDedupeValidation(run) {
    if (!run.hasDedupeTelemetry) {
        return "telemetry=missing";
    }
    const configStatus = run.violatesConfiguredFloor
        ? "invalid"
        : run.configuredFloorSeconds !== null
            ? "ok"
            : "observed";
    const parts = [`config=${configStatus}`];
    if (run.acceptedEvents === 0 && run.generated > 0) {
        parts.push("traffic=suspicious");
    }
    else if (run.acceptedEvents === 0) {
        parts.push("traffic=idle");
    }
    else {
        parts.push("traffic=ok");
    }
    if (run.duplicatesInjected > 0 && run.droppedDuplicates === 0) {
        parts.push("suppression=warning");
    }
    else if (run.droppedDuplicates > 0) {
        parts.push("suppression=active");
    }
    else {
        parts.push("suppression=idle");
    }
    const pressureRatio = run.acceptedEvents > 0 ? run.peakDedupeCacheSize / run.acceptedEvents : 0;
    if (run.acceptedEvents === 0) {
        parts.push("pressure=unknown");
    }
    else if (pressureRatio >= 0.01) {
        parts.push("pressure=warning");
    }
    else if (pressureRatio >= 0.002) {
        parts.push("pressure=noticeable");
    }
    else {
        parts.push("pressure=controlled");
    }
    return parts.join(" ");
}
function describeCorrectness(run) {
    if (run.errors > 0) {
        return `degraded (${run.errors} error anomalies)`;
    }
    const orderingInputCount = run.acceptedEvents > 0 ? run.acceptedEvents : run.delivered;
    if (run.ordered < orderingInputCount) {
        const source = run.acceptedEvents > 0 ? "accepted" : "delivered";
        return `degraded (ordered below ${source})`;
    }
    if (run.duplicateLeakage === 0) {
        return "strong (no leaked duplicates observed)";
    }
    return `strong (${run.duplicateLeakage} leaked duplicates, ${formatPercent(run.duplicateLeakageRatio ?? 0)})`;
}
function describePressure(run) {
    if (run.lateRatio >= 0.5) {
        return `extreme (${formatPercent(run.lateRatio)} late)`;
    }
    if (run.lateRatio >= 0.2) {
        return `high (${formatPercent(run.lateRatio)} late)`;
    }
    if (run.lateRatio >= 0.05) {
        return `moderate (${formatPercent(run.lateRatio)} late)`;
    }
    return `low (${formatPercent(run.lateRatio)} late)`;
}
function describeBacklog(run) {
    const queueRatio = run.generated > 0 ? run.maxQueue / run.generated : 0;
    if (queueRatio >= 0.5) {
        return `heavy (${run.maxQueue} peak queue)`;
    }
    if (queueRatio >= 0.2) {
        return `elevated (${run.maxQueue} peak queue)`;
    }
    return `controlled (${run.maxQueue} peak queue)`;
}
function formatDeltaNumber(value) {
    return `${value > 0 ? "+" : ""}${value}`;
}
function formatMaybeMb(value) {
    return value === null ? "n/a" : `${value.toFixed(1)}MB`;
}
function formatDeltaMb(value) {
    return value === null ? "n/a" : `${value > 0 ? "+" : ""}${value.toFixed(1)}MB`;
}
function deltaMaybe(left, right) {
    if (left === null || right === null) {
        return null;
    }
    return right - left;
}
main();

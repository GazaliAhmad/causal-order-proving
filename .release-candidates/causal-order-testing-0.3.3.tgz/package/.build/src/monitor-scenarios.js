export const monitorScenarioDefinitions = Object.freeze([
    {
        id: "monitor-healthy-rolling-4h",
        kind: "healthy",
        aliases: [],
    },
    {
        id: "monitor-transport-outage-burst",
        kind: "transport_outage",
        aliases: [],
    },
    {
        id: "monitor-dedupe-outage",
        kind: "dedupe_bypass",
        aliases: ["monitor-dedupe-bypass"],
    },
    {
        id: "monitor-order-outage",
        kind: "order_outage",
        aliases: ["monitor-recovery-through-dedupe"],
    },
    {
        id: "monitor-dual-outage",
        kind: "dual_outage",
        aliases: [],
    },
    {
        id: "monitor-transport-dedupe-outage",
        kind: "transport_dedupe_outage",
        aliases: [],
    },
    {
        id: "monitor-transport-order-outage",
        kind: "transport_order_outage",
        aliases: [],
    },
    {
        id: "monitor-transport-dedupe-order-outage",
        kind: "transport_dedupe_order_outage",
        aliases: ["monitor-all-outages"],
    },
    {
        id: "monitor-replay-retry-backoff",
        kind: "replay_retry",
        aliases: [],
    },
]);
const definitionsById = new Map();
for (const definition of monitorScenarioDefinitions) {
    definitionsById.set(definition.id, definition);
    for (const alias of definition.aliases) {
        definitionsById.set(alias, definition);
    }
}
export function resolveMonitorScenario(scenarioId) {
    if (scenarioId === null) {
        return null;
    }
    const definition = definitionsById.get(scenarioId);
    if (!definition) {
        throw new Error(`Unsupported monitor scenario: ${scenarioId}. Supported scenarios: ${monitorScenarioDefinitions
            .flatMap((entry) => [entry.id, ...entry.aliases])
            .join(", ")}`);
    }
    return definition;
}
export function resolveMonitorScenarioId(scenarioId) {
    return resolveMonitorScenario(scenarioId)?.id ?? null;
}
export function monitorScenarioIncludesTransport(scenario) {
    return (scenario?.kind === "transport_outage" ||
        scenario?.kind === "transport_dedupe_outage" ||
        scenario?.kind === "transport_order_outage" ||
        scenario?.kind === "transport_dedupe_order_outage");
}
export function monitorScenarioIncludesDedupeOutage(scenario) {
    return (scenario?.kind === "dedupe_bypass" ||
        scenario?.kind === "dual_outage" ||
        scenario?.kind === "transport_dedupe_outage" ||
        scenario?.kind === "transport_dedupe_order_outage");
}
export function monitorScenarioIncludesOrderOutage(scenario) {
    return (scenario?.kind === "order_outage" ||
        scenario?.kind === "dual_outage" ||
        scenario?.kind === "replay_retry" ||
        scenario?.kind === "transport_order_outage" ||
        scenario?.kind === "transport_dedupe_order_outage");
}

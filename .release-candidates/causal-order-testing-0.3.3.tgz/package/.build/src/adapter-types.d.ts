import type { SimulationEvent } from "./deployment-common.js";
export interface HarnessEventContext {
    peerId?: string;
    connectionId?: string;
    receivedAtMs?: bigint;
    rawMessage?: unknown;
}
export interface HarnessPeerState {
    peerId: string;
    connectionId?: string;
    status: "connecting" | "connected" | "disconnected" | "error";
    detail?: string;
}
export interface HarnessError {
    peerId?: string;
    connectionId?: string;
    detail: string;
    cause?: unknown;
}
export interface HarnessAdapterOptions {
    nodeIds: string[];
    runDir: string;
    log?: (message: string) => void;
}
export interface HarnessAdapter {
    start(): Promise<void>;
    /**
     * Stops ingress and settles only after all transport callbacks have quiesced.
     * Event, peer-state, and error callbacks remain valid while this promise is
     * pending; no new callback may be issued after it resolves.
     */
    stop(): Promise<void>;
    send(event: SimulationEvent): Promise<void>;
    /**
     * Explicitly disconnects or reconnects one harness node for published
     * transport fault scenarios. Sends accepted while disconnected settle after
     * the node reconnects.
     */
    setNodeConnectivity?(nodeId: string, state: "connected" | "disconnected"): Promise<void>;
    onEvent(handler: (event: SimulationEvent, context: HarnessEventContext) => void): () => void;
    onPeerState(handler: (state: HarnessPeerState) => void): () => void;
    onError(handler: (error: HarnessError) => void): () => void;
}
export type HarnessAdapterFactory = (options: HarnessAdapterOptions) => Promise<HarnessAdapter> | HarnessAdapter;

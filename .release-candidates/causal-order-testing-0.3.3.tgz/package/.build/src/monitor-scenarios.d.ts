export type CanonicalMonitorScenarioId = "monitor-healthy-rolling-4h" | "monitor-transport-outage-burst" | "monitor-dedupe-outage" | "monitor-order-outage" | "monitor-dual-outage" | "monitor-transport-dedupe-outage" | "monitor-transport-order-outage" | "monitor-transport-dedupe-order-outage" | "monitor-replay-retry-backoff";
export type MonitorScenarioKind = "healthy" | "transport_outage" | "dedupe_bypass" | "order_outage" | "dual_outage" | "transport_dedupe_outage" | "transport_order_outage" | "transport_dedupe_order_outage" | "replay_retry";
export interface MonitorScenarioDefinition {
    id: CanonicalMonitorScenarioId;
    kind: MonitorScenarioKind;
    aliases: readonly string[];
}
export declare const monitorScenarioDefinitions: readonly MonitorScenarioDefinition[];
export declare function resolveMonitorScenario(scenarioId: string | null): MonitorScenarioDefinition | null;
export declare function resolveMonitorScenarioId(scenarioId: string | null): CanonicalMonitorScenarioId | null;
export declare function monitorScenarioIncludesTransport(scenario: MonitorScenarioDefinition | null): boolean;
export declare function monitorScenarioIncludesDedupeOutage(scenario: MonitorScenarioDefinition | null): boolean;
export declare function monitorScenarioIncludesOrderOutage(scenario: MonitorScenarioDefinition | null): boolean;

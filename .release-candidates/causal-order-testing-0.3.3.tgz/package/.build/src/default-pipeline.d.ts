import type { HarnessPipelineProvider } from "./pipeline-types.js";
export declare const harnessPipeline: HarnessPipelineProvider;
export default harnessPipeline;

import type { HarnessAdapter } from "./adapter-types.js";
import type { HarnessMonitorAdapter } from "./pipeline-types.js";
type JsonRecord = Record<string, any>;
export type ShutdownPhase = "running" | "ingress_stopping" | "ingress_stopped" | "transport_stopping" | "transport_stopped" | "monitor_operations_draining" | "monitor_recovering" | "monitor_drained" | "lifecycle_draining" | "order_draining" | "evidence_finalizing" | "resources_closed";
export type ShutdownMilestone = "ingress_stopped" | "adapter_stop_started" | "adapter_stop_resolved" | "monitor_operations_drained" | "final_reconcile_started" | "monitor_terminal" | "lifecycle_drained" | "event_queue_closed" | "ordering_settled" | "verdict_derived";
export interface ShutdownOperationTracker {
    drain(): Promise<void>;
    getSnapshot(): Record<string, number>;
}
export interface ShutdownEventQueue {
    close(): void;
}
export interface MonitorTerminalEvidence {
    snapshot: JsonRecord;
    replaySnapshot: JsonRecord;
    operatorSnapshot: JsonRecord | null;
}
export interface LifecycleTerminalEvidence {
    flush: JsonRecord;
    snapshot: JsonRecord;
}
export interface ShutdownCoordinatorOptions {
    adapter: HarnessAdapter;
    monitorAdapter: HarnessMonitorAdapter | null;
    monitorOperations: ShutdownOperationTracker;
    eventQueue: ShutdownEventQueue;
    orderingPromise: Promise<void>;
    shutdownTimeoutMs: number;
    replayBatchSize: number;
    simulationNowMs: () => bigint;
    timeScale: number;
    drainIngress: () => Promise<void>;
    stopPeriodicRecovery: () => void;
    markTransportCallbackBoundaryClosed: () => void;
    markTransportCallbackBoundaryUnsafe: () => void;
    getTransportCallbackViolation: () => Error | null;
    observeRecoveryHealth?: () => Promise<void> | void;
    captureTransportEvidence?: () => void;
    captureMonitorEvidence?: (evidence: MonitorTerminalEvidence) => void;
    captureLifecycleEvidence?: (evidence: LifecycleTerminalEvidence) => void;
    captureOrderingEvidence?: () => void;
    onPhase?: (phase: ShutdownPhase) => void;
    onMilestone?: (milestone: ShutdownMilestone) => void;
    now?: () => number;
}
export interface FailureCleanupResult {
    errors: TerminalDrainError[];
    transportStopped: boolean;
    monitorOperationsDrained: boolean;
    lifecycleDrained: boolean;
    orderingSettled: boolean;
}
export declare class TerminalDrainError extends Error {
    readonly phase: ShutdownPhase;
    readonly state: JsonRecord;
    readonly code = "ERR_TESTING_TERMINAL_DRAIN";
    constructor(phase: ShutdownPhase, message: string, state?: JsonRecord);
}
export declare class ShutdownCoordinator {
    #private;
    readonly options: ShutdownCoordinatorOptions;
    constructor(options: ShutdownCoordinatorOptions);
    get phase(): ShutdownPhase;
    get eventQueueClosed(): boolean;
    get completedPhases(): ReadonlyArray<ShutdownPhase>;
    get lastCompletedPhase(): ShutdownPhase | null;
    runToEvidenceReady(): Promise<void>;
    markVerdictDerived(): void;
    markFailureVerdictDerived(): void;
    closeResources(close: () => Promise<void> | void): Promise<void>;
    closeResourcesForFailureCleanup(close: () => Promise<void> | void): Promise<void>;
    closeEventQueueForFailureCleanup(): void;
    runFailureCleanup(): Promise<FailureCleanupResult>;
}
export declare function isMonitorRecoveryComplete(evidence: MonitorTerminalEvidence): boolean;
export {};

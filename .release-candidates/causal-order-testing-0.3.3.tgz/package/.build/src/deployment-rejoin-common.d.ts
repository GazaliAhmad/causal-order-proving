import { type RuntimeConfig } from "./deployment-common.js";
export interface RejoinShapingConfig {
    recoveryWindowMs: bigint;
    tokenRatePerSecond: number;
    burstSize: number;
}
export declare const DEFAULT_REJOIN_SHAPING_CONFIG: RejoinShapingConfig;
export declare function buildRejoinHarnessConfig(argv: string[]): {
    help: true;
    text: string;
} | {
    runtimeConfig: RuntimeConfig;
    rejoinShaping: RejoinShapingConfig;
};
export declare function formatRejoinHarnessHelp(): string;
export declare function formatRejoinShapingSummary(config: RejoinShapingConfig): string;
export declare function serializeRejoinShapingConfig(config: RejoinShapingConfig): Record<string, unknown>;
export declare function deserializeRejoinShapingConfig(serialized: Record<string, unknown>): RejoinShapingConfig;

import type { RuntimeDedupeConfig, SimulationEvent } from "./deployment-common.js";
import type { DedupeFilterResult } from "@causal-order/dedupe";
export interface HarnessClockAdapter {
    now(): SimulationEvent["clock"];
    receive(clock: SimulationEvent["clock"]): SimulationEvent["clock"];
}
export interface HarnessDedupeAdapter {
    filter(event: SimulationEvent): unknown;
    filterWithResult?(event: SimulationEvent): DedupeFilterResult;
    updateWindow?(seconds: number): void;
    getStats(): Record<string, unknown>;
    destroy(): void;
}
export interface HarnessOrderingOptions {
    batchSize: number;
    maxLateArrivalMs: bigint;
    lateArrivalPolicy: string;
    strict: boolean;
    allowUnknownOrder: boolean;
    detectAnomalies: boolean;
    tieBreaker: string;
}
export interface HarnessOrderingBatch extends Record<string, any> {
}
export interface HarnessMonitorDecisionRecord extends Record<string, any> {
}
export interface HarnessMonitorReplayRecord extends Record<string, any> {
}
export interface HarnessMonitorAdapter {
    ingest(event: SimulationEvent, sourceStreamId?: string | null): Promise<void> | void;
    updateComponentHealth(component: "transport" | "dedupe" | "causal-order", state: "online" | "degraded" | "offline", details?: Record<string, unknown>): Promise<void> | void;
    observeHeartbeat(component: "transport" | "dedupe" | "causal-order", observedAt?: bigint, details?: Record<string, unknown>): Promise<void> | void;
    getSnapshot(): Record<string, unknown>;
    getReplaySnapshot(): Record<string, unknown>;
    getOperatorSnapshot?(): Record<string, unknown>;
    getCapacitySnapshot?(): Record<string, unknown>;
    getLifecycleSnapshot?(): Record<string, unknown>;
    flushLifecycle?(timeoutMs?: bigint): Promise<Record<string, unknown>>;
    reconcileRecovery?(limit?: number): Promise<Record<string, unknown> | null> | Record<string, unknown> | null;
    close(): void;
}
export interface HarnessMonitorAdapterOptions {
    runtimeConfig: unknown;
    nowProvider: () => bigint;
    deliverToDedupe: (event: SimulationEvent, context: Record<string, unknown>) => Promise<void> | void;
    deliverToOrder: (event: SimulationEvent, context: Record<string, unknown>) => Promise<void> | void;
    onBuffered?: (event: SimulationEvent, context: HarnessMonitorDecisionRecord) => Promise<void> | void;
    onDecision?: (event: SimulationEvent, context: HarnessMonitorDecisionRecord) => Promise<void> | void;
    onReplayStateChange?: (snapshot: HarnessMonitorReplayRecord) => Promise<void> | void;
}
export interface HarnessPipelineProvider {
    createClockAdapter(options: {
        nodeId: string;
        now: () => bigint;
    }): HarnessClockAdapter;
    createDedupeAdapter(options: {
        config: RuntimeDedupeConfig;
        nowProvider: () => bigint;
    }): HarnessDedupeAdapter;
    createMonitorAdapter?(options: HarnessMonitorAdapterOptions): Promise<HarnessMonitorAdapter> | HarnessMonitorAdapter;
    orderEvents(source: AsyncIterable<SimulationEvent>, options: HarnessOrderingOptions): AsyncIterable<HarnessOrderingBatch>;
}

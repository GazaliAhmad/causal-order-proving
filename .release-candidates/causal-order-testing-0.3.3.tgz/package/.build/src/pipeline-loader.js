import { pathToFileURL } from "node:url";
import { resolve } from "node:path";
export async function loadHarnessPipeline(specifier) {
    if (!specifier) {
        const mod = await import("./default-pipeline.js");
        return selectProvider(mod, "./default-pipeline.js");
    }
    const isPathLike = specifier.startsWith(".") ||
        specifier.startsWith("/") ||
        /^[A-Za-z]:[\\/]/.test(specifier) ||
        specifier.startsWith("file://");
    const ref = specifier.startsWith("file://")
        ? specifier
        : isPathLike
            ? pathToFileURL(resolve(process.cwd(), specifier)).href
            : specifier;
    const mod = (await import(ref));
    return selectProvider(mod, specifier);
}
function selectProvider(mod, specifier) {
    const provider = mod.harnessPipeline ?? mod.default;
    if (!provider || typeof provider !== "object") {
        throw new Error(`Pipeline module ${specifier} must export harnessPipeline or a default provider object`);
    }
    const candidate = provider;
    if (typeof candidate.createClockAdapter !== "function" ||
        typeof candidate.createDedupeAdapter !== "function" ||
        typeof candidate.orderEvents !== "function") {
        throw new Error(`Pipeline module ${specifier} must implement createClockAdapter(), createDedupeAdapter(), and orderEvents()`);
    }
    return candidate;
}

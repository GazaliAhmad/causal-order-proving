export type LateArrivalPolicy = "flag" | "drop" | "emit_correction" | "fail";
export type DedupePreset = "standard" | "heavy-duplicates" | "high-latency" | "cross-node-busy";
export interface WorkloadProfile {
    name: string;
    description: string;
    nodeWeights: Record<string, number>;
    phaseRates: {
        steadyEventsPerSecond: number;
        chaosMultiplier: number;
        chaosJitterMin: number;
        chaosJitterMax: number;
    };
    dependencies: {
        steadySameNodeChance: number;
        steadyCrossNodeChance: number;
        chaoticSameNodeChance: number;
        chaoticCrossNodeChance: number;
        sameNodeParentChance: number;
        crossNodeParentChance: number;
    };
    duplicates: {
        steadyChance: number;
        chaoticChance: number;
    };
    ordering: {
        steadyPreserveOrderChance: number;
        chaoticPreserveOrderChance: number;
    };
    delays: {
        steady: {
            baseMinMs: number;
            baseMaxMs: number;
            spikeChance: number;
            spikeMinMs: number;
            spikeMaxMs: number;
        };
        chaotic: {
            baseMinMs: number;
            baseMaxMs: number;
            slowSpikeChance: number;
            slowSpikeMinMs: number;
            slowSpikeMaxMs: number;
            lateSpikeChance: number;
            lateSpikeMinMs: number;
            lateSpikeMaxMs: number;
            extremeSpikeChance: number;
            extremeSpikeMinMs: number;
            extremeSpikeMaxMs: number;
        };
    };
}
export interface RuntimeArtifacts {
    runDir: string;
    summaryPath: string;
    heartbeatPath: string;
    anomalyPath: string;
    duplicateLeakPath: string;
    lifecyclePath: string;
    monitorHeartbeatPath: string;
    monitorHealthPath: string;
    monitorReplayPath: string;
    monitorSummaryPath: string;
    configPath: string;
    orchestratorLogPath: string;
    collectorStdoutPath: string;
    collectorStderrPath: string;
    nodesDir: string;
}
export interface FaultInjectionConfig {
    darkNodeIds: string[];
    darkIntervalMs: bigint;
    darkDurationMs: bigint;
    darkStartAfterMs: bigint;
    darkStaggerMs: bigint;
    jitterNodeIds: string[];
    jitterExtraDelayMinMs: bigint;
    jitterExtraDelayMaxMs: bigint;
    jitterSpikeChance: number;
    jitterSpikeMinMs: bigint;
    jitterSpikeMaxMs: bigint;
}
export interface HybridClock extends Record<string, unknown> {
    physicalTimeMs: bigint;
}
export interface EventPayload {
    phase?: string;
    service?: string;
    entityId?: string | null;
    traceId?: string | null;
    operation?: string;
    [key: string]: unknown;
}
export interface SimulationEvent {
    id: string;
    nodeId: string;
    clock: HybridClock;
    payload: EventPayload;
    parentEventId?: string;
    dependencyEventIds?: string[];
    sequence?: bigint;
    traceId?: string | null;
    ingestedAt?: bigint;
    [key: string]: unknown;
}
export interface RuntimeDedupeConfig {
    preset?: string;
    [key: string]: unknown;
}
export interface RuntimeMonitorConfig {
    enabled: boolean;
    moduleSpecifier: string | null;
    databasePath: string | null;
    rollingBufferWindowMs: bigint;
    fullOutageMaxWindowMs: bigint;
    pruneIntervalMs: bigint;
    replayBatchSize: number;
    scenarioId: string | null;
}
export interface HintEvent {
    id: string;
    nodeId: string;
    clock: HybridClock;
    traceId?: string | null;
    entityId?: string | null;
    [key: string]: unknown;
}
export interface RuntimeConfig {
    durationMs: bigint;
    steadyForMs: bigint;
    eventsPerSecond: number;
    chaosMultiplier: number;
    batchSize: number;
    maxLateArrivalMs: bigint;
    maxTailDrainMs: bigint;
    lateArrivalPolicy: LateArrivalPolicy;
    reportEveryMs: bigint;
    timeScale: number;
    outputPath: string | null;
    outputDir: string;
    runName: string | null;
    sampleLimit: number;
    maxLateArrivalSamples: number;
    strict: boolean;
    allowUnknownOrder: boolean;
    detectAnomalies: boolean;
    tieBreaker: string;
    dedupeConfig: RuntimeDedupeConfig;
    nodeIds: string[];
    faultInjection: FaultInjectionConfig;
    workloadProfile: WorkloadProfile;
    profileSource: string | null;
    pipelineModule?: string | null;
    monitorConfig: RuntimeMonitorConfig;
    wallStartMs?: number;
    artifacts?: RuntimeArtifacts;
}
export declare const DEFAULT_WORKLOAD_PROFILE: WorkloadProfile;
export declare const DEFAULT_SINGLE_CLUSTER_NODE_IDS: readonly ["edge-a", "edge-b", "edge-c"];
export declare const DEFAULTS: {
    durationMs: bigint;
    steadyRatio: number;
    eventsPerSecond: number;
    chaosMultiplier: number;
    batchSize: number;
    maxLateArrivalMs: bigint;
    maxTailDrainMs: bigint;
    lateArrivalPolicy: LateArrivalPolicy;
    reportEveryMs: bigint;
    timeScale: number;
    outputDir: string;
    sampleLimit: number;
    maxLateArrivalSamples: number;
    strict: boolean;
    allowUnknownOrder: boolean;
    detectAnomalies: boolean;
    tieBreaker: string;
    dedupePreset: string;
    nodeIds: ("edge-a" | "edge-b" | "edge-c")[];
    profile: string;
    profileFile: string | null;
    pipelineModule: string | null;
    monitorEnabled: boolean;
    monitorModule: string;
    monitorDatabasePath: string | null;
    monitorRollingBufferWindowMs: bigint;
    monitorFullOutageMaxWindowMs: bigint;
    monitorPruneIntervalMs: bigint;
    monitorReplayBatchSize: number;
    monitorScenario: string | null;
    darkNodeIds: string[];
    darkIntervalMs: bigint;
    darkDurationMs: bigint;
    darkStartAfterMs: bigint;
    darkStaggerMs: bigint;
    jitterNodeIds: string[];
    jitterExtraDelayMinMs: bigint;
    jitterExtraDelayMaxMs: bigint;
    jitterSpikeChance: number;
    jitterSpikeMinMs: bigint;
    jitterSpikeMaxMs: bigint;
};
export declare const HELP_TEXT = "Usage:\n  causal-order-testing-runtime [options]\n\nOptions:\n  --duration <value>           Total simulated runtime. Supports ms, s, m, h. Default: 4h\n  --steady-for <value>         Simulated steady phase duration before chaos begins\n  --steady-ratio <0..1>        Portion of total duration spent steady when --steady-for is omitted\n  --events-per-second <n>      Average total steady-state throughput across the whole cluster. Default: 16\n  --chaos-multiplier <n>       Multiplier applied during chaotic phase. Default: 1.8\n  --batch-size <n>             orderEventStream batch size. Default: 200\n  --max-late-arrival-ms <n>    Late-arrival window in milliseconds. Default: 60000\n  --max-tail-drain <value>     Max extra simulated drain time for delayed events. Default: 5m\n  --late-policy <value>        flag | drop | emit_correction | fail. Default: flag\n  --report-every <value>       Progress log interval in simulated time. Default: 30s\n  --time-scale <n>             1 = realtime, 60 = one simulated minute per wall second\n  --dedupe-preset <value>      standard | heavy-duplicates | high-latency | cross-node-busy. Default: standard\n  --dedupe-config <path>       JSON file with either a preset or explicit sliding/max windows\n  --node-ids <csv>             Comma-separated node IDs for one single-cluster run. Default: edge-a,edge-b,edge-c\n  --dark-nodes <csv>           Nodes that periodically disconnect and reconnect\n  --dark-interval <value>      Time between repeated dark windows. Default: 25m\n  --dark-duration <value>      Length of each dark window. Default: 4m\n  --dark-start-after <value>   Delay before the first dark window. Default: 10m\n  --dark-stagger <value>       Extra offset applied between dark nodes. Default: 3m\n  --jitter-nodes <csv>         Nodes that stay up but receive extra transport jitter\n  --jitter-extra-delay-min <value>  Minimum extra delay added to jitter nodes. Default: 75ms\n  --jitter-extra-delay-max <value>  Maximum extra delay added to jitter nodes. Default: 1200ms\n  --jitter-spike-chance <0..1> Chance of an additional jitter spike on jitter nodes. Default: 0.08\n  --jitter-spike-min <value>   Minimum extra jitter spike delay. Default: 3s\n  --jitter-spike-max <value>   Maximum extra jitter spike delay. Default: 12s\n  --output <path>              Explicit summary JSON path\n  --output-dir <path>          Base directory for run artifacts. Default: artifacts/runs\n  --run-name <value>           Optional label appended to the run folder name\n  --pipeline <specifier>       Package name, subpath, or file path that supplies clock/dedupe/ordering adapters\n  --monitor                    Enable monitor-aware routing and artifact capture when the pipeline supports it\n  --monitor-module <specifier> Package name, subpath, or file path that supplies the monitor runtime. Default: @causal-order/monitor\n  --monitor-db <path>          Optional SQLite path for the monitor reservoir. Default: in-memory\n  --monitor-replay-batch <n>   Replay batch size used by the monitor adapter. Default: 50\n  --monitor-scenario <value>   Optional monitor scenario label recorded into artifacts and summaries\n  --profile <value>            Built-in or local profile name from profiles/. Default: balanced-default\n  --profile-file <path>        Explicit workload profile JSON file\n  --sample-limit <n>           Number of anomaly/correction samples to retain. Default: 20\n  --strict                     Enable strict stream validation\n  --disallow-unknown-order     Force allowUnknownOrder=false\n  --help                       Show this message\n\nExamples:\n  causal-order-testing-runtime --duration 6h --steady-for 90m --time-scale 1\n  causal-order-testing-runtime --duration 20m --time-scale 60 --report-every 2m\n  causal-order-testing-runtime --duration 10h --steady-for 2h --run-name overnight-laptop\n";
export declare function buildConfig(argv: string[]): RuntimeConfig | {
    help: true;
};
export declare function parseDurationToMs(input: string): bigint;
export declare function formatDuration(milliseconds: number | bigint): string;
export declare function resolveConfiguredNodeRateShare(nodeIds: string[], nodeWeights: Record<string, number>, nodeId: string): number;
export declare function createRunLabel(wallStartMs: number, runName: string | null): string;
export declare function buildRunArtifacts(config: RuntimeConfig, wallStartMs: number): RuntimeArtifacts;
export declare function serializeConfig(config: RuntimeConfig): Record<string, unknown>;
export declare function deserializeConfig(serialized: Record<string, any>): RuntimeConfig;
export declare function createSimulationClock(config: RuntimeConfig & {
    wallStartMs: number;
}): {
    simulatedStartMs: bigint;
    simulatedEndMs: bigint;
    simulationNowMs: () => bigint;
};
export declare function formatOperatorError(error: unknown): string;
export declare function sleepForSimulatedGap(gapMs: bigint, timeScale: number): Promise<void>;
export declare function randomInt(min: number, max: number): number;
export declare function randomBetween(min: number, max: number): number;
export declare function sampleIntervalMs(ratePerSecond: number): bigint;
export declare function serializeEventForWire(event: SimulationEvent): Record<string, unknown>;
export declare function deserializeEventFromWire(event: Record<string, any>): SimulationEvent;
export declare function serializeHintForWire(hint: HintEvent): Record<string, unknown>;
export declare function deserializeHintFromWire(hint: Record<string, any>): HintEvent;

import type { RuntimeMonitorConfig } from "./deployment-common.js";
import type { HarnessMonitorAdapter } from "./pipeline-types.js";
type ControlledMonitorComponent = "transport" | "dedupe" | "causal-order";
type ControlledMonitorState = "online" | "offline";
export interface MonitorScenarioSnapshot {
    label: string;
    transport: ControlledMonitorState;
    dedupe: ControlledMonitorState;
    causalOrder: ControlledMonitorState;
}
export interface MonitorOutageController {
    tick(options?: {
        reconcile?: boolean;
    }): Promise<MonitorScenarioSnapshot | null>;
}
export declare function createMonitorOutageController(options: {
    elapsedMs: () => bigint;
    monitorAdapter: HarnessMonitorAdapter | null;
    monitorConfig: RuntimeMonitorConfig;
    durationMs: bigint;
    steadyForMs: bigint;
    now: () => bigint;
    setTransportState?: (state: ControlledMonitorState) => Promise<void>;
    onTransition?: (component: ControlledMonitorComponent, state: ControlledMonitorState, snapshot: MonitorScenarioSnapshot, elapsedMs: bigint) => void;
}): MonitorOutageController | null;
export {};

import { ThrottleController } from "../throttle/ThrottleController.js";
import type { MonitorIngressDecision, MonitorRoutingMode } from "../types/events.js";
import type { ReservoirStats } from "../types/snapshots.js";
export declare class DeliveryRouter {
    #private;
    constructor(throttleController: ThrottleController);
    decideIngress(routingMode: MonitorRoutingMode, reservoir: Pick<ReservoirStats, "totalPendingRows">): MonitorIngressDecision;
}

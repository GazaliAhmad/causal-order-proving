import type { MonitorHealthConfig } from "../types/config.js";
import type { MonitorComponent, MonitorHealthUpdate } from "../types/events.js";
import type { MonitorComponentHealthSnapshot } from "../types/snapshots.js";
export declare class HealthTracker {
    #private;
    constructor(config: MonitorHealthConfig, now: () => bigint);
    getSnapshot(): Record<MonitorComponent, MonitorComponentHealthSnapshot>;
    getComponentSnapshot(component: MonitorComponent): MonitorComponentHealthSnapshot;
    updateComponentHealth(component: MonitorComponent, update: MonitorHealthUpdate): MonitorComponentHealthSnapshot;
    observeHeartbeat(component: MonitorComponent, observedAt?: bigint, details?: Record<string, unknown>): MonitorComponentHealthSnapshot;
    refreshStates(at?: bigint): Record<MonitorComponent, MonitorComponentHealthSnapshot>;
}

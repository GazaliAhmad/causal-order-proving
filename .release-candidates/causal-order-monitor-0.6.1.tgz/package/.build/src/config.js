import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import { createDefaultMonitorNow, createDefaultMonitorConfig, DEFAULT_MONITOR_CONFIG_FILE, } from "./types/config.js";
const DURATION_PATTERN = /^(?<value>\d+)(?<unit>ms|s|m|h)$/;
export const MONITOR_CONFIG_ENV_VAR = "CAUSAL_ORDER_MONITOR_CONFIG";
const MONITOR_THROTTLE_TIERS = [
    "open",
    "slow",
    "very_slow",
    "paused",
];
function formatPath(pathSegments) {
    return pathSegments.join(".");
}
function assertObject(value, pathSegments) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
        throw new Error(`${formatPath(pathSegments)} must be an object.`);
    }
    return value;
}
function assertAllowedKeys(value, allowedKeys, pathSegments) {
    for (const key of Object.keys(value)) {
        if (!allowedKeys.includes(key)) {
            throw new Error(`${formatPath([...pathSegments, key])} is not a supported monitor config key.`);
        }
    }
}
function parseDurationMs(value, pathSegments) {
    if (typeof value === "number") {
        if (!Number.isInteger(value) || value < 0) {
            throw new Error(`${formatPath(pathSegments)} must be a non-negative integer duration in milliseconds.`);
        }
        return BigInt(value);
    }
    const normalized = value.trim();
    const match = DURATION_PATTERN.exec(normalized);
    if (!match?.groups) {
        throw new Error(`${formatPath(pathSegments)} must be an integer millisecond value or duration string like 15000ms, 30s, 5m, or 4h.`);
    }
    const durationValue = BigInt(match.groups.value);
    switch (match.groups.unit) {
        case "ms":
            return durationValue;
        case "s":
            return durationValue * 1000n;
        case "m":
            return durationValue * 60000n;
        case "h":
            return durationValue * 3600000n;
        default:
            throw new Error(`${formatPath(pathSegments)} uses an unsupported duration unit.`);
    }
}
function parseOptionalString(value, pathSegments) {
    if (value === undefined) {
        return undefined;
    }
    if (typeof value !== "string") {
        throw new Error(`${formatPath(pathSegments)} must be a string.`);
    }
    return value;
}
function parseOptionalBoolean(value, pathSegments) {
    if (value === undefined) {
        return undefined;
    }
    if (typeof value !== "boolean") {
        throw new Error(`${formatPath(pathSegments)} must be a boolean.`);
    }
    return value;
}
function parseOptionalNonNegativeInteger(value, pathSegments) {
    if (value === undefined) {
        return undefined;
    }
    if (!Number.isInteger(value) || value < 0) {
        throw new Error(`${formatPath(pathSegments)} must be a non-negative integer.`);
    }
    return value;
}
function parseOptionalPositiveInteger(value, pathSegments) {
    if (value === undefined) {
        return undefined;
    }
    if (!Number.isInteger(value) || value <= 0) {
        throw new Error(`${formatPath(pathSegments)} must be a positive integer.`);
    }
    return value;
}
function parseOptionalDuration(value, pathSegments) {
    if (value === undefined) {
        return undefined;
    }
    if (typeof value !== "number" && typeof value !== "string") {
        throw new Error(`${formatPath(pathSegments)} must be a duration string or integer milliseconds.`);
    }
    return parseDurationMs(value, pathSegments);
}
function parseOptionalByteLimit(value, pathSegments) {
    if (value === undefined)
        return undefined;
    if (value === null)
        return null;
    if (typeof value === "number") {
        if (!Number.isSafeInteger(value) || value < 0) {
            throw new Error(`${formatPath(pathSegments)} must be null, a non-negative safe integer, or an unsigned decimal integer string.`);
        }
        return BigInt(value);
    }
    if (typeof value === "string" && /^\d+$/.test(value)) {
        return BigInt(value);
    }
    throw new Error(`${formatPath(pathSegments)} must be null, a non-negative safe integer, or an unsigned decimal integer string.`);
}
function parseCapacityConfig(value) {
    if (value === undefined)
        return {};
    const objectValue = assertObject(value, ["reservoir", "capacity"]);
    assertAllowedKeys(objectValue, [
        "maxSerializedEventBytes",
        "maxPendingRows",
        "maxPendingSerializedBytes",
        "filesystemReserve",
        "overflowPolicy",
    ], ["reservoir", "capacity"]);
    const maxPendingRows = objectValue.maxPendingRows;
    if (maxPendingRows !== undefined &&
        maxPendingRows !== null &&
        (!Number.isSafeInteger(maxPendingRows) || maxPendingRows < 0)) {
        throw new Error("reservoir.capacity.maxPendingRows must be null or a non-negative safe integer.");
    }
    if (objectValue.overflowPolicy !== undefined &&
        objectValue.overflowPolicy !== "reject_new") {
        throw new Error("reservoir.capacity.overflowPolicy must be 'reject_new'.");
    }
    const maxSerializedEventBytes = parseOptionalByteLimit(objectValue.maxSerializedEventBytes, ["reservoir", "capacity", "maxSerializedEventBytes"]);
    const maxPendingSerializedBytes = parseOptionalByteLimit(objectValue.maxPendingSerializedBytes, ["reservoir", "capacity", "maxPendingSerializedBytes"]);
    const filesystemReserve = parseFilesystemReserveConfig(objectValue.filesystemReserve);
    return {
        ...(maxSerializedEventBytes !== undefined ? { maxSerializedEventBytes } : {}),
        ...(maxPendingRows !== undefined
            ? { maxPendingRows: maxPendingRows }
            : {}),
        ...(maxPendingSerializedBytes !== undefined
            ? { maxPendingSerializedBytes }
            : {}),
        ...(filesystemReserve !== undefined ? { filesystemReserve } : {}),
        ...(objectValue.overflowPolicy !== undefined
            ? { overflowPolicy: "reject_new" }
            : {}),
    };
}
function parseFilesystemReserveConfig(value) {
    if (value === undefined)
        return undefined;
    if (value === null)
        return null;
    const objectValue = assertObject(value, ["reservoir", "capacity", "filesystemReserve"]);
    assertAllowedKeys(objectValue, ["minimumAvailableBytes", "resumeAvailableBytes", "unavailableEvidence"], ["reservoir", "capacity", "filesystemReserve"]);
    const minimumAvailableBytes = parseOptionalByteLimit(objectValue.minimumAvailableBytes, ["reservoir", "capacity", "filesystemReserve", "minimumAvailableBytes"]);
    const resumeAvailableBytes = parseOptionalByteLimit(objectValue.resumeAvailableBytes, ["reservoir", "capacity", "filesystemReserve", "resumeAvailableBytes"]);
    if (minimumAvailableBytes === undefined || minimumAvailableBytes === null) {
        throw new Error("reservoir.capacity.filesystemReserve.minimumAvailableBytes is required and must be a non-negative integer.");
    }
    if (resumeAvailableBytes === undefined || resumeAvailableBytes === null) {
        throw new Error("reservoir.capacity.filesystemReserve.resumeAvailableBytes is required and must be a non-negative integer.");
    }
    if (resumeAvailableBytes <= minimumAvailableBytes) {
        throw new Error("reservoir.capacity.filesystemReserve.resumeAvailableBytes must be greater than minimumAvailableBytes.");
    }
    const unavailableEvidence = objectValue.unavailableEvidence;
    if (unavailableEvidence !== "allow_logical_admission" &&
        unavailableEvidence !== "refuse_admission") {
        throw new Error("reservoir.capacity.filesystemReserve.unavailableEvidence must be 'allow_logical_admission' or 'refuse_admission'.");
    }
    return {
        minimumAvailableBytes,
        resumeAvailableBytes,
        unavailableEvidence,
    };
}
function parseReservoirConfig(value) {
    if (value === undefined) {
        return {};
    }
    const objectValue = assertObject(value, ["reservoir"]);
    assertAllowedKeys(objectValue, [
        "databasePath",
        "rollingBufferWindowMs",
        "fullOutageMaxWindowMs",
        "pruneIntervalMs",
        "pruneBatchSize",
        "deliveredRetentionMs",
        "deadLetterRetentionMs",
        "walAutoCheckpointPages",
        "capacity",
    ], ["reservoir"]);
    return {
        databasePath: parseOptionalString(objectValue.databasePath, ["reservoir", "databasePath"]),
        rollingBufferWindowMs: parseOptionalDuration(objectValue.rollingBufferWindowMs, ["reservoir", "rollingBufferWindowMs"]),
        fullOutageMaxWindowMs: parseOptionalDuration(objectValue.fullOutageMaxWindowMs, ["reservoir", "fullOutageMaxWindowMs"]),
        pruneIntervalMs: parseOptionalDuration(objectValue.pruneIntervalMs, ["reservoir", "pruneIntervalMs"]),
        pruneBatchSize: parseOptionalPositiveInteger(objectValue.pruneBatchSize, ["reservoir", "pruneBatchSize"]),
        deliveredRetentionMs: parseOptionalDuration(objectValue.deliveredRetentionMs, ["reservoir", "deliveredRetentionMs"]),
        deadLetterRetentionMs: parseOptionalDuration(objectValue.deadLetterRetentionMs, ["reservoir", "deadLetterRetentionMs"]),
        walAutoCheckpointPages: parseOptionalNonNegativeInteger(objectValue.walAutoCheckpointPages, ["reservoir", "walAutoCheckpointPages"]),
        capacity: parseCapacityConfig(objectValue.capacity),
    };
}
function parseTransportConfig(value) {
    if (value === undefined) {
        return {};
    }
    const objectValue = assertObject(value, ["transport"]);
    assertAllowedKeys(objectValue, ["heartbeatGraceMs", "reconnectBurstWindowMs", "sourceLabel"], ["transport"]);
    return {
        heartbeatGraceMs: parseOptionalDuration(objectValue.heartbeatGraceMs, ["transport", "heartbeatGraceMs"]),
        reconnectBurstWindowMs: parseOptionalDuration(objectValue.reconnectBurstWindowMs, ["transport", "reconnectBurstWindowMs"]),
        sourceLabel: parseOptionalString(objectValue.sourceLabel, ["transport", "sourceLabel"]),
    };
}
function parseComponentHealthConfig(value, componentName) {
    if (value === undefined) {
        return {};
    }
    const objectValue = assertObject(value, ["health", componentName]);
    assertAllowedKeys(objectValue, ["degradedAfterMs", "offlineAfterMs"], ["health", componentName]);
    return {
        degradedAfterMs: parseOptionalDuration(objectValue.degradedAfterMs, ["health", componentName, "degradedAfterMs"]),
        offlineAfterMs: parseOptionalDuration(objectValue.offlineAfterMs, ["health", componentName, "offlineAfterMs"]),
    };
}
function parseHealthConfig(value) {
    if (value === undefined) {
        return {};
    }
    const objectValue = assertObject(value, ["health"]);
    assertAllowedKeys(objectValue, ["transport", "dedupe", "causalOrder"], ["health"]);
    return {
        transport: parseComponentHealthConfig(objectValue.transport, "transport"),
        dedupe: parseComponentHealthConfig(objectValue.dedupe, "dedupe"),
        causalOrder: parseComponentHealthConfig(objectValue.causalOrder, "causalOrder"),
    };
}
function parseThrottleTierConfig(value, tierName) {
    if (value === undefined) {
        return {};
    }
    const objectValue = assertObject(value, ["throttle", tierName]);
    assertAllowedKeys(objectValue, ["maxEventsPerSecond", "batchSize"], ["throttle", tierName]);
    return {
        maxEventsPerSecond: parseOptionalNonNegativeInteger(objectValue.maxEventsPerSecond, ["throttle", tierName, "maxEventsPerSecond"]),
        batchSize: parseOptionalNonNegativeInteger(objectValue.batchSize, ["throttle", tierName, "batchSize"]),
    };
}
function parseThrottleDefaultTier(value) {
    if (value === undefined) {
        return undefined;
    }
    if (typeof value !== "string" ||
        !MONITOR_THROTTLE_TIERS.includes(value)) {
        throw new Error("throttle.defaultTier must be one of open, slow, very_slow, or paused.");
    }
    return value;
}
function parseThrottleConfig(value) {
    if (value === undefined) {
        return {};
    }
    const objectValue = assertObject(value, ["throttle"]);
    assertAllowedKeys(objectValue, ["open", "slow", "verySlow", "paused", "defaultTier"], ["throttle"]);
    return {
        open: parseThrottleTierConfig(objectValue.open, "open"),
        slow: parseThrottleTierConfig(objectValue.slow, "slow"),
        verySlow: parseThrottleTierConfig(objectValue.verySlow, "very_slow"),
        paused: parseThrottleTierConfig(objectValue.paused, "paused"),
        defaultTier: parseThrottleDefaultTier(objectValue.defaultTier),
    };
}
function parseReplayConfig(value) {
    if (value === undefined) {
        return {};
    }
    const objectValue = assertObject(value, ["replay"]);
    assertAllowedKeys(objectValue, ["healthConfirmationHeartbeats", "pauseLiveFlowDuringReplay", "retryBackoffMs"], ["replay"]);
    return {
        healthConfirmationHeartbeats: parseOptionalNonNegativeInteger(objectValue.healthConfirmationHeartbeats, ["replay", "healthConfirmationHeartbeats"]),
        pauseLiveFlowDuringReplay: parseOptionalBoolean(objectValue.pauseLiveFlowDuringReplay, ["replay", "pauseLiveFlowDuringReplay"]),
        retryBackoffMs: parseOptionalDuration(objectValue.retryBackoffMs, ["replay", "retryBackoffMs"]),
    };
}
function parseStartupConfig(value) {
    if (value === undefined)
        return {};
    const objectValue = assertObject(value, ["startup"]);
    assertAllowedKeys(objectValue, ["healthPolicy"], ["startup"]);
    const healthPolicy = objectValue.healthPolicy;
    if (healthPolicy !== undefined &&
        healthPolicy !== "optimistic" &&
        healthPolicy !== "conservative") {
        throw new Error("startup.healthPolicy must be 'optimistic' or 'conservative'.");
    }
    return {
        healthPolicy: healthPolicy,
    };
}
function parseLifecycleConfig(value) {
    if (value === undefined)
        return {};
    const objectValue = assertObject(value, ["lifecycle"]);
    assertAllowedKeys(objectValue, ["queueCapacity", "overflowPolicy", "shutdownFlushTimeoutMs"], ["lifecycle"]);
    const queueCapacity = parseOptionalPositiveInteger(objectValue.queueCapacity, ["lifecycle", "queueCapacity"]);
    if (queueCapacity !== undefined && !Number.isSafeInteger(queueCapacity)) {
        throw new Error("lifecycle.queueCapacity must be a positive safe integer.");
    }
    if (objectValue.overflowPolicy !== undefined &&
        objectValue.overflowPolicy !== "drop_oldest") {
        throw new Error("lifecycle.overflowPolicy must be 'drop_oldest'.");
    }
    const shutdownFlushTimeoutMs = parseOptionalDuration(objectValue.shutdownFlushTimeoutMs, ["lifecycle", "shutdownFlushTimeoutMs"]);
    return {
        ...(queueCapacity !== undefined ? { queueCapacity } : {}),
        ...(objectValue.overflowPolicy !== undefined
            ? { overflowPolicy: "drop_oldest" }
            : {}),
        ...(shutdownFlushTimeoutMs !== undefined ? { shutdownFlushTimeoutMs } : {}),
    };
}
export function parseMonitorConfigJson(jsonText) {
    let parsedValue;
    try {
        parsedValue = JSON.parse(jsonText);
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        throw new Error(`Monitor config JSON is invalid: ${message}`);
    }
    const objectValue = assertObject(parsedValue, ["monitorConfig"]);
    assertAllowedKeys(objectValue, ["reservoir", "transport", "health", "throttle", "replay", "startup", "lifecycle"], ["monitorConfig"]);
    return objectValue;
}
function resolvePartialMonitorConfig(config = {}) {
    const reservoir = parseReservoirConfig(config.reservoir);
    const transport = parseTransportConfig(config.transport);
    const health = parseHealthConfig(config.health);
    const throttle = parseThrottleConfig(config.throttle);
    const replay = parseReplayConfig(config.replay);
    const startup = parseStartupConfig(config.startup);
    const lifecycle = parseLifecycleConfig(config.lifecycle);
    return {
        reservoir: {
            ...reservoir,
        },
        transport: {
            ...transport,
        },
        health: {
            transport: health.transport,
            dedupe: health.dedupe,
            causalOrder: health.causalOrder,
        },
        throttle: {
            open: {
                ...throttle.open,
            },
            slow: {
                ...throttle.slow,
            },
            verySlow: {
                ...throttle.verySlow,
            },
            paused: {
                ...throttle.paused,
            },
            defaultTier: throttle.defaultTier,
        },
        replay: {
            ...replay,
        },
        startup: {
            ...startup,
        },
        lifecycle: {
            ...lifecycle,
        },
    };
}
function mergeMonitorConfig(base, override) {
    return {
        ...base,
        ...override,
        reservoir: {
            ...base.reservoir,
            ...override.reservoir,
            capacity: {
                ...base.reservoir.capacity,
                ...override.reservoir?.capacity,
            },
        },
        transport: {
            ...base.transport,
            ...override.transport,
        },
        health: {
            transport: {
                ...base.health.transport,
                ...override.health?.transport,
            },
            dedupe: {
                ...base.health.dedupe,
                ...override.health?.dedupe,
            },
            causalOrder: {
                ...base.health.causalOrder,
                ...override.health?.causalOrder,
            },
        },
        throttle: {
            ...base.throttle,
            ...override.throttle,
            open: {
                ...base.throttle.open,
                ...override.throttle?.open,
            },
            slow: {
                ...base.throttle.slow,
                ...override.throttle?.slow,
            },
            verySlow: {
                ...base.throttle.verySlow,
                ...override.throttle?.verySlow,
            },
            paused: {
                ...base.throttle.paused,
                ...override.throttle?.paused,
            },
        },
        replay: {
            ...base.replay,
            ...override.replay,
        },
        startup: {
            ...base.startup,
            ...override.startup,
        },
        lifecycle: {
            ...base.lifecycle,
            ...override.lifecycle,
        },
    };
}
function resolveConfigPath(configPath, cwd = process.cwd()) {
    return resolve(cwd, configPath);
}
function loadPartialMonitorConfigFileAtPath(resolvedPath) {
    const jsonText = readFileSync(resolvedPath, "utf8");
    const parsedConfig = parseMonitorConfigJson(jsonText);
    return resolvePartialMonitorConfig(parsedConfig);
}
export function resolveMonitorConfig(config = {}) {
    return mergeMonitorConfig(createDefaultMonitorConfig(), resolvePartialMonitorConfig(config));
}
export function loadMonitorConfigFile(configPath = DEFAULT_MONITOR_CONFIG_FILE) {
    const resolvedPath = resolveConfigPath(configPath);
    return mergeMonitorConfig(createDefaultMonitorConfig(), loadPartialMonitorConfigFileAtPath(resolvedPath));
}
export function resolveMonitorConfigFromEnvironment(inlineConfig = {}, options = {}) {
    const env = options.env ?? process.env;
    const cwd = options.cwd ?? process.cwd();
    const defaultConfigFile = options.defaultConfigFile ?? DEFAULT_MONITOR_CONFIG_FILE;
    const configuredPath = env[MONITOR_CONFIG_ENV_VAR];
    let fileConfig = {};
    if (typeof configuredPath === "string" && configuredPath.trim().length > 0) {
        const resolvedPath = resolveConfigPath(configuredPath, cwd);
        try {
            fileConfig = loadPartialMonitorConfigFileAtPath(resolvedPath);
        }
        catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            throw new Error(`Failed to load monitor config from ${MONITOR_CONFIG_ENV_VAR} at "${resolvedPath}": ${message}`);
        }
    }
    else {
        const defaultResolvedPath = resolveConfigPath(defaultConfigFile, cwd);
        if (existsSync(defaultResolvedPath)) {
            fileConfig = loadPartialMonitorConfigFileAtPath(defaultResolvedPath);
        }
    }
    return mergeMonitorConfig(mergeMonitorConfig(createDefaultMonitorConfig(), fileConfig), inlineConfig);
}
export function loadMonitorConfigFromEnvironment(options = {}) {
    return resolveMonitorConfigFromEnvironment({}, options);
}
export { createDefaultMonitorNow, createDefaultMonitorConfig, DEFAULT_MONITOR_CONFIG_FILE, };

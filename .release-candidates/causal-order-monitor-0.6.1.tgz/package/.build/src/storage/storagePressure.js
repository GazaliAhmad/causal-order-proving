export function projectFilesystemStorage(availableBytes, totalBytes) {
    if (totalBytes <= 0n ||
        availableBytes < 0n ||
        availableBytes > totalBytes) {
        return { pressure: "unknown", usedPercent: null };
    }
    const usedPercent = Number(((totalBytes - availableBytes) * 10000n) / totalBytes) / 100;
    const pressure = availableBytes * 100n <= totalBytes * 5n
        ? "critical"
        : availableBytes * 100n <= totalBytes * 15n
            ? "elevated"
            : "normal";
    return { pressure, usedPercent };
}

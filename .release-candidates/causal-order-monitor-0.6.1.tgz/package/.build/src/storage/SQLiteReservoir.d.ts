import type { MonitorReservoirConfig } from "../types/config.js";
import type { MonitorDeliveryMode, MonitorIngressEvent, MonitorSourcePath } from "../types/events.js";
import type { MonitorCapacityFacet, MonitorCapacitySnapshotV1, MonitorComponentHealthSnapshot, MonitorStorageSnapshotV1, ReplaySessionSnapshot, ReservoirStats } from "../types/snapshots.js";
import { type MonitorSchemaInfo } from "./schema.js";
interface ReservoirIngressOptions {
    sourcePath: MonitorSourcePath;
    deliveryMode: MonitorDeliveryMode;
    sourceStreamId?: string | null;
    replayState?: ReservoirReplayState;
    retryNotBeforeMs?: bigint | null;
    monitorIngestAt?: bigint;
    fullOutageActive?: boolean;
}
type ReservoirReplayState = "pending" | "replaying" | "delivered" | "dead_letter";
export interface ReservoirReplayEntry {
    rowId: number;
    event: MonitorIngressEvent;
    sourcePath: MonitorSourcePath;
    sourceStreamId: string | null;
    deliveryMode: MonitorDeliveryMode;
    replayAttempts: number;
}
export interface PruneResult {
    markedDeadLetter: number;
    deletedRows: number;
}
export type WalCheckpointMode = "passive" | "restart" | "truncate";
export interface WalCheckpointResult {
    mode: WalCheckpointMode;
    busy: boolean;
    logFrames: number;
    checkpointedFrames: number;
}
export interface ReservoirLifecycleStats {
    deliveredRows: number;
    deadLetterRows: number;
}
export interface ReservoirRestartState {
    totalPendingRows: number;
    retryWaitingRows: number;
    earliestRetryAt: bigint | null;
    maximumReplayAttempts: number;
    reclaimedInterruptedRows: number;
}
export type MonitorStorageEvidenceReader = () => MonitorStorageSnapshotV1;
export interface MonitorReservoirLifecycleHooks {
    onIngressRowsDelivered?(rowIds: ReadonlyArray<number>): void;
    onReplayRowsDelivered?(rowIds: ReadonlyArray<number>): void;
    onRetentionDeadLettered?(count: number): void;
    onRetentionDeleted?(count: number): void;
    onCapacitySnapshot?(snapshot: MonitorCapacitySnapshotV1): void;
}
export declare class SQLiteReservoir {
    #private;
    readonly capacity: MonitorCapacityFacet;
    constructor(config: MonitorReservoirConfig, now: () => bigint, storageEvidenceReader?: MonitorStorageEvidenceReader | null, lifecycleHooks?: MonitorReservoirLifecycleHooks);
    getSchemaInfo(): Readonly<MonitorSchemaInfo>;
    appendIngressEvent(event: MonitorIngressEvent, options: ReservoirIngressOptions): number;
    recordHealthTransition(snapshot: MonitorComponentHealthSnapshot): number;
    recordReplaySnapshot(snapshot: ReplaySessionSnapshot): number;
    bumpReplayAttempts(limitToStates?: ReadonlyArray<ReservoirReplayState>): number;
    updateReplayState(fromStates: ReadonlyArray<ReservoirReplayState>, nextState: ReservoirReplayState): number;
    claimReplayBatch(limit: number, deliveryMode?: MonitorDeliveryMode): ReservoirReplayEntry[];
    markReplayBatchDelivered(rowIds: ReadonlyArray<number>): number;
    markIngressRowsDelivered(rowIds: ReadonlyArray<number>): number;
    resetReplayBatchToPending(rowIds: ReadonlyArray<number>, retryNotBeforeMs?: bigint | null): number;
    deadLetterReplayBatch(rowIds: ReadonlyArray<number>): number;
    reclaimStaleReplayRows(maxClaimAgeMs: bigint): number;
    recoverRestartState(): ReservoirRestartState;
    pruneExpired(fullOutageActive?: boolean): PruneResult;
    checkpointWal(mode?: WalCheckpointMode): WalCheckpointResult;
    getLifecycleStats(): ReservoirLifecycleStats;
    getStats(): ReservoirStats;
    getPendingRowCount(): number;
    getDatabasePath(): string;
    getStorageSnapshot(): MonitorStorageSnapshotV1;
    close(): void;
}
export {};

import { existsSync, mkdirSync, statfsSync, statSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { DatabaseSync } from "node:sqlite";
import { MonitorCapacityRefusedError, MonitorClosedError, toMonitorBoundaryError, } from "../boundary.js";
import { applyMonitorSchema, MonitorCapacityAccountingError, MonitorSchemaError, } from "./schema.js";
import { projectFilesystemStorage } from "./storagePressure.js";
const BIGINT_SENTINEL = "__monitorBigInt";
const ESCAPED_JSON_SENTINEL = "__causalOrderMonitorInternalEscapedJsonV1__";
const DISABLED_CAPACITY_CONFIG = {
    maxSerializedEventBytes: null,
    maxPendingRows: null,
    maxPendingSerializedBytes: null,
    filesystemReserve: null,
    overflowPolicy: "reject_new",
};
function resolveCapacityConfig(config) {
    const resolved = { ...DISABLED_CAPACITY_CONFIG, ...config };
    for (const [field, value] of [
        ["maxSerializedEventBytes", resolved.maxSerializedEventBytes],
        ["maxPendingSerializedBytes", resolved.maxPendingSerializedBytes],
    ]) {
        if (value !== null && (typeof value !== "bigint" || value < 0n)) {
            throw new TypeError(`reservoir.capacity.${field} must be null or a non-negative bigint.`);
        }
    }
    if (resolved.maxPendingRows !== null &&
        (!Number.isSafeInteger(resolved.maxPendingRows) || resolved.maxPendingRows < 0)) {
        throw new TypeError("reservoir.capacity.maxPendingRows must be null or a non-negative safe integer.");
    }
    if (resolved.filesystemReserve !== null) {
        validateFilesystemReserveConfig(resolved.filesystemReserve);
    }
    if (resolved.overflowPolicy !== "reject_new") {
        throw new TypeError("reservoir.capacity.overflowPolicy must be 'reject_new'.");
    }
    return resolved;
}
function validateFilesystemReserveConfig(config) {
    if (typeof config.minimumAvailableBytes !== "bigint" ||
        config.minimumAvailableBytes < 0n) {
        throw new TypeError("reservoir.capacity.filesystemReserve.minimumAvailableBytes must be a non-negative bigint.");
    }
    if (typeof config.resumeAvailableBytes !== "bigint" ||
        config.resumeAvailableBytes <= config.minimumAvailableBytes) {
        throw new TypeError("reservoir.capacity.filesystemReserve.resumeAvailableBytes must be a bigint greater than minimumAvailableBytes.");
    }
    if (config.unavailableEvidence !== "allow_logical_admission" &&
        config.unavailableEvidence !== "refuse_admission") {
        throw new TypeError("reservoir.capacity.filesystemReserve.unavailableEvidence must be 'allow_logical_admission' or 'refuse_admission'.");
    }
}
const INSERT_INGRESS_EVENT_SQL = `INSERT INTO ingress_events (
  id,
  monitor_ingest_at_ms,
  source_node_id,
  source_stream_id,
  source_path,
  event_id,
  trace_id,
  sequence,
  logical_time_ms,
  payload_json,
  serialized_event_bytes,
  payload_encoding,
  delivery_mode,
  replay_state,
  replay_attempts,
  retry_not_before_ms,
  replay_claimed_at_ms,
  terminal_at_ms,
  expires_at_ms
) VALUES (
  @id,
  @monitor_ingest_at_ms,
  @source_node_id,
  @source_stream_id,
  @source_path,
  @event_id,
  @trace_id,
  @sequence,
  @logical_time_ms,
  @payload_json,
  @serialized_event_bytes,
  @payload_encoding,
  @delivery_mode,
  @replay_state,
  @replay_attempts,
  @retry_not_before_ms,
  @replay_claimed_at_ms,
  @terminal_at_ms,
  @expires_at_ms
)`;
function normalizeDatabasePath(databasePath) {
    return databasePath === ":memory:" ? databasePath : resolve(databasePath);
}
function toReservoirStartupError(databasePath, error) {
    const reason = error instanceof Error ? error.message : String(error);
    const resolvedPath = normalizeDatabasePath(databasePath);
    return new Error(`Failed to initialize monitor SQLite reservoir at "${resolvedPath}". ` +
        `Ensure the path is on a writable local filesystem for this host process. ` +
        `Recommended examples are "./.causal-order-monitor/monitor.sqlite" during development ` +
        `or a server-local path such as "/var/lib/causal-order-monitor/monitor.sqlite" in production. ` +
        `Avoid read-only mounts, synced workspace folders, and unvalidated network filesystems. ` +
        `SQLite startup error: ${reason}`);
}
function toSqlBigInt(value) {
    return value;
}
function parseCount(value) {
    if (typeof value === "number") {
        return value;
    }
    if (typeof value === "bigint") {
        return Number(value);
    }
    if (typeof value === "string") {
        return Number(value);
    }
    return 0;
}
function parseBigInt(value) {
    if (typeof value === "bigint") {
        return value;
    }
    if (typeof value === "number") {
        return BigInt(value);
    }
    if (typeof value === "string" && value.length > 0) {
        return BigInt(value);
    }
    return 0n;
}
function parseOptionalUnsignedDecimal(value) {
    if (value === null || !/^\d+$/.test(value))
        return null;
    return BigInt(value);
}
function unknownStorageSnapshot() {
    return {
        pressure: "unknown",
        databaseBytes: null,
        walBytes: null,
        filesystemAvailableBytes: null,
        filesystemTotalBytes: null,
        filesystemUsedPercent: null,
    };
}
function incrementSafeCounter(value) {
    return value >= Number.MAX_SAFE_INTEGER ? Number.MAX_SAFE_INTEGER : value + 1;
}
function utilizationPercent(usage, limit) {
    if (limit === null)
        return null;
    if (limit === 0n)
        return 100;
    return Math.round((Number(usage) / Number(limit)) * 10_000) / 100;
}
function isPendingReplayState(state) {
    return state === "pending" || state === "replaying";
}
function serializeJson(value) {
    const generatedWrappers = new WeakSet();
    return JSON.stringify(value, (_key, currentValue) => {
        if (typeof currentValue === "bigint") {
            const wrapper = {
                [BIGINT_SENTINEL]: currentValue.toString(),
            };
            generatedWrappers.add(wrapper);
            return wrapper;
        }
        if (currentValue &&
            typeof currentValue === "object" &&
            !Array.isArray(currentValue) &&
            !generatedWrappers.has(currentValue) &&
            (Object.prototype.hasOwnProperty.call(currentValue, BIGINT_SENTINEL) ||
                Object.prototype.hasOwnProperty.call(currentValue, ESCAPED_JSON_SENTINEL))) {
            const wrapper = {
                [ESCAPED_JSON_SENTINEL]: Object.entries(currentValue),
            };
            generatedWrappers.add(wrapper);
            return wrapper;
        }
        return currentValue;
    });
}
function deserializeJson(value) {
    return JSON.parse(value, (_key, currentValue) => {
        if (currentValue &&
            typeof currentValue === "object" &&
            Object.prototype.hasOwnProperty.call(currentValue, ESCAPED_JSON_SENTINEL) &&
            Object.keys(currentValue).length === 1 &&
            Array.isArray(currentValue[ESCAPED_JSON_SENTINEL])) {
            return Object.fromEntries(currentValue[ESCAPED_JSON_SENTINEL]);
        }
        if (currentValue &&
            typeof currentValue === "object" &&
            BIGINT_SENTINEL in currentValue &&
            typeof currentValue[BIGINT_SENTINEL] === "string") {
            return BigInt(currentValue[BIGINT_SENTINEL]);
        }
        return currentValue;
    });
}
export class SQLiteReservoir {
    capacity;
    #config;
    #now;
    #db;
    #schemaInfo;
    #appendIngressStatement;
    #storageEvidenceReader;
    #lifecycleHooks;
    #pendingRowCount;
    #filesystemReserveLatched = false;
    #lastKnownFilesystemAvailableBytes = null;
    #lastCapacityRefusal = null;
    #capacityRefusedTotal = 0;
    #storageAppendFailureTotal = 0;
    #closed = false;
    constructor(config, now, storageEvidenceReader = null, lifecycleHooks = {}) {
        this.#config = {
            ...config,
            capacity: resolveCapacityConfig(config.capacity),
        };
        this.#now = now;
        this.#storageEvidenceReader = storageEvidenceReader;
        this.#lifecycleHooks = lifecycleHooks;
        this.capacity = Object.freeze({
            getSnapshot: () => this.#getCapacitySnapshot(),
        });
        let db;
        try {
            if (config.databasePath !== ":memory:") {
                mkdirSync(dirname(normalizeDatabasePath(config.databasePath)), {
                    recursive: true,
                });
            }
            db = new DatabaseSync(config.databasePath);
            this.#db = db;
            this.#schemaInfo = applyMonitorSchema(db, config.databasePath);
            db.exec("PRAGMA journal_mode = WAL");
            db.exec("PRAGMA synchronous = FULL");
            db.exec(`PRAGMA wal_autocheckpoint = ${config.walAutoCheckpointPages ?? 1_000}`);
            this.#appendIngressStatement = db.prepare(INSERT_INGRESS_EVENT_SQL);
            this.#pendingRowCount = this.#readPendingRowCount();
        }
        catch (error) {
            try {
                db?.close();
            }
            catch {
                // Preserve the startup failure that prevented reservoir initialization.
            }
            if (error instanceof MonitorSchemaError ||
                error instanceof MonitorCapacityAccountingError) {
                throw error;
            }
            throw toReservoirStartupError(config.databasePath, error);
        }
    }
    getSchemaInfo() {
        return { ...this.#schemaInfo };
    }
    appendIngressEvent(event, options) {
        this.#assertOpen("append an ingress event");
        const monitorIngestAt = options.monitorIngestAt ?? event.ingestedAt ?? this.#now();
        const retentionWindowMs = options.fullOutageActive
            ? this.#config.fullOutageMaxWindowMs
            : this.#config.rollingBufferWindowMs;
        const expiresAt = monitorIngestAt + retentionWindowMs;
        const replayState = options.replayState ??
            (options.sourcePath === "deduped_observation" ? "delivered" : "pending");
        const payloadJson = serializeJson(event);
        const serializedEventBytes = BigInt(Buffer.byteLength(payloadJson, "utf8"));
        const maximumEventBytes = this.#config.capacity.maxSerializedEventBytes;
        if (maximumEventBytes !== null &&
            serializedEventBytes > maximumEventBytes) {
            this.#refuseCapacity({
                limitingDimension: "serialized_event_bytes",
                reasonCode: "MONITOR_CAPACITY_SERIALIZED_EVENT_BYTES",
                limit: maximumEventBytes,
                current: 0n,
                attempted: serializedEventBytes,
            });
        }
        this.#assertFilesystemReserveAdmission();
        let result;
        try {
            result = this.#withTransaction(() => {
                this.#assertPendingCapacityAdmission(replayState, serializedEventBytes);
                const appendResult = this.#appendIngressStatement.run({
                    id: event.id,
                    monitor_ingest_at_ms: toSqlBigInt(monitorIngestAt),
                    source_node_id: event.nodeId,
                    source_stream_id: options.sourceStreamId ?? null,
                    source_path: options.sourcePath,
                    event_id: event.id,
                    trace_id: event.traceId ?? event.payload.traceId ?? null,
                    sequence: event.sequence?.toString() ?? null,
                    logical_time_ms: toSqlBigInt(event.clock.physicalTimeMs),
                    payload_json: payloadJson,
                    serialized_event_bytes: toSqlBigInt(serializedEventBytes),
                    payload_encoding: "json",
                    delivery_mode: options.deliveryMode,
                    replay_state: replayState,
                    replay_attempts: 0,
                    retry_not_before_ms: options.retryNotBeforeMs === null || options.retryNotBeforeMs === undefined
                        ? null
                        : toSqlBigInt(options.retryNotBeforeMs),
                    replay_claimed_at_ms: null,
                    terminal_at_ms: replayState === "delivered" || replayState === "dead_letter"
                        ? toSqlBigInt(monitorIngestAt)
                        : null,
                    expires_at_ms: toSqlBigInt(expiresAt),
                });
                if (isPendingReplayState(replayState)) {
                    this.#adjustCapacityAccounting(1, serializedEventBytes);
                }
                return appendResult;
            });
        }
        catch (error) {
            if (!(error instanceof MonitorCapacityRefusedError)) {
                this.#storageAppendFailureTotal = incrementSafeCounter(this.#storageAppendFailureTotal);
            }
            throw toMonitorBoundaryError(error, "append an ingress event");
        }
        return Number(result.lastInsertRowid);
    }
    recordHealthTransition(snapshot) {
        const result = this.#prepare(`INSERT INTO component_health_log (
          recorded_at_ms,
          component,
          health_state,
          reason_code,
          details_json
        ) VALUES (
          @recorded_at_ms,
          @component,
          @health_state,
          @reason_code,
          @details_json
        )`).run({
            recorded_at_ms: toSqlBigInt(snapshot.observedAt),
            component: snapshot.component,
            health_state: snapshot.state,
            reason_code: snapshot.reasonCode,
            details_json: serializeJson(snapshot.details),
        });
        return Number(result.lastInsertRowid);
    }
    recordReplaySnapshot(snapshot) {
        const result = this.#prepare(`INSERT INTO replay_sessions (
          started_at_ms,
          ended_at_ms,
          target_path,
          session_state,
          event_count_attempted,
          event_count_delivered,
          error_count,
          details_json
        ) VALUES (
          @started_at_ms,
          @ended_at_ms,
          @target_path,
          @session_state,
          @event_count_attempted,
          @event_count_delivered,
          @error_count,
          @details_json
        )`).run({
            started_at_ms: snapshot.startedAt === null ? null : toSqlBigInt(snapshot.startedAt),
            ended_at_ms: snapshot.endedAt === null ? null : toSqlBigInt(snapshot.endedAt),
            target_path: snapshot.targetPath,
            session_state: snapshot.state,
            event_count_attempted: snapshot.queuedEventCount,
            event_count_delivered: snapshot.deliveredEventCount,
            error_count: snapshot.lastError ? 1 : 0,
            details_json: serializeJson({
                lastError: snapshot.lastError,
                nextRetryAt: snapshot.nextRetryAt,
                consecutiveFailureCount: snapshot.consecutiveFailureCount,
                recoveryHeartbeatCount: snapshot.recoveryHeartbeatCount,
                requiredRecoveryHeartbeats: snapshot.requiredRecoveryHeartbeats,
            }),
        });
        return Number(result.lastInsertRowid);
    }
    bumpReplayAttempts(limitToStates = []) {
        const pendingStates = limitToStates.length === 0 ? ["pending", "replaying"] : limitToStates;
        const placeholders = pendingStates.map(() => "?").join(", ");
        const result = this.#prepare(`UPDATE ingress_events
         SET replay_attempts = replay_attempts + 1
         WHERE replay_state IN (${placeholders})`).run(...pendingStates);
        return Number(result.changes);
    }
    updateReplayState(fromStates, nextState) {
        this.#assertOpen("update replay state");
        if (fromStates.length === 0)
            return 0;
        const placeholders = fromStates.map(() => "?").join(", ");
        return this.#withTransaction(() => {
            const delta = this.#readCapacityDeltaForStates(fromStates, nextState);
            const result = this.#prepare(`UPDATE ingress_events
           SET replay_state = ?
           WHERE replay_state IN (${placeholders})`).run(nextState, ...fromStates);
            this.#adjustCapacityAccounting(delta.rows, delta.bytes);
            return Number(result.changes);
        });
    }
    claimReplayBatch(limit, deliveryMode = "replay_through_dedupe") {
        if (limit <= 0) {
            return [];
        }
        return this.#withTransaction(() => {
            const rows = this.#prepareReadBigInts(`SELECT
               rowid AS row_id,
               payload_json,
               source_path,
               source_stream_id,
               replay_attempts
             FROM ingress_events
             WHERE replay_state = 'pending'
               AND (retry_not_before_ms IS NULL OR retry_not_before_ms <= ?)
             ORDER BY monitor_ingest_at_ms ASC, rowid ASC
             LIMIT ?`).all(toSqlBigInt(this.#now()), limit);
            if (rows.length === 0) {
                return [];
            }
            const ids = rows.map((row) => Number(row.row_id));
            const placeholders = ids.map(() => "?").join(", ");
            this.#prepare(`UPDATE ingress_events
             SET replay_state = 'replaying',
                 replay_attempts = replay_attempts + 1,
                 retry_not_before_ms = NULL,
                 replay_claimed_at_ms = ?,
                 delivery_mode = ?
             WHERE rowid IN (${placeholders})`).run(toSqlBigInt(this.#now()), deliveryMode, ...ids);
            return rows.map((row) => ({
                rowId: Number(row.row_id),
                event: deserializeJson(row.payload_json),
                sourcePath: row.source_path,
                sourceStreamId: row.source_stream_id,
                deliveryMode,
                replayAttempts: Number(row.replay_attempts) + 1,
            }));
        });
    }
    markReplayBatchDelivered(rowIds) {
        return this.#updateReplayRows(rowIds, "delivered", null, (transitionedRowIds) => this.#lifecycleHooks.onReplayRowsDelivered?.(transitionedRowIds));
    }
    markIngressRowsDelivered(rowIds) {
        return this.#updateReplayRows(rowIds, "delivered", null, (transitionedRowIds) => this.#lifecycleHooks.onIngressRowsDelivered?.(transitionedRowIds));
    }
    resetReplayBatchToPending(rowIds, retryNotBeforeMs) {
        return this.#updateReplayRows(rowIds, "pending", retryNotBeforeMs);
    }
    deadLetterReplayBatch(rowIds) {
        return this.#updateReplayRows(rowIds, "dead_letter", null);
    }
    reclaimStaleReplayRows(maxClaimAgeMs) {
        this.#assertOpen("reclaim stale replay rows");
        if (maxClaimAgeMs < 0n) {
            return 0;
        }
        const staleClaimCutoff = this.#now() - maxClaimAgeMs;
        let totalReclaimed = 0;
        while (true) {
            const reclaimedThisPass = this.#withTransaction(() => {
                const rowIds = this.#selectStaleReplayingRowIds(staleClaimCutoff);
                return this.#updateReplayRowsInTransaction(rowIds, "pending", null);
            });
            if (reclaimedThisPass === 0) {
                return totalReclaimed;
            }
            totalReclaimed += reclaimedThisPass;
        }
    }
    recoverRestartState() {
        const reclaimedInterruptedRows = this.#withTransaction(() => {
            const result = this.#prepare(`UPDATE ingress_events
           SET replay_state = 'pending',
               replay_claimed_at_ms = NULL
           WHERE replay_state = 'replaying'`).run();
            return Number(result.changes);
        });
        const stats = this.getStats();
        const attemptRow = this.#prepareReadBigInts(`SELECT MAX(replay_attempts) AS maximum_replay_attempts
         FROM ingress_events
         WHERE replay_state = 'pending'`).get();
        return {
            totalPendingRows: stats.totalPendingRows,
            retryWaitingRows: stats.retryWaitingRows,
            earliestRetryAt: stats.earliestRetryAt,
            maximumReplayAttempts: parseCount(attemptRow.maximum_replay_attempts),
            reclaimedInterruptedRows,
        };
    }
    pruneExpired(fullOutageActive = false) {
        this.#assertOpen("prune expired rows");
        const now = this.#now();
        const rollingWindowMs = fullOutageActive
            ? this.#config.fullOutageMaxWindowMs
            : this.#config.rollingBufferWindowMs;
        const rollingCutoff = now - rollingWindowMs;
        const hardCutoff = now - this.#config.fullOutageMaxWindowMs;
        const markedDeadLetter = this.#markExpiredPendingRows(hardCutoff, rollingCutoff);
        if (markedDeadLetter > 0) {
            this.#lifecycleHooks.onRetentionDeadLettered?.(markedDeadLetter);
        }
        const deletedRows = this.#deleteExpiredTerminalRows(now);
        if (deletedRows > 0) {
            this.#lifecycleHooks.onRetentionDeleted?.(deletedRows);
        }
        return {
            markedDeadLetter,
            deletedRows,
        };
    }
    checkpointWal(mode = "passive") {
        const pragmaMode = mode.toUpperCase();
        const row = this.#prepareReadBigInts(`PRAGMA wal_checkpoint(${pragmaMode})`).get();
        const values = Object.values(row ?? {});
        return {
            mode,
            busy: parseCount(values[0]) !== 0,
            logFrames: parseCount(values[1]),
            checkpointedFrames: parseCount(values[2]),
        };
    }
    getLifecycleStats() {
        const rows = this.#prepareReadBigInts(`SELECT replay_state, COUNT(*) AS count
         FROM ingress_events
         WHERE replay_state IN ('delivered', 'dead_letter')
         GROUP BY replay_state`).all();
        const stats = { deliveredRows: 0, deadLetterRows: 0 };
        for (const row of rows) {
            if (row.replay_state === "delivered")
                stats.deliveredRows = parseCount(row.count);
            else
                stats.deadLetterRows = parseCount(row.count);
        }
        return stats;
    }
    getStats() {
        const totalPendingRows = this.getPendingRowCount();
        const oldestPendingRow = this.#prepareReadBigInts(`SELECT MIN(monitor_ingest_at_ms) AS oldest
         FROM ingress_events
         WHERE replay_state IN ('pending', 'replaying')`).get();
        const retryWaitingRow = this.#prepareReadBigInts(`SELECT
           COUNT(*) AS count,
           MIN(retry_not_before_ms) AS earliest_retry_at
         FROM ingress_events
         WHERE replay_state = 'pending'
           AND retry_not_before_ms IS NOT NULL
           AND retry_not_before_ms > ?`).get(toSqlBigInt(this.#now()));
        const bySourceRows = this.#prepareReadBigInts(`SELECT source_path, COUNT(*) AS count
         FROM ingress_events
         WHERE replay_state IN ('pending', 'replaying')
         GROUP BY source_path`).all();
        const byDeliveryRows = this.#prepareReadBigInts(`SELECT delivery_mode, COUNT(*) AS count
         FROM ingress_events
         WHERE replay_state IN ('pending', 'replaying')
         GROUP BY delivery_mode`).all();
        const sourceCounts = {
            transport_normalized_stream: 0,
            deduped_observation: 0,
        };
        for (const row of bySourceRows) {
            sourceCounts[row.source_path] = parseCount(row.count);
        }
        const deliveryCounts = {};
        for (const row of byDeliveryRows) {
            deliveryCounts[row.delivery_mode] = parseCount(row.count);
        }
        const oldestPendingAt = parseBigInt(oldestPendingRow.oldest);
        const oldestPendingAgeMs = oldestPendingAt === 0n ? 0n : this.#now() - oldestPendingAt;
        const earliestRetryAtRaw = parseBigInt(retryWaitingRow.earliest_retry_at);
        return {
            totalPendingRows,
            oldestPendingAgeMs,
            retryWaitingRows: parseCount(retryWaitingRow.count),
            earliestRetryAt: earliestRetryAtRaw === 0n ? null : earliestRetryAtRaw,
            pendingRowsBySourcePath: sourceCounts,
            pendingRowsByDeliveryMode: deliveryCounts,
        };
    }
    getPendingRowCount() {
        return this.#pendingRowCount;
    }
    #readPendingRowCount() {
        const row = this.#prepareReadBigInts(`SELECT pending_rows AS count
         FROM reservoir_capacity_state
        WHERE singleton_id = 1`).get();
        return parseCount(row.count);
    }
    getDatabasePath() {
        return this.#config.databasePath;
    }
    getStorageSnapshot() {
        this.#assertOpen("read reservoir storage statistics");
        if (this.#storageEvidenceReader) {
            try {
                return { ...this.#storageEvidenceReader() };
            }
            catch {
                return unknownStorageSnapshot();
            }
        }
        if (this.#config.databasePath === ":memory:") {
            return unknownStorageSnapshot();
        }
        try {
            const databasePath = normalizeDatabasePath(this.#config.databasePath);
            const databaseBytes = existsSync(databasePath)
                ? statSync(databasePath, { bigint: true }).size
                : 0n;
            const walPath = `${databasePath}-wal`;
            const walBytes = existsSync(walPath)
                ? statSync(walPath, { bigint: true }).size
                : 0n;
            const filesystem = statfsSync(dirname(databasePath), { bigint: true });
            const availableBytes = filesystem.bavail * filesystem.bsize;
            const totalBytes = filesystem.blocks * filesystem.bsize;
            const { pressure, usedPercent } = projectFilesystemStorage(availableBytes, totalBytes);
            return {
                pressure,
                databaseBytes: databaseBytes.toString(),
                walBytes: walBytes.toString(),
                filesystemAvailableBytes: availableBytes.toString(),
                filesystemTotalBytes: totalBytes.toString(),
                filesystemUsedPercent: usedPercent,
            };
        }
        catch {
            return unknownStorageSnapshot();
        }
    }
    close() {
        if (this.#closed) {
            return;
        }
        let checkpointError;
        try {
            this.checkpointWal("passive");
        }
        catch (error) {
            checkpointError = error;
        }
        this.#db.close();
        this.#closed = true;
        if (checkpointError !== undefined) {
            throw checkpointError;
        }
    }
    #updateReplayRows(rowIds, nextState, retryNotBeforeMs, onCommitted) {
        this.#assertOpen("update replay rows");
        if (rowIds.length === 0) {
            return 0;
        }
        const uniqueRowIds = [...new Set(rowIds)];
        const result = this.#withTransaction(() => {
            const placeholders = uniqueRowIds.map(() => "?").join(", ");
            const rows = this.#prepareReadBigInts(`SELECT rowid AS row_id, replay_state
           FROM ingress_events
          WHERE rowid IN (${placeholders})`).all(...uniqueRowIds);
            const transitionedRowIds = rows
                .filter((row) => row.replay_state !== nextState)
                .map((row) => Number(row.row_id));
            return {
                changes: this.#updateReplayRowsInTransaction(uniqueRowIds, nextState, retryNotBeforeMs),
                transitionedRowIds,
            };
        });
        if (result.transitionedRowIds.length > 0)
            onCommitted?.(result.transitionedRowIds);
        return result.changes;
    }
    #updateReplayRowsInTransaction(rowIds, nextState, retryNotBeforeMs) {
        if (rowIds.length === 0)
            return 0;
        const uniqueRowIds = [...new Set(rowIds)];
        const delta = this.#readCapacityDeltaForRowIds(uniqueRowIds, nextState);
        const placeholders = uniqueRowIds.map(() => "?").join(", ");
        const result = this.#prepare(`UPDATE ingress_events
         SET replay_state = ?,
             retry_not_before_ms = ?,
             replay_claimed_at_ms = NULL,
             terminal_at_ms = ?
         WHERE rowid IN (${placeholders})`).run(nextState, retryNotBeforeMs === null || retryNotBeforeMs === undefined
            ? null
            : toSqlBigInt(retryNotBeforeMs), nextState === "delivered" || nextState === "dead_letter"
            ? toSqlBigInt(this.#now())
            : null, ...uniqueRowIds);
        this.#adjustCapacityAccounting(delta.rows, delta.bytes);
        return Number(result.changes);
    }
    #markExpiredPendingRows(hardCutoff, rollingCutoff) {
        const pendingBatchSize = this.#config.pruneBatchSize;
        return this.#withTransaction(() => {
            const rowIds = this.#selectExpiredPendingRowIds(hardCutoff, rollingCutoff, pendingBatchSize);
            return this.#updateReplayRowsInTransaction(rowIds, "dead_letter", null);
        });
    }
    #deleteExpiredTerminalRows(now) {
        const deleteBatchSize = this.#config.pruneBatchSize;
        return this.#withTransaction(() => {
            const rowIds = this.#selectExpiredTerminalRowIds(now, deleteBatchSize);
            return this.#deleteRowsByIds(rowIds);
        });
    }
    #selectExpiredPendingRowIds(hardCutoff, rollingCutoff, limit) {
        const rows = this.#prepareReadBigInts(`SELECT rowid AS row_id
         FROM ingress_events
         WHERE replay_state = 'pending'
           AND (
             monitor_ingest_at_ms <= @hard_cutoff
             OR (
               retry_not_before_ms IS NULL
               AND monitor_ingest_at_ms <= @rolling_cutoff
             )
           )
         ORDER BY monitor_ingest_at_ms ASC, rowid ASC
         LIMIT @limit`).all({
            hard_cutoff: toSqlBigInt(hardCutoff),
            rolling_cutoff: toSqlBigInt(rollingCutoff),
            limit,
        });
        return rows.map((row) => Number(row.row_id));
    }
    #selectStaleReplayingRowIds(staleClaimCutoff) {
        const rows = this.#prepareReadBigInts(`SELECT rowid AS row_id
         FROM ingress_events
         WHERE replay_state = 'replaying'
           AND (
             replay_claimed_at_ms IS NULL
             OR replay_claimed_at_ms <= @stale_claim_cutoff
           )
         ORDER BY monitor_ingest_at_ms ASC, rowid ASC
         LIMIT @limit`).all({
            stale_claim_cutoff: toSqlBigInt(staleClaimCutoff),
            limit: this.#config.pruneBatchSize,
        });
        return rows.map((row) => Number(row.row_id));
    }
    #selectExpiredTerminalRowIds(now, limit) {
        const rows = this.#prepareReadBigInts(`SELECT rowid AS row_id
         FROM ingress_events
         WHERE terminal_at_ms IS NOT NULL
           AND (
             (replay_state = 'delivered' AND terminal_at_ms <= @delivered_cutoff)
             OR
             (replay_state = 'dead_letter' AND terminal_at_ms <= @dead_letter_cutoff)
           )
         ORDER BY terminal_at_ms ASC, rowid ASC
         LIMIT @limit`).all({
            delivered_cutoff: toSqlBigInt(now - (this.#config.deliveredRetentionMs ?? 24n * 60n * 60n * 1000n)),
            dead_letter_cutoff: toSqlBigInt(now - (this.#config.deadLetterRetentionMs ?? 7n * 24n * 60n * 60n * 1000n)),
            limit,
        });
        return rows.map((row) => Number(row.row_id));
    }
    #deleteRowsByIds(rowIds) {
        if (rowIds.length === 0) {
            return 0;
        }
        const placeholders = rowIds.map(() => "?").join(", ");
        const result = this.#prepare(`DELETE FROM ingress_events
         WHERE rowid IN (${placeholders})`).run(...rowIds);
        return Number(result.changes);
    }
    #readCapacityDeltaForStates(fromStates, nextState) {
        const placeholders = fromStates.map(() => "?").join(", ");
        const rows = this.#prepareReadBigInts(`SELECT replay_state, serialized_event_bytes
         FROM ingress_events
        WHERE replay_state IN (${placeholders})`).all(...fromStates);
        return this.#calculateCapacityDelta(rows, nextState);
    }
    #readCapacityDeltaForRowIds(rowIds, nextState) {
        const placeholders = rowIds.map(() => "?").join(", ");
        const rows = this.#prepareReadBigInts(`SELECT replay_state, serialized_event_bytes
         FROM ingress_events
        WHERE rowid IN (${placeholders})`).all(...rowIds);
        return this.#calculateCapacityDelta(rows, nextState);
    }
    #calculateCapacityDelta(rows, nextState) {
        const nextPending = isPendingReplayState(nextState);
        let rowDelta = 0;
        let byteDelta = 0n;
        for (const row of rows) {
            const currentPending = isPendingReplayState(row.replay_state);
            if (currentPending === nextPending)
                continue;
            const direction = nextPending ? 1 : -1;
            rowDelta += direction;
            byteDelta += BigInt(direction) * parseBigInt(row.serialized_event_bytes);
        }
        return { rows: rowDelta, bytes: byteDelta };
    }
    #adjustCapacityAccounting(rowDelta, byteDelta) {
        if (rowDelta === 0 && byteDelta === 0n)
            return;
        const result = this.#prepare(`UPDATE reservoir_capacity_state
          SET pending_rows = pending_rows + ?,
              pending_serialized_bytes = pending_serialized_bytes + ?
        WHERE singleton_id = 1`).run(rowDelta, toSqlBigInt(byteDelta));
        if (Number(result.changes) !== 1) {
            throw new MonitorCapacityAccountingError(this.#config.databasePath, "The singleton accounting row disappeared during a capacity-changing transaction.");
        }
        this.#pendingRowCount += rowDelta;
    }
    #assertPendingCapacityAdmission(replayState, serializedEventBytes) {
        if (!isPendingReplayState(replayState))
            return;
        const { maxPendingRows, maxPendingSerializedBytes } = this.#config.capacity;
        if (maxPendingRows === null && maxPendingSerializedBytes === null)
            return;
        const statement = this.#prepareReadBigInts(`SELECT pending_rows, pending_serialized_bytes
         FROM reservoir_capacity_state
        WHERE singleton_id = 1`);
        const state = statement.get();
        const pendingRows = parseBigInt(state.pending_rows);
        const pendingBytes = parseBigInt(state.pending_serialized_bytes);
        const attemptedRows = pendingRows + 1n;
        if (maxPendingRows !== null && attemptedRows > BigInt(maxPendingRows)) {
            this.#refuseCapacity({
                limitingDimension: "pending_rows",
                reasonCode: "MONITOR_CAPACITY_PENDING_ROWS",
                limit: maxPendingRows,
                current: pendingRows,
                attempted: attemptedRows,
            });
        }
        const attemptedBytes = pendingBytes + serializedEventBytes;
        if (maxPendingSerializedBytes !== null &&
            attemptedBytes > maxPendingSerializedBytes) {
            this.#refuseCapacity({
                limitingDimension: "pending_serialized_bytes",
                reasonCode: "MONITOR_CAPACITY_PENDING_SERIALIZED_BYTES",
                limit: maxPendingSerializedBytes,
                current: pendingBytes,
                attempted: attemptedBytes,
            });
        }
    }
    #assertFilesystemReserveAdmission() {
        const reserve = this.#config.capacity.filesystemReserve;
        if (reserve === null)
            return;
        const storage = this.getStorageSnapshot();
        const available = parseOptionalUnsignedDecimal(storage.filesystemAvailableBytes);
        if (available === null) {
            if (this.#filesystemReserveLatched) {
                const lastKnown = this.#lastKnownFilesystemAvailableBytes;
                this.#refuseCapacity({
                    limitingDimension: "filesystem_reserve",
                    reasonCode: "MONITOR_CAPACITY_FILESYSTEM_RESERVE",
                    limit: reserve.resumeAvailableBytes,
                    current: lastKnown ?? "unknown",
                    attempted: lastKnown ?? "unknown",
                });
            }
            if (reserve.unavailableEvidence === "refuse_admission") {
                this.#refuseCapacity({
                    limitingDimension: "filesystem_evidence_unavailable",
                    reasonCode: "MONITOR_CAPACITY_FILESYSTEM_EVIDENCE_UNAVAILABLE",
                    limit: reserve.minimumAvailableBytes,
                    current: "unknown",
                    attempted: "unknown",
                });
            }
            return;
        }
        this.#lastKnownFilesystemAvailableBytes = available;
        if (available <= reserve.minimumAvailableBytes) {
            this.#filesystemReserveLatched = true;
        }
        else if (available >= reserve.resumeAvailableBytes) {
            this.#filesystemReserveLatched = false;
        }
        if (this.#filesystemReserveLatched) {
            this.#refuseCapacity({
                limitingDimension: "filesystem_reserve",
                reasonCode: "MONITOR_CAPACITY_FILESYSTEM_RESERVE",
                limit: available <= reserve.minimumAvailableBytes
                    ? reserve.minimumAvailableBytes
                    : reserve.resumeAvailableBytes,
                current: available,
                attempted: available,
            });
        }
    }
    #refuseCapacity(options) {
        const error = new MonitorCapacityRefusedError(options);
        this.#capacityRefusedTotal = incrementSafeCounter(this.#capacityRefusedTotal);
        this.#lastCapacityRefusal = {
            occurredAtMs: this.#now().toString(),
            limitingDimension: error.limitingDimension,
            reasonCode: error.reasonCode,
            limit: error.limit,
            current: error.current,
            attempted: error.attempted,
            retryable: error.retryable,
            recommendedAction: error.recommendedAction,
        };
        throw error;
    }
    #getCapacitySnapshot() {
        this.#assertOpen("read the capacity snapshot");
        const state = this.#prepareReadBigInts(`SELECT pending_rows, pending_serialized_bytes
         FROM reservoir_capacity_state
        WHERE singleton_id = 1`).get();
        const pendingRows = parseBigInt(state.pending_rows);
        const pendingBytes = parseBigInt(state.pending_serialized_bytes);
        const storage = this.getStorageSnapshot();
        const available = parseOptionalUnsignedDecimal(storage.filesystemAvailableBytes);
        const reserve = this.#config.capacity.filesystemReserve;
        let posture = "open";
        let reasonCode = null;
        let limitingDimension = null;
        if (reserve !== null) {
            if (available === null) {
                if (this.#filesystemReserveLatched) {
                    posture = "refusing";
                    reasonCode = "MONITOR_CAPACITY_FILESYSTEM_RESERVE";
                    limitingDimension = "filesystem_reserve";
                }
                else {
                    posture = reserve.unavailableEvidence === "refuse_admission"
                        ? "refusing"
                        : "unknown";
                    reasonCode = "MONITOR_CAPACITY_FILESYSTEM_EVIDENCE_UNAVAILABLE";
                    limitingDimension = "filesystem_evidence_unavailable";
                }
            }
            else if (available <= reserve.minimumAvailableBytes ||
                (this.#filesystemReserveLatched && available < reserve.resumeAvailableBytes)) {
                posture = "refusing";
                reasonCode = "MONITOR_CAPACITY_FILESYSTEM_RESERVE";
                limitingDimension = "filesystem_reserve";
            }
        }
        if (posture !== "refusing") {
            const maxRows = this.#config.capacity.maxPendingRows;
            const maxBytes = this.#config.capacity.maxPendingSerializedBytes;
            if (maxRows !== null && pendingRows >= BigInt(maxRows)) {
                posture = "refusing";
                reasonCode = "MONITOR_CAPACITY_PENDING_ROWS";
                limitingDimension = "pending_rows";
            }
            else if (maxBytes !== null && pendingBytes >= maxBytes) {
                posture = "refusing";
                reasonCode = "MONITOR_CAPACITY_PENDING_SERIALIZED_BYTES";
                limitingDimension = "pending_serialized_bytes";
            }
        }
        const snapshot = {
            schema: "causal-order-monitor/capacity-snapshot",
            version: 1,
            generatedAtMs: this.#now().toString(),
            overflowPolicy: "reject_new",
            admission: { posture, reasonCode, limitingDimension },
            limits: {
                maxSerializedEventBytes: this.#config.capacity.maxSerializedEventBytes?.toString() ?? null,
                maxPendingRows: this.#config.capacity.maxPendingRows,
                maxPendingSerializedBytes: this.#config.capacity.maxPendingSerializedBytes?.toString() ?? null,
                filesystemReserve: reserve === null
                    ? null
                    : {
                        minimumAvailableBytes: reserve.minimumAvailableBytes.toString(),
                        resumeAvailableBytes: reserve.resumeAvailableBytes.toString(),
                        unavailableEvidence: reserve.unavailableEvidence,
                    },
            },
            usage: {
                pendingRows: Number(pendingRows),
                pendingSerializedBytes: pendingBytes.toString(),
                databaseBytes: storage.databaseBytes,
                walBytes: storage.walBytes,
                filesystemAvailableBytes: storage.filesystemAvailableBytes,
                filesystemTotalBytes: storage.filesystemTotalBytes,
            },
            utilization: {
                pendingRowsPercent: utilizationPercent(pendingRows, this.#config.capacity.maxPendingRows === null
                    ? null
                    : BigInt(this.#config.capacity.maxPendingRows)),
                pendingSerializedBytesPercent: utilizationPercent(pendingBytes, this.#config.capacity.maxPendingSerializedBytes),
            },
            lastRefusal: this.#lastCapacityRefusal === null
                ? null
                : { ...this.#lastCapacityRefusal },
            counters: {
                refusedTotal: this.#capacityRefusedTotal,
                storageAppendFailureTotal: this.#storageAppendFailureTotal,
            },
        };
        this.#lifecycleHooks.onCapacitySnapshot?.(snapshot);
        return snapshot;
    }
    #prepare(sql) {
        this.#assertOpen("access reservoir storage");
        return this.#db.prepare(sql);
    }
    #prepareReadBigInts(sql) {
        this.#assertOpen("read reservoir storage");
        const statement = this.#db.prepare(sql);
        statement.setReadBigInts(true);
        return statement;
    }
    #withTransaction(work) {
        this.#assertOpen("run a reservoir transaction");
        this.#db.exec("BEGIN IMMEDIATE");
        try {
            const result = work();
            this.#db.exec("COMMIT");
            return result;
        }
        catch (error) {
            this.#db.exec("ROLLBACK");
            this.#pendingRowCount = this.#readPendingRowCount();
            throw error;
        }
    }
    #assertOpen(operation) {
        if (this.#closed) {
            throw new MonitorClosedError(operation);
        }
    }
}

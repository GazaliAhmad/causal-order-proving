import type { MonitorStoragePressure } from "../types/snapshots.js";
export interface FilesystemStorageProjection {
    pressure: MonitorStoragePressure;
    usedPercent: number | null;
}
export declare function projectFilesystemStorage(availableBytes: bigint, totalBytes: bigint): FilesystemStorageProjection;

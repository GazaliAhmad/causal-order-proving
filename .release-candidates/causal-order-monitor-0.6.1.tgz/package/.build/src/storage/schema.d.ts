import type { DatabaseSync } from "node:sqlite";
export declare const MONITOR_SQLITE_SCHEMA_VERSION = 3;
export interface MonitorSchemaInfo {
    currentVersion: number;
    latestSupportedVersion: number;
    migratedFromLegacy: boolean;
}
export type MonitorSchemaErrorCode = "ERR_MONITOR_SCHEMA_NEWER_THAN_SUPPORTED" | "ERR_MONITOR_SCHEMA_INCOMPATIBLE" | "ERR_MONITOR_SCHEMA_MIGRATION_FAILED";
export declare class MonitorSchemaError extends Error {
    readonly code: MonitorSchemaErrorCode;
    readonly databasePath: string;
    readonly detectedVersion: number | null;
    readonly latestSupportedVersion = 3;
    constructor(message: string, options: {
        code: MonitorSchemaErrorCode;
        databasePath: string;
        detectedVersion: number | null;
        cause?: unknown;
    });
}
export declare class MonitorSchemaVersionError extends MonitorSchemaError {
    constructor(databasePath: string, detectedVersion: number);
}
export declare class MonitorSchemaCompatibilityError extends MonitorSchemaError {
    constructor(databasePath: string, detectedVersion: number | null, reason: string);
}
export declare class MonitorSchemaMigrationError extends MonitorSchemaError {
    readonly fromVersion: number;
    readonly toVersion: number;
    constructor(databasePath: string, fromVersion: number, toVersion: number, cause: unknown);
}
export declare class MonitorCapacityAccountingError extends Error {
    readonly code: "ERR_MONITOR_CAPACITY_ACCOUNTING";
    readonly databasePath: string;
    constructor(databasePath: string, reason: string);
}
export declare const MONITOR_SQLITE_SCHEMA = "\nCREATE TABLE IF NOT EXISTS ingress_events (\n  monitor_ingest_seq INTEGER PRIMARY KEY AUTOINCREMENT,\n  id TEXT NOT NULL,\n  monitor_ingest_at_ms INTEGER NOT NULL,\n  source_node_id TEXT NOT NULL,\n  source_stream_id TEXT,\n  source_path TEXT NOT NULL,\n  event_id TEXT NOT NULL,\n  trace_id TEXT,\n  sequence TEXT,\n  logical_time_ms INTEGER NOT NULL,\n  payload_json TEXT NOT NULL,\n  serialized_event_bytes INTEGER NOT NULL CHECK (serialized_event_bytes >= 0),\n  payload_encoding TEXT NOT NULL DEFAULT 'json',\n  delivery_mode TEXT NOT NULL,\n  replay_state TEXT NOT NULL,\n  replay_attempts INTEGER NOT NULL DEFAULT 0,\n  retry_not_before_ms INTEGER,\n  replay_claimed_at_ms INTEGER,\n  terminal_at_ms INTEGER,\n  expires_at_ms INTEGER NOT NULL\n);\n\nCREATE INDEX IF NOT EXISTS idx_ingress_events_expires_at\n  ON ingress_events(expires_at_ms);\n\nCREATE INDEX IF NOT EXISTS idx_ingress_events_replay_state\n  ON ingress_events(replay_state);\n\nCREATE INDEX IF NOT EXISTS idx_ingress_events_replay_retry\n  ON ingress_events(replay_state, retry_not_before_ms);\n\nCREATE INDEX IF NOT EXISTS idx_ingress_events_replay_claimed\n  ON ingress_events(replay_state, replay_claimed_at_ms);\n\nCREATE INDEX IF NOT EXISTS idx_ingress_events_replay_ingest_time\n  ON ingress_events(replay_state, monitor_ingest_at_ms);\n\nCREATE INDEX IF NOT EXISTS idx_ingress_events_replay_expiry\n  ON ingress_events(replay_state, expires_at_ms);\n\nCREATE INDEX IF NOT EXISTS idx_ingress_events_terminal_retention\n  ON ingress_events(replay_state, terminal_at_ms);\n\nCREATE INDEX IF NOT EXISTS idx_ingress_events_source_path\n  ON ingress_events(source_path);\n\nCREATE TABLE IF NOT EXISTS reservoir_capacity_state (\n  singleton_id INTEGER PRIMARY KEY CHECK (singleton_id = 1),\n  pending_rows INTEGER NOT NULL CHECK (pending_rows >= 0),\n  pending_serialized_bytes INTEGER NOT NULL CHECK (pending_serialized_bytes >= 0)\n);\n\nCREATE TABLE IF NOT EXISTS component_health_log (\n  id INTEGER PRIMARY KEY AUTOINCREMENT,\n  recorded_at_ms INTEGER NOT NULL,\n  component TEXT NOT NULL,\n  health_state TEXT NOT NULL,\n  reason_code TEXT,\n  details_json TEXT NOT NULL\n);\n\nCREATE INDEX IF NOT EXISTS idx_component_health_log_component_time\n  ON component_health_log(component, recorded_at_ms);\n\nCREATE TABLE IF NOT EXISTS outage_windows (\n  id INTEGER PRIMARY KEY AUTOINCREMENT,\n  started_at_ms INTEGER NOT NULL,\n  ended_at_ms INTEGER,\n  dedupe_state TEXT NOT NULL,\n  causal_order_state TEXT NOT NULL,\n  buffer_mode TEXT NOT NULL,\n  notes_json TEXT NOT NULL\n);\n\nCREATE TABLE IF NOT EXISTS replay_sessions (\n  id INTEGER PRIMARY KEY AUTOINCREMENT,\n  started_at_ms INTEGER,\n  ended_at_ms INTEGER,\n  target_path TEXT NOT NULL,\n  session_state TEXT NOT NULL,\n  event_count_attempted INTEGER NOT NULL DEFAULT 0,\n  event_count_delivered INTEGER NOT NULL DEFAULT 0,\n  error_count INTEGER NOT NULL DEFAULT 0,\n  details_json TEXT NOT NULL\n);\n";
export declare function applyMonitorSchema(db: DatabaseSync, databasePath?: string): MonitorSchemaInfo;

import type { MonitorThrottleTier } from "./types/events.js";
import { createDefaultMonitorNow, createDefaultMonitorConfig, DEFAULT_MONITOR_CONFIG_FILE, type MonitorComponentHealthConfig, type MonitorCapacityConfig, type MonitorCapacityOverflowPolicy, type MonitorConfig, type MonitorHealthConfig, type MonitorJsonComponentHealthConfig, type MonitorJsonCapacityConfig, type MonitorJsonByteLimit, type MonitorJsonFilesystemReserveConfig, type MonitorJsonLifecycleConfig, type MonitorJsonConfig, type MonitorJsonDuration, type MonitorJsonHealthConfig, type MonitorJsonReplayConfig, type MonitorJsonReservoirConfig, type MonitorJsonThrottleConfig, type MonitorJsonThrottleTierConfig, type MonitorJsonTransportConfig, type MonitorReplayConfig, type MonitorFilesystemReserveConfig, type MonitorLifecycleConfig, type MonitorLifecycleOverflowPolicy, type MonitorStartupConfig, type MonitorReservoirConfig, type MonitorThrottleConfig, type MonitorThrottleTierConfig, type MonitorTransportConfig } from "./types/config.js";
export declare const MONITOR_CONFIG_ENV_VAR = "CAUSAL_ORDER_MONITOR_CONFIG";
export interface MonitorConfigEnvironmentOptions {
    env?: Record<string, string | undefined>;
    cwd?: string;
    defaultConfigFile?: string;
}
export interface MonitorConfigOverride {
    reservoir?: Partial<Omit<MonitorReservoirConfig, "capacity">> & {
        capacity?: Partial<MonitorCapacityConfig>;
    };
    transport?: Partial<MonitorTransportConfig>;
    health?: {
        transport?: Partial<MonitorComponentHealthConfig>;
        dedupe?: Partial<MonitorComponentHealthConfig>;
        causalOrder?: Partial<MonitorComponentHealthConfig>;
    };
    throttle?: {
        open?: Partial<MonitorThrottleTierConfig>;
        slow?: Partial<MonitorThrottleTierConfig>;
        verySlow?: Partial<MonitorThrottleTierConfig>;
        paused?: Partial<MonitorThrottleTierConfig>;
        defaultTier?: MonitorThrottleTier;
    };
    replay?: Partial<MonitorReplayConfig>;
    startup?: Partial<MonitorStartupConfig>;
    lifecycle?: Partial<MonitorLifecycleConfig>;
    now?: () => bigint;
}
export declare function parseMonitorConfigJson(jsonText: string): MonitorJsonConfig;
export declare function resolveMonitorConfig(config?: MonitorJsonConfig): MonitorConfig;
export declare function loadMonitorConfigFile(configPath?: string): MonitorConfig;
export declare function resolveMonitorConfigFromEnvironment(inlineConfig?: MonitorConfigOverride, options?: MonitorConfigEnvironmentOptions): MonitorConfig;
export declare function loadMonitorConfigFromEnvironment(options?: MonitorConfigEnvironmentOptions): MonitorConfig;
export { createDefaultMonitorNow, createDefaultMonitorConfig, DEFAULT_MONITOR_CONFIG_FILE, type MonitorComponentHealthConfig, type MonitorCapacityConfig, type MonitorCapacityOverflowPolicy, type MonitorConfig, type MonitorHealthConfig, type MonitorJsonComponentHealthConfig, type MonitorJsonCapacityConfig, type MonitorJsonByteLimit, type MonitorJsonFilesystemReserveConfig, type MonitorJsonLifecycleConfig, type MonitorJsonConfig, type MonitorJsonDuration, type MonitorJsonHealthConfig, type MonitorJsonReplayConfig, type MonitorJsonReservoirConfig, type MonitorJsonThrottleConfig, type MonitorJsonThrottleTierConfig, type MonitorJsonTransportConfig, type MonitorReplayConfig, type MonitorFilesystemReserveConfig, type MonitorLifecycleConfig, type MonitorLifecycleOverflowPolicy, type MonitorReservoirConfig, type MonitorThrottleConfig, type MonitorThrottleTierConfig, type MonitorTransportConfig, };

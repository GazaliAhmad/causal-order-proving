import { resolve } from "node:path";
export const DEFAULT_MONITOR_CONFIG_FILE = "monitor.config.json";
const DEFAULT_MONITOR_DB_PATH = resolve(".causal-order-monitor", "monitor.sqlite");
export function createDefaultMonitorNow() {
    const wallClockBaseMs = BigInt(Date.now());
    const monotonicBaseNs = process.hrtime.bigint();
    let lastEmittedMs = wallClockBaseMs;
    return () => {
        const monotonicElapsedMs = (process.hrtime.bigint() - monotonicBaseNs) / 1000000n;
        const candidateMs = wallClockBaseMs + monotonicElapsedMs;
        if (candidateMs < lastEmittedMs) {
            return lastEmittedMs;
        }
        lastEmittedMs = candidateMs;
        return candidateMs;
    };
}
export function createDefaultMonitorConfig() {
    return {
        reservoir: {
            databasePath: DEFAULT_MONITOR_DB_PATH,
            rollingBufferWindowMs: 4n * 60n * 60n * 1000n,
            fullOutageMaxWindowMs: 6n * 60n * 60n * 1000n,
            pruneIntervalMs: 60000n,
            pruneBatchSize: 1_000,
            deliveredRetentionMs: 24n * 60n * 60n * 1000n,
            deadLetterRetentionMs: 7n * 24n * 60n * 60n * 1000n,
            walAutoCheckpointPages: 1_000,
            capacity: {
                maxSerializedEventBytes: null,
                maxPendingRows: null,
                maxPendingSerializedBytes: null,
                filesystemReserve: null,
                overflowPolicy: "reject_new",
            },
        },
        transport: {
            heartbeatGraceMs: 15000n,
            reconnectBurstWindowMs: 30000n,
            sourceLabel: "@causal-order/transport",
        },
        health: {
            transport: {
                degradedAfterMs: 10000n,
                offlineAfterMs: 30000n,
            },
            dedupe: {
                degradedAfterMs: 10000n,
                offlineAfterMs: 30000n,
            },
            causalOrder: {
                degradedAfterMs: 10000n,
                offlineAfterMs: 30000n,
            },
        },
        throttle: {
            open: {
                maxEventsPerSecond: 5_000,
                batchSize: 500,
            },
            slow: {
                maxEventsPerSecond: 1_000,
                batchSize: 200,
            },
            verySlow: {
                maxEventsPerSecond: 250,
                batchSize: 50,
            },
            paused: {
                maxEventsPerSecond: 0,
                batchSize: 0,
            },
            defaultTier: "open",
        },
        replay: {
            healthConfirmationHeartbeats: 2,
            pauseLiveFlowDuringReplay: true,
            retryBackoffMs: 5000n,
        },
        startup: {
            healthPolicy: "optimistic",
        },
        lifecycle: {
            queueCapacity: 1_024,
            overflowPolicy: "drop_oldest",
            shutdownFlushTimeoutMs: 1000n,
        },
        now: createDefaultMonitorNow(),
    };
}

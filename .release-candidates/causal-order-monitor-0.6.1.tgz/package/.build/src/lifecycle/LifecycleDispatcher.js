import { MonitorClosedError } from "../boundary.js";
import { MONITOR_LIFECYCLE_EVENT_NAMES, } from "../types/lifecycle.js";
function incrementSaturating(value, amount = 1) {
    return Math.min(Number.MAX_SAFE_INTEGER, value + amount);
}
function deepFreeze(value, seen = new Set()) {
    if (value === null || typeof value !== "object" || seen.has(value)) {
        return value;
    }
    seen.add(value);
    for (const nested of Object.values(value)) {
        deepFreeze(nested, seen);
    }
    return Object.freeze(value);
}
function snapshotEvent(event) {
    const copied = structuredClone(event);
    if (!MONITOR_LIFECYCLE_EVENT_NAMES.includes(copied.type)) {
        throw new TypeError(`Unsupported lifecycle event type '${String(copied.type)}'.`);
    }
    if (!/^\d+$/.test(copied.occurredAtMs)) {
        throw new TypeError("Lifecycle occurredAtMs must be an unsigned decimal string.");
    }
    stripPayloadFields(copied);
    return deepFreeze(copied);
}
function stripPayloadFields(value, seen = new Set()) {
    if (value === null || typeof value !== "object" || seen.has(value))
        return;
    seen.add(value);
    if (!Array.isArray(value)) {
        const record = value;
        for (const key of ["payload", "payloadJson", "serializedEvent"])
            delete record[key];
    }
    for (const nested of Object.values(value)) {
        stripPayloadFields(nested, seen);
    }
}
export class LifecycleDispatcher {
    #config;
    #now;
    #listeners = new Map();
    #queue = [];
    #flushWaiters = new Set();
    #active = false;
    #scheduled = false;
    #closed = false;
    #subscriberCount = 0;
    #droppedTotal = 0;
    #listenerFailureTotal = 0;
    #lastDrop = null;
    constructor(config, now) {
        if (!Number.isSafeInteger(config.queueCapacity) || config.queueCapacity <= 0) {
            throw new TypeError("lifecycle.queueCapacity must be a positive safe integer.");
        }
        if (config.overflowPolicy !== "drop_oldest") {
            throw new TypeError("lifecycle.overflowPolicy must be 'drop_oldest'.");
        }
        if (typeof config.shutdownFlushTimeoutMs !== "bigint" || config.shutdownFlushTimeoutMs < 0n) {
            throw new TypeError("lifecycle.shutdownFlushTimeoutMs must be a non-negative bigint.");
        }
        this.#config = { ...config };
        this.#now = now;
    }
    subscribe(eventName, listener) {
        if (this.#closed)
            throw new MonitorClosedError("subscribe to lifecycle observations");
        if (!MONITOR_LIFECYCLE_EVENT_NAMES.includes(eventName)) {
            throw new TypeError(`Unsupported lifecycle event name '${String(eventName)}'.`);
        }
        if (typeof listener !== "function") {
            throw new TypeError("Lifecycle listener must be a function.");
        }
        let listeners = this.#listeners.get(eventName);
        if (!listeners) {
            listeners = new Set();
            this.#listeners.set(eventName, listeners);
        }
        const subscription = {
            listener: listener,
        };
        listeners.add(subscription);
        this.#subscriberCount += 1;
        let subscribed = true;
        return () => {
            if (!subscribed)
                return;
            subscribed = false;
            if (listeners?.delete(subscription))
                this.#subscriberCount -= 1;
            if (listeners?.size === 0)
                this.#listeners.delete(eventName);
        };
    }
    publish(event) {
        if (this.#closed)
            return false;
        const immutableEvent = snapshotEvent(event);
        if (this.#queue.length >= this.#config.queueCapacity) {
            const dropped = this.#queue.shift();
            if (dropped)
                this.#recordDrop(dropped, "queue_overflow");
        }
        this.#queue.push(immutableEvent);
        this.#scheduleDrain();
        return true;
    }
    flush(timeoutMs = this.#config.shutdownFlushTimeoutMs) {
        if (typeof timeoutMs !== "bigint" || timeoutMs < 0n) {
            return Promise.reject(new TypeError("Lifecycle flush timeoutMs must be a non-negative bigint."));
        }
        if (this.#closed)
            return Promise.resolve(this.#flushResult("closed"));
        if (!this.#active && this.#queue.length === 0) {
            return Promise.resolve(this.#flushResult("drained"));
        }
        return new Promise((resolve) => {
            const waiter = { resolve, timeout: null };
            const boundedTimeout = Number(timeoutMs > BigInt(2_147_483_647) ? 2147483647n : timeoutMs);
            waiter.timeout = setTimeout(() => {
                if (!this.#flushWaiters.delete(waiter))
                    return;
                resolve(this.#flushResult("timed_out"));
            }, boundedTimeout);
            this.#flushWaiters.add(waiter);
        });
    }
    getSnapshot() {
        return deepFreeze({
            schema: "causal-order-monitor/lifecycle-snapshot",
            version: 1,
            generatedAtMs: this.#now().toString(),
            status: this.#closed ? "closed" : "open",
            queueDepth: this.#queue.length,
            queueCapacity: this.#config.queueCapacity,
            overflowPolicy: this.#config.overflowPolicy,
            subscriberCount: this.#subscriberCount,
            droppedTotal: this.#droppedTotal,
            listenerFailureTotal: this.#listenerFailureTotal,
            lastDrop: this.#lastDrop,
        });
    }
    close() {
        if (this.#closed)
            return;
        this.#closed = true;
        for (const event of this.#queue.splice(0))
            this.#recordDrop(event, "shutdown");
        this.#listeners.clear();
        this.#subscriberCount = 0;
        for (const waiter of this.#flushWaiters) {
            if (waiter.timeout)
                clearTimeout(waiter.timeout);
            waiter.resolve(this.#flushResult("closed"));
        }
        this.#flushWaiters.clear();
    }
    #scheduleDrain() {
        if (this.#scheduled || this.#active || this.#closed)
            return;
        this.#scheduled = true;
        queueMicrotask(() => {
            this.#scheduled = false;
            void this.#drainNext();
        });
    }
    async #drainNext() {
        if (this.#active || this.#closed)
            return;
        const event = this.#queue.shift();
        if (!event) {
            this.#resolveDrainedWaiters();
            return;
        }
        this.#active = true;
        const listeners = [...(this.#listeners.get(event.type) ?? [])];
        await Promise.allSettled(listeners.map(async ({ listener }) => {
            try {
                await listener(event);
            }
            catch {
                if (!this.#closed) {
                    this.#listenerFailureTotal = incrementSaturating(this.#listenerFailureTotal);
                }
            }
        }));
        this.#active = false;
        if (this.#closed)
            return;
        if (this.#queue.length === 0)
            this.#resolveDrainedWaiters();
        else
            this.#scheduleDrain();
    }
    #recordDrop(event, reason) {
        this.#droppedTotal = incrementSaturating(this.#droppedTotal);
        this.#lastDrop = deepFreeze({
            occurredAtMs: this.#now().toString(),
            eventType: event.type,
            reason,
        });
    }
    #resolveDrainedWaiters() {
        for (const waiter of this.#flushWaiters) {
            if (waiter.timeout)
                clearTimeout(waiter.timeout);
            waiter.resolve(this.#flushResult("drained"));
        }
        this.#flushWaiters.clear();
    }
    #flushResult(status) {
        return deepFreeze({ status, queueDepth: this.#queue.length, activeDispatch: this.#active });
    }
}

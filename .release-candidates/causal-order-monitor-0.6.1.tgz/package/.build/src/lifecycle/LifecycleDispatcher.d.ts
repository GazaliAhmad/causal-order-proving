import type { MonitorLifecycleConfig } from "../types/config.js";
import { type MonitorLifecycleEventName, type MonitorLifecycleEvents, type MonitorLifecycleFacet, type MonitorLifecycleFlushResult, type MonitorLifecycleListener, type MonitorLifecycleSnapshotV1 } from "../types/lifecycle.js";
export declare class LifecycleDispatcher implements MonitorLifecycleFacet {
    #private;
    constructor(config: MonitorLifecycleConfig, now: () => bigint);
    subscribe<K extends MonitorLifecycleEventName>(eventName: K, listener: MonitorLifecycleListener<K>): () => void;
    publish<K extends MonitorLifecycleEventName>(event: MonitorLifecycleEvents[K]): boolean;
    flush(timeoutMs?: bigint): Promise<MonitorLifecycleFlushResult>;
    getSnapshot(): MonitorLifecycleSnapshotV1;
    close(): void;
}

import type { MonitorThrottleConfig } from "../types/config.js";
import type { MonitorRoutingMode, MonitorThrottleTier } from "../types/events.js";
import type { ReservoirStats } from "../types/snapshots.js";
export interface ThrottleDecision {
    tier: MonitorThrottleTier;
    targetEventsPerSecond: number;
    targetBatchSize: number;
    reason: string;
}
export declare class ThrottleController {
    #private;
    constructor(config: MonitorThrottleConfig);
    decide(routingMode: MonitorRoutingMode, reservoir: Pick<ReservoirStats, "totalPendingRows">): ThrottleDecision;
}

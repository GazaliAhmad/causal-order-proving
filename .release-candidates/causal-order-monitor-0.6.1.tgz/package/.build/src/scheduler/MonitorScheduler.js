import { LifecycleDispatcher } from "../lifecycle/LifecycleDispatcher.js";
const DEFAULT_INTERVAL_MS = 1_000;
export class MonitorScheduler {
    #adapter;
    #healthProbe;
    #healthIntervalMs;
    #replayIntervalMs;
    #pruneIntervalMs;
    #replayBatchSize;
    #closeAdapterOnStop;
    #timers;
    #now;
    #onError;
    #timer = null;
    #activeTick = null;
    #status = "stopped";
    #tickCount = 0;
    #lastError = null;
    #lastHealthAt = 0n;
    #lastReplayAt = 0n;
    #lastPruneAt = 0n;
    constructor(options) {
        this.#adapter = options.adapter;
        this.#healthProbe = options.healthProbe;
        this.#healthIntervalMs = positiveInterval(options.healthIntervalMs);
        this.#replayIntervalMs = positiveInterval(options.replayIntervalMs);
        this.#pruneIntervalMs = positiveInterval(options.pruneIntervalMs);
        this.#replayBatchSize = options.replayBatchSize;
        this.#closeAdapterOnStop = options.closeAdapterOnStop ?? false;
        this.#timers = options.timers ?? {
            setTimeout: (callback, delayMs) => setTimeout(callback, delayMs),
            clearTimeout: (handle) => clearTimeout(handle),
        };
        this.#now = options.now ?? (() => BigInt(Date.now()));
        this.#onError = options.onError;
    }
    getState() {
        return {
            status: this.#status,
            tickCount: this.#tickCount,
            lastError: this.#lastError,
        };
    }
    start() {
        if (this.#status === "running")
            return;
        this.#status = "running";
        this.#schedule(0);
    }
    async stop() {
        if (this.#status === "stopped" && this.#activeTick === null)
            return;
        this.#status = "stopped";
        if (this.#timer !== null) {
            this.#timers.clearTimeout(this.#timer);
            this.#timer = null;
        }
        const activeTick = this.#activeTick;
        if (activeTick !== null)
            await activeTick;
        if (this.#closeAdapterOnStop)
            this.#adapter.close();
    }
    async tick() {
        if (this.#status !== "running")
            return;
        if (this.#activeTick !== null)
            return this.#activeTick;
        const operation = this.#runTick();
        this.#activeTick = operation;
        try {
            await operation;
        }
        finally {
            if (this.#activeTick === operation)
                this.#activeTick = null;
        }
    }
    #schedule(delayMs) {
        if (this.#status !== "running" || this.#timer !== null)
            return;
        this.#timer = this.#timers.setTimeout(() => {
            this.#timer = null;
            void this.tick().finally(() => this.#schedule(this.#nextDelayMs()));
        }, Math.max(0, Math.ceil(delayMs)));
    }
    async #runTick() {
        this.#tickCount += 1;
        const now = this.#now();
        let outcome = "completed";
        try {
            if (this.#healthProbe && elapsedMs(now, this.#lastHealthAt) >= this.#healthIntervalMs) {
                await this.#healthProbe();
                this.#lastHealthAt = now;
            }
            if (elapsedMs(now, this.#lastReplayAt) >= this.#replayIntervalMs) {
                if (this.#replayTargetsOnline()) {
                    await this.#adapter.reconcileRecovery(this.#replayBatchSize);
                }
                this.#lastReplayAt = now;
            }
            if (elapsedMs(now, this.#lastPruneAt) >= this.#pruneIntervalMs) {
                this.#adapter.getRuntime().pruneReservoir();
                this.#lastPruneAt = now;
            }
        }
        catch (error) {
            outcome = "failed";
            this.#lastError = error;
            this.#onError?.(error);
        }
        finally {
            try {
                const endedAt = this.#now();
                this.#adapter.lifecycle.publish({
                    type: "operationDurationObserved",
                    occurredAtMs: endedAt.toString(),
                    operation: "scheduler.tick",
                    durationMs: (endedAt >= now ? endedAt - now : 0n).toString(),
                    outcome,
                });
            }
            catch {
                // Lifecycle observation is best effort and cannot alter scheduler outcomes.
            }
        }
    }
    #nextDelayMs() {
        const snapshot = this.#adapter.getReplaySnapshot();
        const retryAt = snapshot.nextRetryAt;
        if (retryAt !== null) {
            const remaining = retryAt - this.#now();
            if (remaining > 0n)
                return Number(remaining > 2147483647n ? 2147483647n : remaining);
        }
        return Math.min(this.#healthIntervalMs, this.#replayIntervalMs, this.#pruneIntervalMs);
    }
    #replayTargetsOnline() {
        const health = this.#adapter.getRuntime().getHealthSnapshot();
        return health.dedupe.state === "online" && health["causal-order"].state === "online";
    }
}
function positiveInterval(value) {
    if (value === undefined)
        return DEFAULT_INTERVAL_MS;
    if (!Number.isFinite(value) || value <= 0)
        throw new Error("Scheduler intervals must be positive finite numbers.");
    return value;
}
function elapsedMs(now, previous) {
    const elapsed = now - previous;
    return Number(elapsed > 2147483647n ? 2147483647n : elapsed);
}

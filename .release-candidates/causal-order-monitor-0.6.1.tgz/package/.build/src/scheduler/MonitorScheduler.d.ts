import type { TransportMonitorAdapter } from "../transport/TransportMonitorAdapter.js";
export interface MonitorSchedulerTimerApi {
    setTimeout(callback: () => void, delayMs: number): ReturnType<typeof setTimeout>;
    clearTimeout(handle: ReturnType<typeof setTimeout>): void;
}
export interface MonitorSchedulerOptions {
    adapter: TransportMonitorAdapter;
    healthProbe?: () => Promise<void> | void;
    healthIntervalMs?: number;
    replayIntervalMs?: number;
    pruneIntervalMs?: number;
    replayBatchSize?: number;
    closeAdapterOnStop?: boolean;
    timers?: MonitorSchedulerTimerApi;
    now?: () => bigint;
    onError?: (error: unknown) => void;
}
export interface MonitorSchedulerState {
    status: "stopped" | "running";
    tickCount: number;
    lastError: unknown | null;
}
export declare class MonitorScheduler {
    #private;
    constructor(options: MonitorSchedulerOptions);
    getState(): MonitorSchedulerState;
    start(): void;
    stop(): Promise<void>;
    tick(): Promise<void>;
}

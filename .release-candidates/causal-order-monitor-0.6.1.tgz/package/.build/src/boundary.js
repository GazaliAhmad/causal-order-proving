export class MonitorBoundaryError extends Error {
    code;
    operation;
    outcome;
    retryable;
    recommendedAction;
    constructor(failure, options = {}) {
        super(failure.message, options.cause === undefined ? undefined : { cause: options.cause });
        this.name = "MonitorBoundaryError";
        this.code = failure.code;
        this.operation = failure.operation;
        this.outcome = failure.outcome;
        this.retryable = failure.retryable;
        this.recommendedAction = failure.recommendedAction;
    }
    toJSON() {
        return {
            code: this.code,
            operation: this.operation,
            outcome: this.outcome,
            retryable: this.retryable,
            recommendedAction: this.recommendedAction,
            message: this.message,
        };
    }
}
export class MonitorClosedError extends MonitorBoundaryError {
    constructor(operation) {
        super({
            code: "ERR_MONITOR_CLOSED",
            operation,
            outcome: "definite_rejection",
            retryable: false,
            recommendedAction: "do_not_retry",
            message: `Cannot ${operation} because the monitor is closed.`,
        });
        this.name = "MonitorClosedError";
    }
}
export class MonitorAdmissionRefusedError extends MonitorBoundaryError {
    httpStatus = 503;
    decision;
    constructor(decision) {
        super({
            code: "ERR_MONITOR_ADMISSION_REFUSED",
            operation: "admit an ingress event",
            outcome: "definite_rejection",
            retryable: true,
            recommendedAction: "retry_when_admission_reopens",
            message: "The monitor is in a protective refusal posture; the event was not persisted. Return HTTP 503 when this error crosses an HTTP ingress boundary.",
        });
        this.name = "MonitorAdmissionRefusedError";
        this.decision = decision;
    }
}
export class MonitorCapacityRefusedError extends MonitorBoundaryError {
    httpStatus = 503;
    limitingDimension;
    reasonCode;
    limit;
    current;
    attempted;
    constructor(options) {
        const oversizedEvent = options.limitingDimension === "serialized_event_bytes";
        const filesystemReserve = options.limitingDimension === "filesystem_reserve";
        const unavailableEvidence = options.limitingDimension === "filesystem_evidence_unavailable";
        const recommendedAction = oversizedEvent
            ? "reduce_event_size"
            : filesystemReserve
                ? "free_local_storage_then_retry"
                : unavailableEvidence
                    ? "restore_capacity_evidence_then_retry"
                    : "retry_when_capacity_available";
        const message = filesystemReserve
            ? `The monitor refused ingress because observed filesystem availability ${String(options.current)} ` +
                `does not satisfy the configured reserve or hysteresis threshold ${String(options.limit)}. The event was not persisted. ` +
                "Return HTTP 503 when this error crosses an HTTP ingress boundary."
            : unavailableEvidence
                ? "The monitor refused ingress because filesystem capacity evidence is unavailable under the configured conservative policy. " +
                    "The event was not persisted. Return HTTP 503 when this error crosses an HTTP ingress boundary."
                : `The monitor refused ingress because ${options.limitingDimension} would be ` +
                    `${String(options.attempted)}, above the configured limit ${String(options.limit)}. ` +
                    "The event was not persisted. Return HTTP 503 when this error crosses an HTTP ingress boundary.";
        super({
            code: "ERR_MONITOR_CAPACITY_REFUSED",
            operation: "admit an ingress event",
            outcome: "definite_rejection",
            retryable: !oversizedEvent,
            recommendedAction,
            message,
        });
        this.name = "MonitorCapacityRefusedError";
        this.limitingDimension = options.limitingDimension;
        this.reasonCode = options.reasonCode;
        this.limit = String(options.limit);
        this.current = String(options.current);
        this.attempted = String(options.attempted);
    }
    toJSON() {
        return {
            ...super.toJSON(),
            code: "ERR_MONITOR_CAPACITY_REFUSED",
            httpStatus: this.httpStatus,
            limitingDimension: this.limitingDimension,
            reasonCode: this.reasonCode,
            limit: this.limit,
            current: this.current,
            attempted: this.attempted,
        };
    }
}
export class MonitorIndeterminateOutcomeError extends MonitorBoundaryError {
    rowId;
    constructor(operation, rowId, cause) {
        super({
            code: "ERR_MONITOR_OUTCOME_INDETERMINATE",
            operation,
            outcome: "indeterminate",
            retryable: false,
            recommendedAction: "reconcile_from_monitor_storage",
            message: `The monitor persisted row ${rowId ?? "unknown"} but ${operation} did not complete observably. ` +
                "Reconcile from monitor storage; do not assume the event was absent or delivered.",
        }, { cause });
        this.name = "MonitorIndeterminateOutcomeError";
        this.rowId = rowId;
    }
}
function errorText(error) {
    return error instanceof Error ? error.message : String(error);
}
export function classifyMonitorBoundaryFailure(error, operation = "perform the monitor operation") {
    if (error instanceof MonitorBoundaryError) {
        return error.toJSON();
    }
    const message = errorText(error);
    const normalized = message.toLowerCase();
    if (normalized.includes("database is locked") || normalized.includes("database is busy")) {
        return {
            code: "ERR_MONITOR_STORAGE_BUSY",
            operation,
            outcome: "definite_rejection",
            retryable: true,
            recommendedAction: "retry_after_contention_clears",
            message,
        };
    }
    if (normalized.includes("database or disk is full") || normalized.includes("sqlite_full")) {
        return {
            code: "ERR_MONITOR_STORAGE_FULL",
            operation,
            outcome: "definite_rejection",
            retryable: true,
            recommendedAction: "free_local_storage_then_retry",
            message,
        };
    }
    if (normalized.includes("readonly") || normalized.includes("read-only")) {
        return {
            code: "ERR_MONITOR_STORAGE_READ_ONLY",
            operation,
            outcome: "definite_rejection",
            retryable: true,
            recommendedAction: "restore_writable_local_storage_then_retry",
            message,
        };
    }
    if (normalized.includes("disk i/o") ||
        normalized.includes("sqlite_ioerr") ||
        normalized.includes("unable to open database")) {
        return {
            code: "ERR_MONITOR_STORAGE_IO",
            operation,
            outcome: "definite_rejection",
            retryable: false,
            recommendedAction: "stop_and_inspect_storage",
            message,
        };
    }
    return null;
}
export function deriveMonitorAdmissionDecision(decision) {
    if (decision.action === "pause") {
        return {
            posture: "protective_refusal",
            accepted: false,
            httpStatus: 503,
            reasonCode: "MONITOR_PROTECTIVE_THROTTLE",
        };
    }
    if (decision.action === "buffer_only") {
        return {
            posture: "accepted_buffered",
            accepted: true,
            httpStatus: 202,
            reasonCode: decision.routingMode === "replay_through_dedupe"
                ? "MONITOR_RECOVERY_GATE_BUFFERING"
                : "MONITOR_OUTAGE_BUFFERING",
        };
    }
    return {
        posture: "accepted_live",
        accepted: true,
        httpStatus: 202,
        reasonCode: "MONITOR_LIVE_FLOW_AVAILABLE",
    };
}
export function toMonitorBoundaryError(error, operation) {
    if (error instanceof MonitorBoundaryError)
        return error;
    const failure = classifyMonitorBoundaryFailure(error, operation);
    return failure === null ? error : new MonitorBoundaryError(failure, { cause: error });
}

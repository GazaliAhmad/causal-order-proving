import type { MonitorIngressDecision } from "./types/events.js";
import type { MonitorAdmissionPosture, MonitorAdmissionReasonCode, MonitorCapacityLimitingDimension, MonitorCapacityReasonCode } from "./types/snapshots.js";
export type { MonitorCapacityLimitingDimension, MonitorCapacityReasonCode, } from "./types/snapshots.js";
export type MonitorBoundaryErrorCode = "ERR_MONITOR_CLOSED" | "ERR_MONITOR_ADMISSION_REFUSED" | "ERR_MONITOR_CAPACITY_REFUSED" | "ERR_MONITOR_STORAGE_BUSY" | "ERR_MONITOR_STORAGE_FULL" | "ERR_MONITOR_STORAGE_READ_ONLY" | "ERR_MONITOR_STORAGE_IO" | "ERR_MONITOR_OUTCOME_INDETERMINATE";
export type MonitorBoundaryOutcome = "definite_rejection" | "indeterminate";
export type MonitorBoundaryRecommendedAction = "do_not_retry" | "retry_when_admission_reopens" | "reduce_event_size" | "retry_when_capacity_available" | "restore_capacity_evidence_then_retry" | "retry_after_contention_clears" | "free_local_storage_then_retry" | "restore_writable_local_storage_then_retry" | "stop_and_inspect_storage" | "reconcile_from_monitor_storage";
export interface MonitorBoundaryFailure {
    code: MonitorBoundaryErrorCode;
    operation: string;
    outcome: MonitorBoundaryOutcome;
    retryable: boolean;
    recommendedAction: MonitorBoundaryRecommendedAction;
    message: string;
}
export interface MonitorAdmissionDecision {
    posture: MonitorAdmissionPosture;
    accepted: boolean;
    httpStatus: 202 | 503;
    reasonCode: MonitorAdmissionReasonCode;
}
export interface MonitorCapacityRefusalEvidence extends MonitorBoundaryFailure {
    code: "ERR_MONITOR_CAPACITY_REFUSED";
    httpStatus: 503;
    limitingDimension: MonitorCapacityLimitingDimension;
    reasonCode: MonitorCapacityReasonCode;
    limit: string;
    current: string;
    attempted: string;
}
export declare class MonitorBoundaryError extends Error {
    readonly code: MonitorBoundaryErrorCode;
    readonly operation: string;
    readonly outcome: MonitorBoundaryOutcome;
    readonly retryable: boolean;
    readonly recommendedAction: MonitorBoundaryRecommendedAction;
    constructor(failure: MonitorBoundaryFailure, options?: {
        cause?: unknown;
    });
    toJSON(): MonitorBoundaryFailure;
}
export declare class MonitorClosedError extends MonitorBoundaryError {
    constructor(operation: string);
}
export declare class MonitorAdmissionRefusedError extends MonitorBoundaryError {
    readonly httpStatus: 503;
    readonly decision: MonitorIngressDecision;
    constructor(decision: MonitorIngressDecision);
}
export declare class MonitorCapacityRefusedError extends MonitorBoundaryError {
    readonly httpStatus: 503;
    readonly limitingDimension: MonitorCapacityLimitingDimension;
    readonly reasonCode: MonitorCapacityReasonCode;
    readonly limit: string;
    readonly current: string;
    readonly attempted: string;
    constructor(options: {
        limitingDimension: MonitorCapacityLimitingDimension;
        reasonCode: MonitorCapacityReasonCode;
        limit: bigint | number | string;
        current: bigint | number | string;
        attempted: bigint | number | string;
    });
    toJSON(): MonitorCapacityRefusalEvidence;
}
export declare class MonitorIndeterminateOutcomeError extends MonitorBoundaryError {
    readonly rowId: number | null;
    constructor(operation: string, rowId: number | null, cause: unknown);
}
export declare function classifyMonitorBoundaryFailure(error: unknown, operation?: string): MonitorBoundaryFailure | null;
export declare function deriveMonitorAdmissionDecision(decision: MonitorIngressDecision): MonitorAdmissionDecision;
export declare function toMonitorBoundaryError(error: unknown, operation: string): unknown;

import type { MonitorReplayConfig } from "../types/config.js";
import type { MonitorComponent, MonitorHealthState } from "../types/events.js";
import type { ReplaySessionSnapshot } from "../types/snapshots.js";
import type { MonitorLifecyclePublisher } from "../types/lifecycle.js";
import { SQLiteReservoir, type ReservoirReplayEntry } from "../storage/SQLiteReservoir.js";
export interface ReplayBatch {
    session: ReplaySessionSnapshot;
    entries: ReservoirReplayEntry[];
    isDrainComplete: boolean;
}
export declare class ReplayCoordinator {
    #private;
    constructor(config: MonitorReplayConfig, reservoir: SQLiteReservoir, now: () => bigint, publishLifecycle?: MonitorLifecyclePublisher | null);
    getSnapshot(): ReplaySessionSnapshot;
    hasRecoveryConfirmation(): boolean;
    isGateClosed(): boolean;
    queueIfNeeded(): ReplaySessionSnapshot;
    start(): ReplaySessionSnapshot;
    claimNextBatch(limit: number): ReplayBatch;
    acknowledgeBatch(rowIds: ReadonlyArray<number>): ReplaySessionSnapshot;
    fail(error: string, rowIds?: ReadonlyArray<number>): ReplaySessionSnapshot;
    abort(reason: string, rowIds?: ReadonlyArray<number>): ReplaySessionSnapshot;
    complete(): ReplaySessionSnapshot;
    observeRecoveryHeartbeat(component: MonitorComponent, state: MonitorHealthState, allHealthy: boolean): ReplaySessionSnapshot;
    resetToIdle(): ReplaySessionSnapshot;
}

export type MonitorHarnessScenarioId = "monitor-healthy-rolling-4h" | "monitor-transport-outage-burst" | "monitor-dedupe-outage" | "monitor-order-outage" | "monitor-dual-outage" | "monitor-transport-dedupe-outage" | "monitor-transport-order-outage" | "monitor-transport-dedupe-order-outage" | "monitor-recovery-through-dedupe";
export type MonitorHarnessRuntimeKind = "deployment-runtime" | "adapter-runtime";
export interface MonitorHarnessArtifactSpec {
    fileName: string;
    purpose: string;
}
export interface MonitorHarnessExpectation {
    description: string;
}
export interface MonitorHarnessScenarioDefinition {
    id: MonitorHarnessScenarioId;
    runtimeKinds: ReadonlyArray<MonitorHarnessRuntimeKind>;
    title: string;
    description: string;
    expectedArtifacts: ReadonlyArray<MonitorHarnessArtifactSpec>;
    expectedRoutingModes: ReadonlyArray<string>;
    expectations: ReadonlyArray<MonitorHarnessExpectation>;
}
export declare const monitorHarnessArtifacts: ReadonlyArray<MonitorHarnessArtifactSpec>;
export declare const monitorHarnessScenarios: ReadonlyArray<MonitorHarnessScenarioDefinition>;
export interface MonitorHarnessAdapterContract {
    ingest(event: Record<string, unknown>): Promise<void> | void;
    updateComponentHealth(component: "transport" | "dedupe" | "causal-order", state: string): void;
    getSnapshot(): Record<string, unknown>;
    reconcileRecovery?(): Promise<Record<string, unknown> | null> | Record<string, unknown> | null;
    destroy(): void;
}

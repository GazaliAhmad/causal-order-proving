import { type MonitorConfig } from "../types/config.js";
import type { MonitorConfigOverride } from "../config.js";
import { type ReservoirLifecycleStats, type WalCheckpointMode, type WalCheckpointResult } from "../storage/SQLiteReservoir.js";
import type { MonitorSchemaInfo } from "../storage/schema.js";
import type { MonitorComponent, MonitorIngressDecision, MonitorHealthUpdate, MonitorIngressEvent, MonitorThrottleTier } from "../types/events.js";
import type { InspectedMonitorSnapshot, MonitorCapacityFacet, MonitorOperatorSnapshotV1, MonitorSnapshot, ReplaySessionSnapshot, ReservoirStats } from "../types/snapshots.js";
import type { MonitorLifecycleFacet } from "../types/lifecycle.js";
type ReplayOrchestrationOwner = "manual" | "adapter";
export declare class ReplayOwnershipError extends Error {
    readonly code = "ERR_MONITOR_REPLAY_OWNERSHIP";
    readonly attemptedAction: string;
    readonly actualOwner: ReplayOrchestrationOwner;
    readonly requestedOwner: ReplayOrchestrationOwner;
    constructor(attemptedAction: string, actualOwner: ReplayOrchestrationOwner, requestedOwner: ReplayOrchestrationOwner, guidance: string);
}
export declare class MonitorRuntime {
    #private;
    readonly capacity: MonitorCapacityFacet;
    readonly lifecycle: MonitorLifecycleFacet;
    constructor(config?: MonitorConfigOverride);
    getConfig(): Readonly<MonitorConfig>;
    getSnapshot(): MonitorSnapshot;
    getInspectedSnapshot(): InspectedMonitorSnapshot;
    getOperatorSnapshot(): MonitorOperatorSnapshotV1;
    getHealthSnapshot(): Record<MonitorComponent, import("../types/snapshots.js").MonitorComponentHealthSnapshot>;
    getReservoirStats(): ReservoirStats;
    getSchemaInfo(): Readonly<MonitorSchemaInfo>;
    getReservoirLifecycleStats(): ReservoirLifecycleStats;
    checkpointReservoirWal(mode?: WalCheckpointMode): WalCheckpointResult;
    getReplaySnapshot(): ReplaySessionSnapshot;
    getIngressDecision(): MonitorIngressDecision;
    updateComponentHealth(component: MonitorComponent, update: MonitorHealthUpdate): import("../types/snapshots.js").MonitorComponentHealthSnapshot;
    observeHeartbeat(component: MonitorComponent, observedAt?: bigint, details?: Record<string, unknown>): import("../types/snapshots.js").MonitorComponentHealthSnapshot;
    setThrottleTier(tier: MonitorThrottleTier): MonitorThrottleTier;
    bindReplayOrchestrationOwner(owner: ReplayOrchestrationOwner): ReplayOrchestrationOwner;
    queueReplay(): ReplaySessionSnapshot;
    queueManagedReplay(): ReplaySessionSnapshot;
    startReplay(): ReplaySessionSnapshot;
    claimManagedReplayBatch(limit?: number): import("../replay/ReplayCoordinator.js").ReplayBatch;
    acknowledgeManagedReplayBatch(rowIds: ReadonlyArray<number>): ReplaySessionSnapshot;
    failManagedReplay(error: string, rowIds?: ReadonlyArray<number>): ReplaySessionSnapshot;
    abortManagedReplay(reason: string, rowIds?: ReadonlyArray<number>): ReplaySessionSnapshot;
    claimReplayBatch(limit?: number): import("../replay/ReplayCoordinator.js").ReplayBatch;
    acknowledgeReplayBatch(rowIds: ReadonlyArray<number>): ReplaySessionSnapshot;
    acknowledgeIngressDelivery(rowIds: ReadonlyArray<number>): number;
    failReplay(error: string, rowIds?: ReadonlyArray<number>): ReplaySessionSnapshot;
    abortReplay(reason: string, rowIds?: ReadonlyArray<number>): ReplaySessionSnapshot;
    ingestTransportEvent(event: MonitorIngressEvent, sourceStreamId?: string | null): {
        rowId: number;
        decision: MonitorIngressDecision;
    };
    observeDedupeEvent(event: MonitorIngressEvent, sourceStreamId?: string | null): number;
    pruneReservoir(): {
        markedDeadLetter: number;
        deletedRows: number;
    };
    refreshHealthStates(at?: bigint): Record<MonitorComponent, import("../types/snapshots.js").MonitorComponentHealthSnapshot>;
    needsRecoveryReplay(): boolean;
    hasObservedRecoveryTransition(): boolean;
    isReplayRecoveryConfirmed(): boolean;
    close(): void;
}
export {};

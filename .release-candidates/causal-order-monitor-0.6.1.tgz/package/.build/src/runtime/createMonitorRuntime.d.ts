import { MonitorRuntime } from "./MonitorRuntime.js";
import { type MonitorConfigEnvironmentOptions, type MonitorConfigOverride } from "../config.js";
export declare function createMonitorRuntime(config?: MonitorConfigOverride): MonitorRuntime;
export declare function createMonitorRuntimeFromFile(configPath?: string): MonitorRuntime;
export declare function createMonitorRuntimeFromEnvironment(inlineConfig?: MonitorConfigOverride, options?: MonitorConfigEnvironmentOptions): MonitorRuntime;

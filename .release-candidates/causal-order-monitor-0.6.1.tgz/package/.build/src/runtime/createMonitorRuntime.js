import { MonitorRuntime } from "./MonitorRuntime.js";
import { loadMonitorConfigFile, resolveMonitorConfigFromEnvironment, } from "../config.js";
export function createMonitorRuntime(config = {}) {
    return new MonitorRuntime(config);
}
export function createMonitorRuntimeFromFile(configPath) {
    return new MonitorRuntime(loadMonitorConfigFile(configPath));
}
export function createMonitorRuntimeFromEnvironment(inlineConfig = {}, options = {}) {
    return new MonitorRuntime(resolveMonitorConfigFromEnvironment(inlineConfig, options));
}

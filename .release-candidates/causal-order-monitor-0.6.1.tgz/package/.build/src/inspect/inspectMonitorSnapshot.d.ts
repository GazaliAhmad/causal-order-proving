import type { InspectedMonitorSnapshot, MonitorOperatorSnapshotV1, MonitorSnapshot, MonitorStorageSnapshotV1 } from "../types/snapshots.js";
export declare function inspectMonitorSnapshot(snapshot: MonitorSnapshot): InspectedMonitorSnapshot;
export declare function inspectMonitorSnapshotV1(snapshot: MonitorSnapshot, storage?: MonitorStorageSnapshotV1): MonitorOperatorSnapshotV1;

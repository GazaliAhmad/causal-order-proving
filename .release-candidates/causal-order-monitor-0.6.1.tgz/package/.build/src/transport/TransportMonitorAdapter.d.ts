import { MonitorRuntime } from "../runtime/MonitorRuntime.js";
import { type MonitorConfigEnvironmentOptions, type MonitorConfigOverride } from "../config.js";
import type { MonitorComponent, MonitorDeliveryMode, MonitorIngressDecision, MonitorIngressEvent } from "../types/events.js";
import type { InspectedMonitorSnapshot, MonitorCapacityFacet, MonitorOperatorSnapshotV1, MonitorSnapshot, ReplaySessionSnapshot } from "../types/snapshots.js";
import type { MonitorLifecycleFacet } from "../types/lifecycle.js";
import { type MonitorAdmissionDecision } from "../boundary.js";
export interface MonitorAdapterForwardContext {
    rowId: number;
    sourceStreamId: string | null;
    deliveryMode: MonitorDeliveryMode;
    replay: boolean;
}
export interface MonitorAdapterHandlers {
    deliverToDedupe: (event: MonitorIngressEvent, context: MonitorAdapterForwardContext) => Promise<void> | void;
    deliverToOrder: (event: MonitorIngressEvent, context: MonitorAdapterForwardContext) => Promise<void> | void;
    onBuffered?: (event: MonitorIngressEvent, decision: MonitorIngressDecision, rowId: number) => Promise<void> | void;
    onDecision?: (event: MonitorIngressEvent, decision: MonitorIngressDecision, rowId: number) => Promise<void> | void;
    onReplayStateChange?: (snapshot: ReplaySessionSnapshot) => Promise<void> | void;
}
export interface MonitorIngestResult {
    rowId: number;
    decision: MonitorIngressDecision;
    admission: MonitorAdmissionDecision;
    forwardedTo: "dedupe" | "causal-order" | "buffer";
}
export interface ReplayPumpResult {
    snapshot: ReplaySessionSnapshot;
    claimedCount: number;
    deliveredCount: number;
    completed: boolean;
}
export declare class TransportMonitorAdapter {
    #private;
    readonly capacity: MonitorCapacityFacet;
    readonly lifecycle: MonitorLifecycleFacet;
    constructor(handlers: MonitorAdapterHandlers, config?: MonitorConfigOverride);
    getRuntime(): MonitorRuntime;
    getSnapshot(): MonitorSnapshot;
    getInspectedSnapshot(): InspectedMonitorSnapshot;
    getOperatorSnapshot(): MonitorOperatorSnapshotV1;
    getReplaySnapshot(): ReplaySessionSnapshot;
    updateComponentHealth(component: MonitorComponent, update: Parameters<MonitorRuntime["updateComponentHealth"]>[1]): import("../types/snapshots.js").MonitorComponentHealthSnapshot;
    observeHeartbeat(component: MonitorComponent, observedAt?: bigint, details?: Record<string, unknown>): import("../types/snapshots.js").MonitorComponentHealthSnapshot;
    ingest(event: MonitorIngressEvent, sourceStreamId?: string | null): Promise<MonitorIngestResult>;
    pumpReplayBatch(limit?: number): Promise<ReplayPumpResult>;
    reconcileRecovery(limit?: number): Promise<ReplayPumpResult | null>;
    close(): void;
}
export declare function createTransportMonitorAdapterFromFile(handlers: MonitorAdapterHandlers, configPath?: string): TransportMonitorAdapter;
export declare function createTransportMonitorAdapterFromEnvironment(handlers: MonitorAdapterHandlers, inlineConfig?: MonitorConfigOverride, options?: MonitorConfigEnvironmentOptions): TransportMonitorAdapter;

import { MonitorRuntime } from "../runtime/MonitorRuntime.js";
import { LifecycleDispatcher } from "../lifecycle/LifecycleDispatcher.js";
import { loadMonitorConfigFile, resolveMonitorConfigFromEnvironment, } from "../config.js";
import { deriveMonitorAdmissionDecision, MonitorIndeterminateOutcomeError, } from "../boundary.js";
export class TransportMonitorAdapter {
    capacity;
    lifecycle;
    #runtime;
    #handlers;
    #activeReplayOperation = null;
    constructor(handlers, config = {}) {
        this.#runtime = new MonitorRuntime(config);
        this.capacity = this.#runtime.capacity;
        this.lifecycle = this.#runtime.lifecycle;
        this.#runtime.bindReplayOrchestrationOwner("adapter");
        this.#handlers = handlers;
    }
    getRuntime() {
        return this.#runtime;
    }
    getSnapshot() {
        return this.#runtime.getSnapshot();
    }
    getInspectedSnapshot() {
        return this.#runtime.getInspectedSnapshot();
    }
    getOperatorSnapshot() {
        return this.#runtime.getOperatorSnapshot();
    }
    getReplaySnapshot() {
        return this.#runtime.getReplaySnapshot();
    }
    updateComponentHealth(component, update) {
        const snapshot = this.#runtime.updateComponentHealth(component, update);
        void this.#notifyReplayChange();
        return snapshot;
    }
    observeHeartbeat(component, observedAt, details) {
        const snapshot = this.#runtime.observeHeartbeat(component, observedAt, details);
        void this.#notifyReplayChange();
        return snapshot;
    }
    async ingest(event, sourceStreamId) {
        const operationStartedAt = this.#now();
        const { rowId, decision } = this.#runtime.ingestTransportEvent(event, sourceStreamId);
        const admission = deriveMonitorAdmissionDecision(decision);
        let deliveryAttempted = false;
        let deliveryHandlerCompleted = false;
        let deliveryStartedAt = operationStartedAt;
        try {
            await this.#handlers.onDecision?.(event, decision, rowId);
            if (decision.action === "buffer_only" || decision.action === "pause") {
                await this.#handlers.onBuffered?.(event, decision, rowId);
                this.#emitOperationDuration("adapter.ingest", operationStartedAt, "buffered");
                return {
                    rowId,
                    decision,
                    admission,
                    forwardedTo: "buffer",
                };
            }
            if (decision.deliveryMode === "dedupe_bypass") {
                deliveryAttempted = true;
                deliveryStartedAt = this.#now();
                this.#emitLifecycleAt(deliveryStartedAt, {
                    type: "deliveryAttempted",
                    rowId,
                    eventId: event.id,
                    deliveryMode: decision.deliveryMode,
                    replay: false,
                });
                await this.#handlers.deliverToOrder(event, {
                    rowId,
                    sourceStreamId: sourceStreamId ?? null,
                    deliveryMode: decision.deliveryMode,
                    replay: false,
                });
                deliveryHandlerCompleted = true;
                this.#emitLifecycle({
                    type: "deliveryHandlerCompleted",
                    rowId,
                    eventId: event.id,
                    deliveryMode: decision.deliveryMode,
                    replay: false,
                    durationMs: this.#durationSince(deliveryStartedAt),
                });
                this.#runtime.acknowledgeIngressDelivery([rowId]);
                this.#emitOperationDuration("adapter.ingest", operationStartedAt, "delivered");
                return {
                    rowId,
                    decision,
                    admission,
                    forwardedTo: "causal-order",
                };
            }
            deliveryAttempted = true;
            deliveryStartedAt = this.#now();
            this.#emitLifecycleAt(deliveryStartedAt, {
                type: "deliveryAttempted",
                rowId,
                eventId: event.id,
                deliveryMode: decision.deliveryMode,
                replay: false,
            });
            await this.#handlers.deliverToDedupe(event, {
                rowId,
                sourceStreamId: sourceStreamId ?? null,
                deliveryMode: decision.deliveryMode,
                replay: false,
            });
            deliveryHandlerCompleted = true;
            this.#emitLifecycle({
                type: "deliveryHandlerCompleted",
                rowId,
                eventId: event.id,
                deliveryMode: decision.deliveryMode,
                replay: false,
                durationMs: this.#durationSince(deliveryStartedAt),
            });
            this.#runtime.acknowledgeIngressDelivery([rowId]);
            this.#emitOperationDuration("adapter.ingest", operationStartedAt, "delivered");
            return {
                rowId,
                decision,
                admission,
                forwardedTo: "dedupe",
            };
        }
        catch (error) {
            if (deliveryAttempted && !deliveryHandlerCompleted) {
                this.#emitLifecycle({
                    type: "deliveryFailed",
                    rowId,
                    eventId: event.id,
                    deliveryMode: decision.deliveryMode,
                    replay: false,
                    durationMs: this.#durationSince(deliveryStartedAt),
                    reasonCode: "DELIVERY_HANDLER_REJECTED",
                });
            }
            else {
                this.#emitLifecycle({
                    type: "deliveryIndeterminate",
                    rowId,
                    eventId: event.id,
                    deliveryMode: decision.deliveryMode,
                    replay: false,
                    reasonCode: deliveryHandlerCompleted
                        ? "DELIVERY_ACKNOWLEDGEMENT_UNOBSERVED"
                        : "ADAPTER_COMPLETION_UNOBSERVED",
                });
            }
            this.#emitOperationDuration("adapter.ingest", operationStartedAt, "failed");
            throw new MonitorIndeterminateOutcomeError("complete adapter ingress delivery", rowId, error);
        }
    }
    async pumpReplayBatch(limit) {
        if (this.#activeReplayOperation) {
            return this.#activeReplayOperation.then((result) => result ?? this.#emptyReplayPumpResult());
        }
        return this.#runReplayOperation(() => this.#pumpReplayBatchInternal(limit)).then((result) => result ?? this.#emptyReplayPumpResult());
    }
    async #pumpReplayBatchInternal(limit) {
        const operationStartedAt = this.#now();
        const batch = this.#runtime.claimManagedReplayBatch(limit);
        await this.#notifyReplayChange();
        if (batch.entries.length === 0) {
            await this.#notifyReplayChange();
            this.#emitOperationDuration("adapter.pumpReplayBatch", operationStartedAt, "empty");
            return {
                snapshot: this.#runtime.getReplaySnapshot(),
                claimedCount: 0,
                deliveredCount: 0,
                completed: batch.isDrainComplete,
            };
        }
        const claimedRowIds = [];
        const handlerCompletedEntries = [];
        let activeEntry = null;
        let activeEntryStartedAt = operationStartedAt;
        try {
            for (const entry of batch.entries) {
                activeEntry = entry;
                claimedRowIds.push(entry.rowId);
                activeEntryStartedAt = this.#now();
                this.#emitLifecycleAt(activeEntryStartedAt, {
                    type: "deliveryAttempted",
                    rowId: entry.rowId,
                    eventId: entry.event.id,
                    deliveryMode: "replay_through_dedupe",
                    replay: true,
                    attempt: entry.replayAttempts,
                });
                await this.#handlers.deliverToDedupe(entry.event, {
                    rowId: entry.rowId,
                    sourceStreamId: entry.sourceStreamId,
                    deliveryMode: "replay_through_dedupe",
                    replay: true,
                });
                handlerCompletedEntries.push(entry);
                this.#emitLifecycle({
                    type: "deliveryHandlerCompleted",
                    rowId: entry.rowId,
                    eventId: entry.event.id,
                    deliveryMode: "replay_through_dedupe",
                    replay: true,
                    attempt: entry.replayAttempts,
                    durationMs: this.#durationSince(activeEntryStartedAt),
                });
                activeEntry = null;
            }
            const snapshot = this.#runtime.acknowledgeManagedReplayBatch(claimedRowIds);
            await this.#notifyReplayChange();
            this.#emitOperationDuration("adapter.pumpReplayBatch", operationStartedAt, "completed");
            return {
                snapshot,
                claimedCount: claimedRowIds.length,
                deliveredCount: claimedRowIds.length,
                completed: snapshot.state === "completed" || snapshot.state === "idle",
            };
        }
        catch (error) {
            if (activeEntry !== null) {
                this.#emitLifecycle({
                    type: "deliveryFailed",
                    rowId: activeEntry.rowId,
                    eventId: activeEntry.event.id,
                    deliveryMode: "replay_through_dedupe",
                    replay: true,
                    attempt: activeEntry.replayAttempts,
                    durationMs: this.#durationSince(activeEntryStartedAt),
                    reasonCode: "DELIVERY_HANDLER_REJECTED",
                });
            }
            for (const completedEntry of handlerCompletedEntries) {
                this.#emitLifecycle({
                    type: "deliveryIndeterminate",
                    rowId: completedEntry.rowId,
                    eventId: completedEntry.event.id,
                    deliveryMode: "replay_through_dedupe",
                    replay: true,
                    attempt: completedEntry.replayAttempts,
                    reasonCode: "REPLAY_BATCH_ACKNOWLEDGEMENT_UNOBSERVED",
                });
            }
            const message = error instanceof Error ? error.message : "unknown replay failure";
            const snapshot = this.#runtime.failManagedReplay(message, claimedRowIds);
            await this.#notifyReplayChange();
            this.#emitOperationDuration("adapter.pumpReplayBatch", operationStartedAt, "failed");
            return {
                snapshot,
                claimedCount: claimedRowIds.length,
                deliveredCount: 0,
                completed: false,
            };
        }
    }
    async reconcileRecovery(limit) {
        if (this.#activeReplayOperation) {
            return this.#activeReplayOperation;
        }
        return this.#runReplayOperation(() => this.#reconcileRecoveryInternal(limit));
    }
    async #reconcileRecoveryInternal(limit) {
        const snapshot = this.#runtime.getReplaySnapshot();
        const reservoir = this.#runtime.getReservoirStats();
        const backlog = reservoir.totalPendingRows;
        const needsRecoveryReplay = this.#runtime.needsRecoveryReplay();
        const hasObservedRecoveryTransition = this.#runtime.hasObservedRecoveryTransition();
        const hasReplayEligibleBacklog = this.#hasReplayEligibleBacklog(reservoir.pendingRowsByDeliveryMode);
        if (backlog === 0) {
            return null;
        }
        if (snapshot.state === "idle" &&
            (!needsRecoveryReplay ||
                !hasObservedRecoveryTransition ||
                !hasReplayEligibleBacklog)) {
            return null;
        }
        if (snapshot.state === "completed" &&
            !hasReplayEligibleBacklog) {
            return null;
        }
        if ((snapshot.state === "idle" ||
            snapshot.state === "failed" ||
            snapshot.state === "completed") &&
            !this.#runtime.isReplayRecoveryConfirmed()) {
            return null;
        }
        if (snapshot.state === "idle" ||
            snapshot.state === "failed" ||
            snapshot.state === "completed") {
            this.#runtime.queueManagedReplay();
            await this.#notifyReplayChange();
        }
        const nextSnapshot = this.#runtime.getReplaySnapshot();
        if (nextSnapshot.state !== "queued" && nextSnapshot.state !== "running") {
            return null;
        }
        return this.#pumpReplayBatchInternal(limit);
    }
    close() {
        this.#runtime.close();
    }
    async #notifyReplayChange() {
        await this.#handlers.onReplayStateChange?.(this.#runtime.getReplaySnapshot());
    }
    #runReplayOperation(operation) {
        if (this.#activeReplayOperation) {
            return this.#activeReplayOperation;
        }
        const activeOperation = operation();
        this.#activeReplayOperation = activeOperation;
        void activeOperation.then(() => {
            if (this.#activeReplayOperation === activeOperation) {
                this.#activeReplayOperation = null;
            }
        }, () => {
            if (this.#activeReplayOperation === activeOperation) {
                this.#activeReplayOperation = null;
            }
        });
        return activeOperation;
    }
    #emptyReplayPumpResult() {
        const snapshot = this.#runtime.getReplaySnapshot();
        return {
            snapshot,
            claimedCount: 0,
            deliveredCount: 0,
            completed: snapshot.state === "completed" || snapshot.state === "idle",
        };
    }
    #hasReplayEligibleBacklog(pendingRowsByDeliveryMode) {
        return Object.entries(pendingRowsByDeliveryMode).some(([deliveryMode, count]) => deliveryMode !== "normal" &&
            deliveryMode !== "dedupe_bypass" &&
            Number(count ?? 0) > 0);
    }
    #now() {
        try {
            return this.#runtime.getConfig().now?.() ?? BigInt(Date.now());
        }
        catch {
            return BigInt(Date.now());
        }
    }
    #durationSince(startedAt) {
        const endedAt = this.#now();
        return (endedAt >= startedAt ? endedAt - startedAt : 0n).toString();
    }
    #emitLifecycle(event) {
        this.#emitLifecycleAt(this.#now(), event);
    }
    #emitLifecycleAt(occurredAt, event) {
        try {
            this.lifecycle.publish({
                ...event,
                occurredAtMs: occurredAt.toString(),
            });
        }
        catch {
            // Lifecycle observation is best effort and cannot alter adapter outcomes.
        }
    }
    #emitOperationDuration(operation, startedAt, outcome) {
        const endedAt = this.#now();
        this.#emitLifecycleAt(endedAt, {
            type: "operationDurationObserved",
            operation,
            durationMs: (endedAt >= startedAt ? endedAt - startedAt : 0n).toString(),
            outcome,
        });
    }
}
export function createTransportMonitorAdapterFromFile(handlers, configPath) {
    return new TransportMonitorAdapter(handlers, loadMonitorConfigFile(configPath));
}
export function createTransportMonitorAdapterFromEnvironment(handlers, inlineConfig = {}, options = {}) {
    return new TransportMonitorAdapter(handlers, resolveMonitorConfigFromEnvironment(inlineConfig, options));
}

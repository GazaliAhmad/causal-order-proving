import net from "node:net";
import { once } from "node:events";
import { TransportOperationError } from "./types.js";
import { WebSocketJsonTransport } from "./websocket.js";
async function getAvailablePort() {
    const server = net.createServer();
    server.listen(0, "127.0.0.1");
    await once(server, "listening");
    const address = server.address();
    if (!address || typeof address === "string") {
        server.close();
        throw new Error("Failed to allocate a local TCP port");
    }
    const { port } = address;
    await new Promise((resolveClose) => server.close(resolveClose));
    return port;
}
export async function createHarnessAdapter(options) {
    const eventHandlers = new Set();
    const peerStateHandlers = new Set();
    const errorHandlers = new Set();
    const clients = new Map();
    const disconnectedNodes = new Set();
    const queuedSends = new Map();
    const acceptedSends = new Set();
    let transport = null;
    let serverPort = null;
    let stopping = false;
    let stopOperation = null;
    const createClient = (nodeId, port) => {
        const client = new WebSocketJsonTransport({
            mode: "client",
            url: `ws://127.0.0.1:${port}`,
            peerId: `harness-server-for-${nodeId}`,
            maxInFlightSendsPerPeer: options.maxInFlightSendsPerPeer,
        });
        client.onError((error) => {
            for (const handler of errorHandlers) {
                handler(error);
            }
        });
        return client;
    };
    const trackSend = async (client, event) => {
        const operation = client.send(event);
        acceptedSends.add(operation);
        try {
            await operation;
        }
        finally {
            acceptedSends.delete(operation);
        }
    };
    return {
        async start() {
            if (transport) {
                throw new Error("Transport harness adapter already started");
            }
            stopping = false;
            stopOperation = null;
            const port = await getAvailablePort();
            serverPort = port;
            transport = new WebSocketJsonTransport({
                mode: "server",
                host: "127.0.0.1",
                port,
            });
            transport.onEvent((event, context) => {
                for (const handler of eventHandlers) {
                    handler(event, context);
                }
            });
            transport.onPeerState((state) => {
                for (const handler of peerStateHandlers) {
                    handler(state);
                }
            });
            transport.onError((error) => {
                for (const handler of errorHandlers) {
                    handler(error);
                }
            });
            await transport.start();
            try {
                for (const nodeId of options.nodeIds) {
                    const client = createClient(nodeId, port);
                    clients.set(nodeId, client);
                }
                await Promise.all([...clients.values()].map((client) => client.start()));
            }
            catch (error) {
                await Promise.allSettled([...clients.values()].map((client) => client.stop()));
                clients.clear();
                await transport.stop().catch(() => undefined);
                transport = null;
                serverPort = null;
                throw error;
            }
        },
        async stop() {
            if (stopOperation) {
                return stopOperation;
            }
            stopping = true;
            stopOperation = (async () => {
                const stopError = new TransportOperationError("TRANSPORT_INVALID_STATE", "Transport harness adapter stopped before a fault-buffered send could reconnect");
                for (const entries of queuedSends.values()) {
                    for (const entry of entries) {
                        entry.reject(stopError);
                    }
                }
                queuedSends.clear();
                const sendResults = await Promise.allSettled([...acceptedSends]);
                const clientResults = await Promise.allSettled([...clients.values()].map((client) => client.stop()));
                clients.clear();
                let serverResult;
                if (transport) {
                    serverResult = await transport.stop().then(() => ({ status: "fulfilled", value: undefined }), (reason) => ({ status: "rejected", reason }));
                    transport = null;
                    serverPort = null;
                }
                const failure = [
                    ...sendResults,
                    ...clientResults,
                    ...(serverResult ? [serverResult] : []),
                ].find((result) => result.status === "rejected");
                if (failure?.status === "rejected") {
                    throw failure.reason;
                }
            })();
            return stopOperation;
        },
        async send(event) {
            if (stopping) {
                throw new TransportOperationError("TRANSPORT_INVALID_STATE", "Transport harness adapter cannot send while stopping");
            }
            if (disconnectedNodes.has(event.nodeId)) {
                return new Promise((resolve, reject) => {
                    const entries = queuedSends.get(event.nodeId) ?? [];
                    entries.push({ event, resolve, reject });
                    queuedSends.set(event.nodeId, entries);
                });
            }
            const client = clients.get(event.nodeId);
            if (!client) {
                throw new Error(`No transport test client registered for ${event.nodeId}`);
            }
            await trackSend(client, event);
        },
        async setNodeConnectivity(nodeId, state) {
            if (stopping || !transport) {
                throw new TransportOperationError("TRANSPORT_INVALID_STATE", "Transport harness connectivity cannot change while stopped");
            }
            if (!options.nodeIds.includes(nodeId)) {
                throw new Error(`Unknown transport harness node: ${nodeId}`);
            }
            if (state === "disconnected") {
                if (disconnectedNodes.has(nodeId)) {
                    return;
                }
                disconnectedNodes.add(nodeId);
                const client = clients.get(nodeId);
                clients.delete(nodeId);
                await client?.stop();
                return;
            }
            if (!disconnectedNodes.has(nodeId)) {
                return;
            }
            if (serverPort === null) {
                throw new Error("Transport harness server did not expose a TCP address");
            }
            const client = createClient(nodeId, serverPort);
            clients.set(nodeId, client);
            try {
                await client.start();
                disconnectedNodes.delete(nodeId);
                const entries = queuedSends.get(nodeId) ?? [];
                queuedSends.delete(nodeId);
                await Promise.all(entries.map(async (entry) => {
                    try {
                        await trackSend(client, entry.event);
                        entry.resolve();
                    }
                    catch (error) {
                        entry.reject(error);
                    }
                }));
            }
            catch (error) {
                clients.delete(nodeId);
                await client.stop().catch(() => undefined);
                throw error;
            }
        },
        onEvent(handler) {
            eventHandlers.add(handler);
            return () => eventHandlers.delete(handler);
        },
        onPeerState(handler) {
            peerStateHandlers.add(handler);
            return () => peerStateHandlers.delete(handler);
        },
        onError(handler) {
            errorHandlers.add(handler);
            return () => errorHandlers.delete(handler);
        },
    };
}
export default createHarnessAdapter;

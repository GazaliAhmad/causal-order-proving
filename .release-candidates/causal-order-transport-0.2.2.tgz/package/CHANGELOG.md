# Changelog

All notable changes to `@causal-order/transport` will be documented in this file.

## 0.2.2

- Exposed the existing per-peer in-flight send capacity through the published
  `/testing` adapter so outage qualification can preserve production-like
  throughput without weakening the transport's pressure guard.

## 0.2.1

- Added published `/testing` fault control for deterministic per-node
  disconnect and reconnect scenarios.
- Buffered sends accepted while a harness node is disconnected and settled
  them only after reconnection, preserving end-to-end accounting.
- Added a connectivity contract proving mid-run peer-state evidence, withheld
  delivery during the outage, replay after reconnect, and clean shutdown.

## 0.2.0

- Added an explicit restartable transport lifecycle with deterministic state,
  invalid-transition rejection, bounded initial connection, accepted-work
  draining, and bounded shutdown.
- Introduced a versioned root wire envelope with a unique transmission ID and
  correlated positive or negative delivery-result frames.
- Changed root `send()` completion to await successful remote primary delivery
  acknowledgment rather than treating WebSocket write invocation as delivery.
- Added one awaited `onDelivery()` authority while retaining `onEvent()` for
  isolated observation callbacks.
- Added global and per-peer send/receive bounds, buffered-byte pressure checks,
  delivery and acknowledgment timeouts, and explicit partial-broadcast failure.
- Added stable `TransportOperationError` codes for lifecycle, connection,
  pressure, delivery, protocol, and shutdown outcomes.
- Refactored the `/testing` adapter to use root transport clients and the same
  acknowledgment and stop-barrier behavior as production code.
- Added deterministic acknowledged-delivery, refusal, pressure, shutdown
  timeout, restart, duplicate-ID, immediate-stop, and no-post-stop-callback
  regressions.
- Added a required `/testing` stop-barrier gate covering 1,000 acknowledged
  transmissions followed by immediate shutdown.
- Raised the supported Node.js floor to `>=22`, removed Node.js 20 from CI, and
  retained required validation on Node.js 22 and 24.

## 0.1.3

- Fixed public `send()` so bigint-backed sequence, clock, and ingest metadata
  are encoded as decimal strings on the JSON wire.
- Preserved `partition`, `parentEventId`, and `dependencyEventIds` through the
  default normalization and send/receive paths.
- Rejected unsafe or fractional numeric timestamps and sequences plus invalid
  HLC logical counters instead of truncating or silently accepting them.
- Made server `start()` await listen readiness and reject initial bind failures.
- Added focused transport contract tests and a clean packed-consumer test for
  the root and `/testing` entrypoints.
- Updated the vendored WebSocket runtime to `ws@8.21.1` while retaining the
  documented removal of optional native-module probing.
- Updated development validation to `@causal-order/testing@0.2.6` and made the
  raw `ws` test client an explicit development dependency.
- Expanded required CI coverage to the contract, multi-node, E2E, harness,
  vendored metadata, and Node.js 24 checks alongside Node.js 20 and 22.

## 0.1.2

- Published the `@causal-order/transport/testing` subpath so `@causal-order/testing` can drive the transport adapter through the documented npm consumer flow.
- Updated the README with the npm consumer flow for exercising the transport through `@causal-order/testing`.
- Clarified the `/testing` validation ladder so `transport-sanity-mesh` is the smoke baseline, `typical-real-world-mesh` is the normal deployment profile, and `expected-production-mesh-dark-jitter` is a separate resilience profile.
- Aligned `/transport` validation artifacts with the published `@causal-order/testing` reporting layer so the same summary and compare CLIs now interpret both adapter-runtime and wall-clock transport runs through a shared dedupe-aware correctness model.
- Vendored the `ws` runtime behind an internal wrapper so the published package keeps a stable WebSocket implementation boundary without an extra npm runtime dependency.
- Verified the packaged adapter entrypoint against the published `@causal-order/testing` runtime path from a clean consumer install.
- Confirmed the `0.1.2` tarball includes the built `testing` adapter files required by the `./testing` export.
- Validated the release with a clean `transport-sanity-mesh` pass, a healthy `typical-real-world-mesh` pass, and repeated `expected-production-mesh-dark-jitter` runs that completed as `PASS WITH STRESS` under heavy lateness and backlog pressure without a stable duplicate-leak reproduction.

## 0.1.1

- Clarified the README scope so the package is explicitly positioned as the current WebSocket + JSON transport layer for the `causal-order` stack.
- Tightened the README so it reads more like an npm package reference, including public GitHub links to validation scripts.
- Added a 12-node multi-node transport test for concurrent WebSocket + JSON ingress verification.
- Added an end-to-end pipeline test covering `transport -> @causal-order/dedupe -> causal-order`.
- Added a smoke-level verification script for the published `@causal-order/testing` runtime package.
- Added a transport-aware wall-clock runtime harness for long-running `WebSocket -> transport -> dedupe -> causal-order` validation with timing, heartbeats, anomaly logs, and run summaries.
- Added wall-clock memory summary fields including `maxRssBytes`, `finalRssBytes`, and `avgRssBytes`.
- Added heap-oriented wall-clock memory fields including `heapUsedBytes`, `heapTotalBytes`, `externalBytes`, and `arrayBuffersBytes`.
- Reworked wall-clock latency tracking so the harness uses running summaries instead of retaining full in-memory latency sample arrays.
- Moved `@causal-order/testing` to `devDependencies` so publish installs stay runtime-focused.
- Confirmed the published npm tarball is limited to built runtime files and package documentation.
- Documented the completed `2h`, `4h`, and `8h` validation runs, including the heap-tracked `8h` rerun used to reduce transport-leak concern after the harness memory fix.

## 0.1.0

- Introduced a standalone transport package for the `causal-order` ecosystem.
- Added a WebSocket + JSON reference adapter that normalizes incoming node traffic into canonical runtime events.
- Added a small transport contract for event delivery, peer state, and transport errors.
- Added smoke-test, CI, and npm publish scaffolding for first release readiness.
